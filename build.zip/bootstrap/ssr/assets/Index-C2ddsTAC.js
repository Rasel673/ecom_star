import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { useForm, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { Plus, Trash2 } from "lucide-react";
function Index({ banners = [] }) {
  const { data, setData, post, reset, processing, errors } = useForm({
    title: "",
    subtitle: "",
    image: "",
    link: "",
    position: "home_slider",
    sort_order: 0,
    status: true
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("admin.banners.store"), {
      onSuccess: () => reset()
    });
  };
  const handleDelete = (id, title) => {
    if (confirm(`Delete banner "${title || "Untitled"}"?`)) {
      router.delete(route("admin.banners.destroy", id));
    }
  };
  return /* @__PURE__ */ jsx(AdminLayout, { title: "Manage Banners & Sliders", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8", children: [
    /* @__PURE__ */ jsxs("div", { className: "lg:col-span-4 bg-white rounded-2xl border border-gray-200/80 shadow-sm p-6", children: [
      /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 border-b pb-3 mb-4 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4 text-[#EF4A23]" }),
        /* @__PURE__ */ jsx("span", { children: "Add New Banner" })
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Banner Title" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.title,
              onChange: (e) => setData("title", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              placeholder: "e.g. Build Your Dream PC"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Subtitle / Caption" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.subtitle,
              onChange: (e) => setData("subtitle", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              placeholder: "Exclusive offer on latest processors"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Image URL *" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              required: true,
              value: data.image,
              onChange: (e) => setData("image", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              placeholder: "https://images.unsplash.com/..."
            }
          ),
          errors.image && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.image })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Click Link / URL" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.link,
              onChange: (e) => setData("link", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              placeholder: "/pc-builder or /category/laptop"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Position" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: data.position,
                onChange: (e) => setData("position", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "home_slider", children: "Hero Slider" }),
                  /* @__PURE__ */ jsx("option", { value: "home_banner_2", children: "Right Promo Card" }),
                  /* @__PURE__ */ jsx("option", { value: "promo_banner", children: "Popup Banner" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Sort Order" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: data.sort_order,
                onChange: (e) => setData("sort_order", Number(e.target.value)),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "w-full bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold py-2.5 rounded-lg transition",
            children: processing ? "Saving..." : "Add Banner"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "lg:col-span-8 bg-white rounded-2xl border border-gray-200/80 shadow-sm overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "p-4 border-b", children: /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: "Current Promotional Banners" }) }),
      /* @__PURE__ */ jsx("div", { className: "p-4 grid grid-cols-1 sm:grid-cols-2 gap-4", children: banners.map((banner) => /* @__PURE__ */ jsxs("div", { className: "border border-gray-200 rounded-xl overflow-hidden relative group", children: [
        /* @__PURE__ */ jsx(
          "img",
          {
            src: banner.image,
            alt: banner.title || "Banner",
            className: "w-full h-32 object-cover"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "p-3 bg-white text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-900 truncate", children: banner.title || "Untitled Banner" }),
            /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-semibold uppercase", children: banner.position })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-400 mt-0.5 truncate", children: banner.subtitle || "No subtitle" })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => handleDelete(banner.id, banner.title),
            className: "absolute top-2 right-2 bg-rose-600 hover:bg-rose-700 text-white p-1.5 rounded-lg shadow-md transition opacity-0 group-hover:opacity-100",
            title: "Delete banner",
            children: /* @__PURE__ */ jsx(Trash2, { className: "w-3.5 h-3.5" })
          }
        )
      ] }, banner.id)) })
    ] })
  ] }) });
}
export {
  Index as default
};
