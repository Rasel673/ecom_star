import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { Link, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { Clock, User, Phone, MapPin, Calendar, Edit3, CheckCircle2, XCircle, Truck } from "lucide-react";
function PreOrders({ preOrders }) {
  const [selectedPreOrder, setSelectedPreOrder] = useState(null);
  const [statusForm, setStatusForm] = useState({
    status: "pending",
    expected_date: "",
    notes: ""
  });
  const [submitting, setSubmitting] = useState(false);
  const handleOpenEdit = (po) => {
    setSelectedPreOrder(po);
    setStatusForm({
      status: po.status || "pending",
      expected_date: po.expected_date || "",
      notes: po.notes || ""
    });
  };
  const handleUpdateStatus = (e) => {
    e.preventDefault();
    if (!selectedPreOrder) return;
    setSubmitting(true);
    router.patch(route("admin.preorders.status", selectedPreOrder.id), statusForm, {
      preserveScroll: true,
      onSuccess: () => {
        setSelectedPreOrder(null);
      },
      onFinish: () => setSubmitting(false)
    });
  };
  const getStatusBadge = (status) => {
    switch (status) {
      case "confirmed":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200", children: [
          /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3 h-3" }),
          " Confirmed"
        ] });
      case "ready_to_ship":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200", children: [
          /* @__PURE__ */ jsx(Truck, { className: "w-3 h-3" }),
          " Ready to Ship"
        ] });
      case "cancelled":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-50 text-red-700 border border-red-200", children: [
          /* @__PURE__ */ jsx(XCircle, { className: "w-3 h-3" }),
          " Cancelled"
        ] });
      default:
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200", children: [
          /* @__PURE__ */ jsx(Clock, { className: "w-3 h-3" }),
          " Pending Review"
        ] });
    }
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "Manage Customer Pre-Orders", children: [
    /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6", children: /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-xl font-black text-gray-900 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Clock, { className: "w-6 h-6 text-amber-500" }),
        /* @__PURE__ */ jsx("span", { children: "Customer Pre-Orders" })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Track and manage reservations for upcoming hardware, set expected delivery dates, and notify customers." })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs text-gray-600", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 text-gray-700 uppercase font-semibold border-b text-[11px] tracking-wider", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Pre-Order #" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Product" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Customer Info" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Qty & Price" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Expected Date" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "p-4 text-right", children: "Action" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: preOrders.data && preOrders.data.length > 0 ? preOrders.data.map((po) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/70 transition", children: [
          /* @__PURE__ */ jsxs("td", { className: "p-4 whitespace-nowrap", children: [
            /* @__PURE__ */ jsx("div", { className: "font-mono font-bold text-gray-900 text-xs", children: po.pre_order_number }),
            /* @__PURE__ */ jsx("div", { className: "text-[10px] text-gray-400 mt-0.5", children: new Date(po.created_at).toLocaleDateString() })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-4 max-w-xs", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            po.product && /* @__PURE__ */ jsx(
              "img",
              {
                src: po.product.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100&h=100&fit=crop",
                alt: po.product.name,
                className: "w-10 h-10 object-contain rounded-lg border bg-gray-50 p-1 shrink-0"
              }
            ),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "font-bold text-gray-900 line-clamp-1", children: po.product?.name || "Custom Product" }),
              /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400", children: [
                "Model: ",
                po.product?.model || "N/A"
              ] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxs("td", { className: "p-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "font-bold text-gray-900 flex items-center gap-1", children: [
              /* @__PURE__ */ jsx(User, { className: "w-3.5 h-3.5 text-gray-400" }),
              /* @__PURE__ */ jsx("span", { children: po.customer_name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-500 flex items-center gap-1 mt-0.5", children: [
              /* @__PURE__ */ jsx(Phone, { className: "w-3 h-3 text-gray-400" }),
              /* @__PURE__ */ jsx("span", { children: po.customer_phone })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400 flex items-center gap-1 mt-0.5 line-clamp-1", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "w-3 h-3 text-gray-400 shrink-0" }),
              /* @__PURE__ */ jsx("span", { children: po.delivery_address })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("td", { className: "p-4 whitespace-nowrap", children: [
            /* @__PURE__ */ jsxs("div", { className: "font-bold text-[#EF4A23]", children: [
              "৳",
              Number(po.unit_price * po.quantity).toLocaleString()
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400", children: [
              po.quantity,
              " pcs @ ৳",
              Number(po.unit_price).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-4 whitespace-nowrap", children: po.expected_date ? /* @__PURE__ */ jsxs("span", { className: "font-semibold text-xs text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100 flex items-center gap-1 w-fit", children: [
            /* @__PURE__ */ jsx(Calendar, { className: "w-3 h-3" }),
            po.expected_date
          ] }) : /* @__PURE__ */ jsx("span", { className: "text-gray-400 italic text-[11px]", children: "Pending estimation" }) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 whitespace-nowrap", children: getStatusBadge(po.status) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 text-right whitespace-nowrap", children: /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => handleOpenEdit(po),
              className: "px-3 py-1.5 bg-[#081621] hover:bg-amber-600 text-white text-xs font-semibold rounded-lg transition shadow-sm inline-flex items-center gap-1.5",
              children: [
                /* @__PURE__ */ jsx(Edit3, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: "Update" })
              ]
            }
          ) })
        ] }, po.id)) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "7", className: "p-8 text-center text-gray-400", children: "No customer pre-orders placed yet." }) }) })
      ] }) }),
      preOrders.links && preOrders.links.length > 3 && /* @__PURE__ */ jsxs("div", { className: "p-4 border-t border-gray-100 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-gray-500", children: [
          "Showing ",
          preOrders.from || 0,
          " to ",
          preOrders.to || 0,
          " of ",
          preOrders.total,
          " pre-orders"
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1", children: preOrders.links.map((link, idx) => /* @__PURE__ */ jsx(
          Link,
          {
            href: link.url || "#",
            dangerouslySetInnerHTML: { __html: link.label },
            className: `px-3 py-1 text-xs rounded-lg border transition ${link.active ? "bg-amber-500 text-white border-amber-500" : !link.url ? "text-gray-300 border-gray-200 cursor-not-allowed" : "text-gray-600 border-gray-200 hover:bg-gray-50"}`
          },
          idx
        )) })
      ] })
    ] }),
    selectedPreOrder && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-gray-100", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] px-6 py-4 flex items-center justify-between text-white", children: [
        /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4 text-amber-400" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "Update Pre-Order #",
            selectedPreOrder.pre_order_number
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setSelectedPreOrder(null),
            className: "text-gray-400 hover:text-white text-lg leading-none",
            children: "×"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleUpdateStatus, className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 p-3.5 rounded-xl border border-gray-200 text-xs text-gray-700", children: [
          /* @__PURE__ */ jsx("div", { className: "font-bold text-gray-900 mb-1", children: selectedPreOrder.product?.name }),
          /* @__PURE__ */ jsxs("div", { children: [
            "Customer: ",
            /* @__PURE__ */ jsx("strong", { children: selectedPreOrder.customer_name }),
            " (",
            selectedPreOrder.customer_phone,
            ")"
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            "Address: ",
            selectedPreOrder.delivery_address
          ] }),
          selectedPreOrder.notes && /* @__PURE__ */ jsxs("div", { className: "mt-2 text-gray-500 italic bg-white p-2 rounded border border-gray-200", children: [
            'Customer note: "',
            selectedPreOrder.notes,
            '"'
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Pre-Order Status *" }),
          /* @__PURE__ */ jsxs(
            "select",
            {
              value: statusForm.status,
              onChange: (e) => setStatusForm({ ...statusForm, status: e.target.value }),
              className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3",
              children: [
                /* @__PURE__ */ jsx("option", { value: "pending", children: "Pending Review (Waiting for shipment schedule)" }),
                /* @__PURE__ */ jsx("option", { value: "confirmed", children: "Confirmed (Stock allocation secured)" }),
                /* @__PURE__ */ jsx("option", { value: "ready_to_ship", children: "Ready to Ship (Arrived at warehouse)" }),
                /* @__PURE__ */ jsx("option", { value: "cancelled", children: "Cancelled" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Expected Arrival Date / Period" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: statusForm.expected_date,
              onChange: (e) => setStatusForm({ ...statusForm, expected_date: e.target.value }),
              placeholder: "e.g. 15 Nov, 2026 or 2-3 Weeks",
              className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
            }
          ),
          /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400 mt-1", children: "This date will be displayed to the customer in their account pre-orders tab." })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Admin Notes (Optional)" }),
          /* @__PURE__ */ jsx(
            "textarea",
            {
              rows: "3",
              value: statusForm.notes,
              onChange: (e) => setStatusForm({ ...statusForm, notes: e.target.value }),
              placeholder: "Internal notes or updates...",
              className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] p-2.5"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setSelectedPreOrder(null),
              className: "px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "submit",
              disabled: submitting,
              className: "px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md disabled:opacity-50 transition",
              children: [
                /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: submitting ? "Saving..." : "Save Changes" })
              ]
            }
          )
        ] })
      ] })
    ] }) })
  ] });
}
export {
  PreOrders as default
};
