import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { usePage, Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { Cpu, Zap, RotateCcw, Share2, Printer, Bookmark, ShoppingCart, Trash2, Plus, Monitor } from "lucide-react";
function PcBuilder({ components = [], seo = {} }) {
  const { auth, settings } = usePage().props;
  const [selectedBuild, setSelectedBuild] = useState({});
  const [copied, setCopied] = useState(false);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  useEffect(() => {
    const saved = localStorage.getItem("startech_pc_build");
    if (saved) {
      try {
        setSelectedBuild(JSON.parse(saved));
      } catch (e) {
      }
    }
  }, []);
  const getItemPrice = (item) => {
    if (!item) return 0;
    const raw = item.special_price ?? item.regular_price ?? item.price ?? 0;
    const num = parseFloat(raw);
    return isNaN(num) ? 0 : num;
  };
  const removeComponent = (slotId) => {
    const updated = { ...selectedBuild };
    delete updated[slotId];
    setSelectedBuild(updated);
    localStorage.setItem("startech_pc_build", JSON.stringify(updated));
  };
  const clearBuild = () => {
    if (confirm("Are you sure you want to clear your current PC build?")) {
      setSelectedBuild({});
      localStorage.removeItem("startech_pc_build");
    }
  };
  const buildKeys = Object.keys(selectedBuild);
  const buildItems = buildKeys.map((k) => ({ slotKey: k, ...selectedBuild[k] })).filter((item) => item.id);
  const totalPrice = buildItems.reduce((sum, item) => sum + getItemPrice(item), 0);
  const hasGPU = selectedBuild["graphics-card"];
  const hasCPU = selectedBuild["processor"];
  const totalWattage = 65 + (hasGPU ? 180 : 0) + (hasCPU ? 65 : 0) + (buildItems.length > 3 ? 60 : 30);
  const handleAddAllToCart = () => {
    if (buildItems.length === 0) return;
    const productIds = buildItems.map((item) => item.id);
    router.post(route("cart.addBulk"), {
      product_ids: productIds
    });
  };
  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 3e3);
  };
  const handlePrint = () => {
    window.print();
  };
  const handleSaveToAccount = () => {
    if (!auth?.user) {
      router.visit(route("login"));
      return;
    }
    if (buildItems.length === 0) {
      alert("Please select at least one component before saving your build.");
      return;
    }
    const name = prompt("Give a name to your custom PC build:", "My Custom Rig " + (/* @__PURE__ */ new Date()).toLocaleDateString());
    if (!name) return;
    router.post(route("customer.pcbuild.save"), {
      name,
      components: selectedBuild,
      total_price: totalPrice,
      total_wattage: totalWattage
    }, {
      preserveScroll: true
    });
  };
  const coreComponents = components.filter((c) => c.group === "Core Components" || !c.group);
  const peripheralComponents = components.filter((c) => c.group === "Peripherals & Accessories");
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: seo.title, description: seo.description, children: [
    /* @__PURE__ */ jsxs("div", { className: "print:hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-6 md:p-8 mb-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 border-b border-gray-200 pb-6 mb-6", children: [
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-2xl bg-orange-50 text-[#EF4A23] flex items-center justify-center", children: /* @__PURE__ */ jsx(Cpu, { className: "w-6 h-6" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("h1", { className: "text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: [
                "PC Builder - Build Your Own Computer - ",
                settings?.site_name || "Tech Shoppers"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Select and customize desktop hardware with real-time price & wattage calculation." })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-2 sm:flex sm:flex-wrap sm:items-center sm:gap-4 bg-gray-50/80 p-2.5 sm:p-3 rounded-2xl border border-gray-200 w-full lg:w-auto text-center sm:text-right", children: [
            /* @__PURE__ */ jsxs("div", { className: "border-r border-gray-200 pr-1 sm:pr-4", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-[11px] text-gray-400 font-medium block", children: "Selected" }),
              /* @__PURE__ */ jsxs("span", { className: "text-xs sm:text-sm font-black text-gray-800", children: [
                buildItems.length,
                "/",
                components.length
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "border-r border-gray-200 pr-1 sm:pr-4", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-[11px] text-gray-400 font-medium block", children: "Wattage" }),
              /* @__PURE__ */ jsxs("span", { className: "text-xs sm:text-sm font-black text-emerald-600 flex items-center justify-center sm:justify-end gap-0.5", children: [
                /* @__PURE__ */ jsx(Zap, { className: "w-3 h-3" }),
                " ~",
                totalWattage,
                "W"
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-[11px] text-gray-400 font-medium block", children: "Total" }),
              /* @__PURE__ */ jsxs("span", { className: "text-sm sm:text-2xl font-black text-[#EF4A23]", children: [
                "৳",
                Math.round(totalPrice).toLocaleString()
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-gray-50/80 p-3 sm:p-3.5 rounded-2xl border border-gray-200", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            buildItems.length > 0 && /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: clearBuild,
                className: "text-xs text-rose-600 hover:text-rose-700 font-bold px-3 py-2 rounded-xl border border-rose-200 bg-white hover:bg-rose-50 transition flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsx("span", { children: "Clear All" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: handleShare,
                className: "text-xs bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm",
                children: [
                  /* @__PURE__ */ jsx(Share2, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsx("span", { children: copied ? "Link Copied!" : "Share PC" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: handlePrint,
                className: "text-xs bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm",
                children: [
                  /* @__PURE__ */ jsx(Printer, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                  /* @__PURE__ */ jsx("span", { children: "Print / Quotation" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: handleSaveToAccount,
                disabled: buildItems.length === 0,
                className: "text-xs bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm disabled:opacity-40",
                title: "Save this configuration to your account history",
                children: [
                  /* @__PURE__ */ jsx(Bookmark, { className: "w-3.5 h-3.5 text-blue-600" }),
                  /* @__PURE__ */ jsx("span", { children: "Save Build" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: handleAddAllToCart,
              disabled: buildItems.length === 0,
              className: "w-full sm:w-auto bg-[#EF4A23] hover:bg-[#d63c17] disabled:opacity-40 text-white font-bold text-xs py-2.5 px-6 rounded-xl flex items-center justify-center gap-2 transition shadow-md hover:shadow-orange-500/20",
              children: [
                /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Add All to Cart (",
                  buildItems.length,
                  ")"
                ] })
              ]
            }
          ) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-6 md:p-8 mb-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-200 pb-3 mb-4 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Core Components" })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400", children: "Essential hardware for system boot" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100", children: coreComponents.map((comp) => {
          const selected = selectedBuild[comp.id] || selectedBuild[comp.category_slug];
          const price = getItemPrice(selected);
          return /* @__PURE__ */ jsxs("div", { className: "py-3 sm:py-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 group", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 sm:gap-4 flex-1", children: [
              /* @__PURE__ */ jsx("div", { className: "w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gray-50 border border-gray-200 flex items-center justify-center shrink-0 p-1", children: selected ? /* @__PURE__ */ jsx(
                "img",
                {
                  src: selected.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                  alt: selected.name,
                  className: "w-full h-full object-contain"
                }
              ) : /* @__PURE__ */ jsx(Cpu, { className: "w-5 h-5 sm:w-6 sm:h-6 text-gray-300" }) }),
              /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mb-0.5", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-900", children: comp.name }),
                  comp.required && /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-red-50 text-red-600 px-1.5 py-0.2 rounded font-semibold border border-red-100", children: "Required" })
                ] }),
                selected ? /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    Link,
                    {
                      href: route("product.show", selected.slug),
                      className: "text-xs font-semibold text-gray-800 hover:text-[#EF4A23] transition line-clamp-1",
                      children: selected.name
                    }
                  ),
                  /* @__PURE__ */ jsxs("span", { className: "text-xs font-bold text-[#EF4A23] block mt-0.5", children: [
                    "৳",
                    Math.round(price).toLocaleString()
                  ] })
                ] }) : /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 block", children: "Please select an item" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center justify-end gap-2", children: selected ? /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: `${route("pcbuilder.select", comp.category_slug)}?slot=${comp.id}`,
                  className: "text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold px-3 py-1.5 rounded-lg transition",
                  children: "Change"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => removeComponent(comp.id),
                  className: "p-1.5 text-gray-400 hover:text-rose-600 rounded-lg transition",
                  title: "Remove Component",
                  children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
                }
              )
            ] }) : /* @__PURE__ */ jsxs(
              Link,
              {
                href: `${route("pcbuilder.select", comp.category_slug)}?slot=${comp.id}`,
                className: "text-xs bg-[#081621] hover:bg-[#EF4A23] text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm",
                children: [
                  /* @__PURE__ */ jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsx("span", { children: "Choose" })
                ]
              }
            ) })
          ] }, comp.id);
        }) })
      ] }),
      peripheralComponents.length > 0 && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-6 md:p-8 mb-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-200 pb-3 mb-4 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-blue-600" }),
            /* @__PURE__ */ jsx("span", { children: "Peripherals & Accessories" })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400", children: "Display, keyboard, mouse & gear" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100", children: peripheralComponents.map((comp) => {
          const selected = selectedBuild[comp.id] || selectedBuild[comp.category_slug];
          const price = getItemPrice(selected);
          return /* @__PURE__ */ jsxs("div", { className: "py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 flex-1", children: [
              /* @__PURE__ */ jsx("div", { className: "w-14 h-14 rounded-2xl bg-gray-50 border border-gray-200 flex items-center justify-center shrink-0 p-1", children: selected ? /* @__PURE__ */ jsx(
                "img",
                {
                  src: selected.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                  alt: selected.name,
                  className: "w-full h-full object-contain"
                }
              ) : /* @__PURE__ */ jsx(Monitor, { className: "w-6 h-6 text-gray-300" }) }),
              /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-900 block mb-0.5", children: comp.name }),
                selected ? /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    Link,
                    {
                      href: route("product.show", selected.slug),
                      className: "text-xs font-semibold text-gray-800 hover:text-[#EF4A23] transition line-clamp-1",
                      children: selected.name
                    }
                  ),
                  /* @__PURE__ */ jsxs("span", { className: "text-xs font-bold text-[#EF4A23] block mt-0.5", children: [
                    "৳",
                    Math.round(price).toLocaleString()
                  ] })
                ] }) : /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 block", children: "Please select an item" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2 self-end sm:self-center", children: selected ? /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: `${route("pcbuilder.select", comp.category_slug)}?slot=${comp.id}`,
                  className: "text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold px-3 py-1.5 rounded-lg transition",
                  children: "Change"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => removeComponent(comp.id),
                  className: "p-1.5 text-gray-400 hover:text-rose-600 rounded-lg transition",
                  title: "Remove Component",
                  children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
                }
              )
            ] }) : /* @__PURE__ */ jsxs(
              Link,
              {
                href: `${route("pcbuilder.select", comp.category_slug)}?slot=${comp.id}`,
                className: "text-xs bg-[#081621] hover:bg-[#EF4A23] text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm",
                children: [
                  /* @__PURE__ */ jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsx("span", { children: "Choose" })
                ]
              }
            ) })
          ] }, comp.id);
        }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] text-white rounded-2xl sm:rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 sm:gap-6 border border-gray-800", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 block", children: "Estimated Custom Build Total:" }),
          /* @__PURE__ */ jsxs("div", { className: "text-2xl sm:text-3xl font-black text-[#EF4A23] mt-0.5", children: [
            "৳",
            Math.round(totalPrice).toLocaleString()
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block mt-1", children: "Includes official warranty & live components compatibility verification." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 sm:gap-3 w-full md:w-auto", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: handlePrint,
              className: "flex-1 md:flex-initial inline-flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xs py-3 px-4 sm:px-6 rounded-xl transition",
              children: [
                /* @__PURE__ */ jsx(Printer, { className: "w-4 h-4 text-orange-400" }),
                /* @__PURE__ */ jsx("span", { children: "Print Quotation" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: handleAddAllToCart,
              disabled: buildItems.length === 0,
              className: "flex-1 md:flex-initial inline-flex items-center justify-center gap-2 bg-[#EF4A23] hover:bg-[#d63c17] disabled:opacity-40 text-white font-bold text-xs py-3 px-6 sm:px-8 rounded-xl shadow-lg transition",
              children: [
                /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Add All to Cart (",
                  buildItems.length,
                  ")"
                ] })
              ]
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "hidden print:block p-8 bg-white text-black font-sans", children: [
      /* @__PURE__ */ jsxs("div", { className: "border-b-2 border-black pb-4 mb-6 flex justify-between items-start", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          settings?.site_logo ? /* @__PURE__ */ jsx("img", { src: settings.site_logo, alt: settings?.site_name || "Logo", className: "max-h-10 object-contain mb-2" }) : /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 mb-1", children: /* @__PURE__ */ jsx("span", { className: "text-2xl font-black tracking-tight uppercase", style: { color: settings?.primary_color || "#EF4A23" }, children: settings?.site_name || "TECH SHOPPERS" }) }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-600 font-semibold", children: settings?.site_name || "Tech Shoppers" }),
          /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-500", children: settings?.address || "28 Kazi Nazrul Islam Avenue, Banglamotor, Dhaka 1000" }),
          /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-gray-500", children: [
            "Hotline: ",
            settings?.hotline || "16793",
            " ",
            settings?.email ? `| Email: ${settings.email}` : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("span", { className: "text-lg font-black uppercase tracking-wider block", children: "PC Build Quotation" }),
          /* @__PURE__ */ jsxs("span", { className: "text-xs text-gray-600 block mt-1", children: [
            "Date: ",
            (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "text-xs text-gray-500 block", children: [
            "Ref: ST-PC-",
            Math.floor(1e5 + Math.random() * 9e5)
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs mb-6 border border-gray-300", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-100 border-b border-gray-300 font-bold", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-2.5 border-r border-gray-300 w-12 text-center", children: "SL" }),
          /* @__PURE__ */ jsx("th", { className: "p-2.5 border-r border-gray-300 w-44", children: "Component" }),
          /* @__PURE__ */ jsx("th", { className: "p-2.5 border-r border-gray-300", children: "Product Description" }),
          /* @__PURE__ */ jsx("th", { className: "p-2.5 text-right w-32", children: "Price (৳)" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-200", children: components.map((comp, idx) => {
          const item = selectedBuild[comp.id] || selectedBuild[comp.category_slug];
          const itemPrice = getItemPrice(item);
          return /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "p-2.5 text-center border-r border-gray-200", children: idx + 1 }),
            /* @__PURE__ */ jsx("td", { className: "p-2.5 font-bold border-r border-gray-200", children: comp.name }),
            /* @__PURE__ */ jsx("td", { className: "p-2.5 border-r border-gray-200", children: item ? /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("p", { className: "font-semibold", children: item.name }),
              item.model && /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-gray-500", children: [
                "Model: ",
                item.model
              ] })
            ] }) : /* @__PURE__ */ jsx("span", { className: "text-gray-400 italic", children: "Not Selected" }) }),
            /* @__PURE__ */ jsx("td", { className: "p-2.5 text-right font-bold", children: item ? `৳${Math.round(itemPrice).toLocaleString()}` : "—" })
          ] }, comp.id);
        }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-start gap-8 border-t border-black pt-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "max-w-md text-[10px] text-gray-600 space-y-1", children: [
          /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-800", children: "Terms & Conditions:" }),
          /* @__PURE__ */ jsx("p", { children: "1. Prices are subject to market availability and currency exchange fluctuations." }),
          /* @__PURE__ */ jsx("p", { children: "2. Official manufacturer warranty is provided for all genuine components." }),
          /* @__PURE__ */ jsx("p", { children: "3. This quotation is valid for 3 working days from the date of issuance." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-64 space-y-2 text-right", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-xs font-medium text-gray-600", children: [
            /* @__PURE__ */ jsx("span", { children: "Total Items:" }),
            /* @__PURE__ */ jsxs("span", { children: [
              buildItems.length,
              " Products"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-xs font-medium text-gray-600", children: [
            /* @__PURE__ */ jsx("span", { children: "Estimated Wattage:" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "~",
              totalWattage,
              "W"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-base font-black border-t-2 border-black pt-2", children: [
            /* @__PURE__ */ jsx("span", { children: "Total Price:" }),
            /* @__PURE__ */ jsxs("span", { className: "text-[#EF4A23]", children: [
              "৳",
              Math.round(totalPrice).toLocaleString()
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-16 pt-8 border-t border-dashed border-gray-400 flex justify-between text-xs text-gray-600", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "w-40 border-b border-gray-400 mb-1" }),
          /* @__PURE__ */ jsx("p", { children: "Customer Signature" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("div", { className: "w-40 border-b border-gray-400 mb-1 ml-auto" }),
          /* @__PURE__ */ jsxs("p", { children: [
            settings?.site_name || "Tech Shoppers",
            " Authorized Signature"
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  PcBuilder as default
};
