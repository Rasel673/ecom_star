import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { useForm, Head } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { Settings, Save, Check, Globe, Palette, PhoneCall, Share2, FileText, Upload, Trash2, Mail, Clock, MapPin, Truck } from "lucide-react";
const FacebookIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" }) });
const YoutubeIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" }) });
const InstagramIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" }) });
const TwitterIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" }) });
const LinkedinIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" }) });
const COLOR_PRESETS = [
  { name: "Tech Shoppers Orange", color: "#EF4A23" },
  { name: "Crimson Red", color: "#DC2626" },
  { name: "Royal Blue", color: "#2563EB" },
  { name: "Emerald Green", color: "#059669" },
  { name: "Purple Glow", color: "#7C3AED" },
  { name: "Amber Gold", color: "#D97706" },
  { name: "Teal Cyan", color: "#0D9488" },
  { name: "Midnight Dark", color: "#1E293B" }
];
function Index({ settings = {} }) {
  const [activeTab, setActiveTab] = useState("general");
  const [logoPreview, setLogoPreview] = useState(settings?.site_logo || null);
  const [faviconPreview, setFaviconPreview] = useState(settings?.site_favicon || null);
  const { data, setData, post, processing, errors, recentlySuccessful } = useForm({
    site_name: settings?.site_name || "",
    site_tagline: settings?.site_tagline || "",
    site_logo: null,
    site_logo_url: settings?.site_logo || "",
    remove_site_logo: false,
    site_favicon: null,
    site_favicon_url: settings?.site_favicon || "",
    remove_site_favicon: false,
    primary_color: settings?.primary_color || "#EF4A23",
    header_bg_color: settings?.header_bg_color || "#081621",
    footer_bg_color: settings?.footer_bg_color || "#081621",
    hotline: settings?.hotline || "",
    phone: settings?.phone || "",
    whatsapp: settings?.whatsapp || "",
    email: settings?.email || "",
    address: settings?.address || "",
    working_hours: settings?.working_hours || "10:00 AM - 7:00 PM",
    facebook_url: settings?.facebook_url || "",
    youtube_url: settings?.youtube_url || "",
    instagram_url: settings?.instagram_url || "",
    twitter_url: settings?.twitter_url || "",
    linkedin_url: settings?.linkedin_url || "",
    footer_about: settings?.footer_about || "",
    footer_copyright: settings?.footer_copyright || "",
    delivery_charge_inside: settings?.delivery_charge_inside || "60",
    delivery_charge_outside: settings?.delivery_charge_outside || "120"
  });
  const handleLogoFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setData((prev) => ({ ...prev, site_logo: file, remove_site_logo: false }));
      setLogoPreview(URL.createObjectURL(file));
    }
  };
  const handleRemoveLogo = () => {
    setData((prev) => ({ ...prev, site_logo: null, site_logo_url: "", remove_site_logo: true }));
    setLogoPreview(null);
  };
  const handleFaviconFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setData((prev) => ({ ...prev, site_favicon: file, remove_site_favicon: false }));
      setFaviconPreview(URL.createObjectURL(file));
    }
  };
  const handleRemoveFavicon = () => {
    setData((prev) => ({ ...prev, site_favicon: null, site_favicon_url: "", remove_site_favicon: true }));
    setFaviconPreview(null);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("admin.settings.update"), {
      preserveScroll: true,
      forceFormData: true
    });
  };
  const tabs = [
    { id: "general", label: "General & Logo", icon: Globe },
    { id: "colors", label: "Theme & Colors", icon: Palette },
    { id: "contact", label: "Contact & Store", icon: PhoneCall },
    { id: "social", label: "Social Media", icon: Share2 },
    { id: "footer", label: "Footer & Charges", icon: FileText }
  ];
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "Site Settings", children: [
    /* @__PURE__ */ jsx(Head, { title: "Site Settings - Admin" }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-5xl mx-auto space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-gray-200", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-black tracking-tight text-gray-900 flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsx(Settings, { className: "w-7 h-7 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Site Settings" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Customize your store branding, logo, colors, contact numbers, social media links, and footer information." })
        ] }),
        /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: handleSubmit,
            disabled: processing,
            className: "inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#EF4A23] hover:bg-[#d43e1c] text-white text-xs font-bold shadow-lg shadow-orange-500/20 disabled:opacity-50 transition shrink-0",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: processing ? "Saving Changes..." : "Save All Settings" })
            ]
          }
        )
      ] }),
      recentlySuccessful && /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in", children: [
        /* @__PURE__ */ jsx(Check, { className: "w-4 h-4 text-emerald-600" }),
        /* @__PURE__ */ jsx("span", { children: "Settings have been successfully saved and applied to your storefront!" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1.5 p-1.5 bg-white border border-gray-200 rounded-2xl shadow-sm overflow-x-auto", children: tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: () => setActiveTab(tab.id),
            className: `flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${isActive ? "bg-[#081621] text-white shadow-md" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"}`,
            children: [
              /* @__PURE__ */ jsx(Icon, { className: `w-4 h-4 ${isActive ? "text-[#EF4A23]" : "text-gray-400"}` }),
              /* @__PURE__ */ jsx("span", { children: tab.label })
            ]
          },
          tab.id
        );
      }) }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
        activeTab === "general" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900", children: "General Branding & Identity" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Site title, tagline, logo image and browser favicon." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: [
                "Site Name / Store Title ",
                /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.site_name,
                  onChange: (e) => setData("site_name", e.target.value),
                  placeholder: "e.g. Tech Shoppers",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.site_name && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.site_name })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Site Tagline" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.site_tagline,
                  onChange: (e) => setData("site_tagline", e.target.value),
                  placeholder: "e.g. Leading Computer & Laptop Shop in Bangladesh",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.site_tagline && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.site_tagline })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 pt-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/60 space-y-3", children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-800", children: "Site Logo Image" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500", children: "Recommended: PNG or SVG with transparent background, height around 40px - 60px." }),
              logoPreview ? /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsx("div", { className: "p-4 rounded-xl bg-[#081621] flex items-center justify-center border border-gray-800", children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: logoPreview,
                    alt: "Site Logo Preview",
                    className: "max-h-12 max-w-full object-contain"
                  }
                ) }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxs("label", { className: "flex-1 cursor-pointer inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-white border border-gray-300 text-gray-700 text-xs font-semibold hover:bg-gray-50 transition shadow-sm", children: [
                    /* @__PURE__ */ jsx(Upload, { className: "w-3.5 h-3.5 text-gray-500" }),
                    /* @__PURE__ */ jsx("span", { children: "Change Logo" }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "file",
                        accept: "image/*",
                        onChange: handleLogoFileChange,
                        className: "hidden"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: handleRemoveLogo,
                      className: "inline-flex items-center gap-1.5 py-2 px-3 rounded-lg bg-rose-50 text-rose-600 border border-rose-200 text-xs font-semibold hover:bg-rose-100 transition",
                      children: [
                        /* @__PURE__ */ jsx(Trash2, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsx("span", { children: "Remove" })
                      ]
                    }
                  )
                ] })
              ] }) : /* @__PURE__ */ jsxs("label", { className: "border-2 border-dashed border-gray-300 hover:border-[#EF4A23] rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer bg-white transition group", children: [
                /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-full bg-orange-50 text-[#EF4A23] flex items-center justify-center mb-2 group-hover:scale-110 transition", children: /* @__PURE__ */ jsx(Upload, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-700", children: "Click to upload logo" }),
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 mt-0.5", children: "PNG, JPG, SVG, WebP up to 3MB" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "file",
                    accept: "image/*",
                    onChange: handleLogoFileChange,
                    className: "hidden"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "pt-2", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-[11px] font-semibold text-gray-600 mb-1", children: "Or enter Logo Image URL:" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: data.site_logo_url,
                    onChange: (e) => {
                      setData("site_logo_url", e.target.value);
                      if (e.target.value) setLogoPreview(e.target.value);
                    },
                    placeholder: "https://example.com/logo.png",
                    className: "w-full text-xs px-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] }),
              errors.site_logo && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500", children: errors.site_logo })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/60 space-y-3", children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-800", children: "Browser Favicon Icon" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500", children: "Small icon shown on browser tabs (32x32px or 64x64px ICO/PNG)." }),
              faviconPreview ? /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsx("div", { className: "p-4 rounded-xl bg-white flex items-center justify-center border border-gray-200", children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: faviconPreview,
                    alt: "Favicon Preview",
                    className: "w-8 h-8 object-contain"
                  }
                ) }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxs("label", { className: "flex-1 cursor-pointer inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-white border border-gray-300 text-gray-700 text-xs font-semibold hover:bg-gray-50 transition shadow-sm", children: [
                    /* @__PURE__ */ jsx(Upload, { className: "w-3.5 h-3.5 text-gray-500" }),
                    /* @__PURE__ */ jsx("span", { children: "Change Favicon" }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "file",
                        accept: "image/*",
                        onChange: handleFaviconFileChange,
                        className: "hidden"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: handleRemoveFavicon,
                      className: "inline-flex items-center gap-1.5 py-2 px-3 rounded-lg bg-rose-50 text-rose-600 border border-rose-200 text-xs font-semibold hover:bg-rose-100 transition",
                      children: [
                        /* @__PURE__ */ jsx(Trash2, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsx("span", { children: "Remove" })
                      ]
                    }
                  )
                ] })
              ] }) : /* @__PURE__ */ jsxs("label", { className: "border-2 border-dashed border-gray-300 hover:border-[#EF4A23] rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer bg-white transition group", children: [
                /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-full bg-orange-50 text-[#EF4A23] flex items-center justify-center mb-2 group-hover:scale-110 transition", children: /* @__PURE__ */ jsx(Upload, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-700", children: "Click to upload favicon" }),
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 mt-0.5", children: "ICO, PNG up to 1MB" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "file",
                    accept: "image/*",
                    onChange: handleFaviconFileChange,
                    className: "hidden"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "pt-2", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-[11px] font-semibold text-gray-600 mb-1", children: "Or enter Favicon URL:" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: data.site_favicon_url,
                    onChange: (e) => {
                      setData("site_favicon_url", e.target.value);
                      if (e.target.value) setFaviconPreview(e.target.value);
                    },
                    placeholder: "https://example.com/favicon.ico",
                    className: "w-full text-xs px-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] }),
              errors.site_favicon && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500", children: errors.site_favicon })
            ] })
          ] })
        ] }),
        activeTab === "colors" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900", children: "Color Palette & Appearance" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Configure your brand accent color, header background, and footer background." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700", children: "Quick Brand Color Presets:" }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5", children: COLOR_PRESETS.map((preset) => /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => setData("primary_color", preset.color),
                className: `flex items-center gap-2 p-2.5 rounded-xl border text-left transition ${data.primary_color === preset.color ? "border-gray-900 bg-gray-50 ring-2 ring-gray-900/10" : "border-gray-200 hover:border-gray-300"}`,
                children: [
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: "w-5 h-5 rounded-full shrink-0 shadow-sm border border-black/10",
                      style: { backgroundColor: preset.color }
                    }
                  ),
                  /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold text-gray-800 truncate", children: preset.name })
                ]
              },
              preset.name
            )) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-5 pt-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/50 space-y-2", children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700", children: "Primary Brand Color" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500", children: "Buttons, badges, highlights, links." }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 pt-2", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "color",
                    value: data.primary_color,
                    onChange: (e) => setData("primary_color", e.target.value),
                    className: "w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent p-0"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: data.primary_color,
                    onChange: (e) => setData("primary_color", e.target.value),
                    placeholder: "#EF4A23",
                    className: "flex-1 text-xs px-3 py-2 rounded-lg border border-gray-300 uppercase font-mono"
                  }
                )
              ] }),
              errors.primary_color && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500", children: errors.primary_color })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/50 space-y-2", children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700", children: "Header & Navbar Background" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500", children: "Main navigation background." }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 pt-2", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "color",
                    value: data.header_bg_color,
                    onChange: (e) => setData("header_bg_color", e.target.value),
                    className: "w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent p-0"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: data.header_bg_color,
                    onChange: (e) => setData("header_bg_color", e.target.value),
                    placeholder: "#081621",
                    className: "flex-1 text-xs px-3 py-2 rounded-lg border border-gray-300 uppercase font-mono"
                  }
                )
              ] }),
              errors.header_bg_color && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500", children: errors.header_bg_color })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/50 space-y-2", children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700", children: "Footer Background" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500", children: "Bottom footer area background." }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 pt-2", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "color",
                    value: data.footer_bg_color,
                    onChange: (e) => setData("footer_bg_color", e.target.value),
                    className: "w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent p-0"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: data.footer_bg_color,
                    onChange: (e) => setData("footer_bg_color", e.target.value),
                    placeholder: "#081621",
                    className: "flex-1 text-xs px-3 py-2 rounded-lg border border-gray-300 uppercase font-mono"
                  }
                )
              ] }),
              errors.footer_bg_color && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500", children: errors.footer_bg_color })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-4 p-5 rounded-xl border border-gray-200 space-y-3 bg-white", children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold text-gray-400 uppercase tracking-wider block", children: "Live Preview Sample" }),
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: "p-4 rounded-xl text-white flex items-center justify-between shadow-inner",
                style: { backgroundColor: data.header_bg_color },
                children: [
                  /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: logoPreview ? /* @__PURE__ */ jsx("img", { src: logoPreview, alt: "Logo", className: "max-h-7 max-w-[120px] object-contain" }) : data.site_name ? data.site_name.includes(" ") ? /* @__PURE__ */ jsxs(Fragment, { children: [
                    /* @__PURE__ */ jsx("span", { className: "font-black text-lg", children: data.site_name.substring(0, data.site_name.lastIndexOf(" ")) }),
                    /* @__PURE__ */ jsx("span", { className: "font-black text-lg", style: { color: data.primary_color }, children: data.site_name.substring(data.site_name.lastIndexOf(" ") + 1) })
                  ] }) : /* @__PURE__ */ jsx("span", { className: "font-black text-lg", style: { color: data.primary_color }, children: data.site_name }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                    /* @__PURE__ */ jsx("span", { className: "font-black text-lg", children: "TECH" }),
                    /* @__PURE__ */ jsx("span", { className: "font-black text-lg", style: { color: data.primary_color }, children: "SHOPPERS" })
                  ] }) }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "text-xs text-gray-300", children: [
                      "Hotline: ",
                      data.hotline || "16793"
                    ] }),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        type: "button",
                        className: "px-3 py-1.5 rounded-lg text-xs font-bold text-white shadow-md",
                        style: { backgroundColor: data.primary_color },
                        children: "Buy Now"
                      }
                    )
                  ] })
                ]
              }
            )
          ] })
        ] }),
        activeTab === "contact" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900", children: "Contact & Customer Support" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Helpline numbers, physical outlet address, and operational hours." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-5", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Hotline Number" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.hotline,
                  onChange: (e) => setData("hotline", e.target.value),
                  placeholder: "16793",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.hotline && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.hotline })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-3.5 h-3.5 text-blue-500" }),
                /* @__PURE__ */ jsx("span", { children: "Store Phone Number" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.phone,
                  onChange: (e) => setData("phone", e.target.value),
                  placeholder: "09678002003",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.phone && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.phone })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-3.5 h-3.5 text-emerald-500" }),
                /* @__PURE__ */ jsx("span", { children: "WhatsApp Support Number" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.whatsapp,
                  onChange: (e) => setData("whatsapp", e.target.value),
                  placeholder: "01700000000",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.whatsapp && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.whatsapp })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Mail, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Support Email" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "email",
                  value: data.email,
                  onChange: (e) => setData("email", e.target.value),
                  placeholder: "info@techshoppers.com",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.email && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.email })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Clock, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Working / Outlet Hours" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.working_hours,
                  onChange: (e) => setData("working_hours", e.target.value),
                  placeholder: "10:00 AM - 7:00 PM (7 Days a Week)",
                  className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
                }
              ),
              errors.working_hours && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.working_hours })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("label", { className: "block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: "Head Office / Physical Address" })
            ] }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                rows: 2,
                value: data.address,
                onChange: (e) => setData("address", e.target.value),
                placeholder: "28 Kazi Nazrul Islam Avenue, Banglamotor, Dhaka 1000",
                className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
              }
            ),
            errors.address && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.address })
          ] })
        ] }),
        activeTab === "social" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900", children: "Social Media Links" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Provide official channel links displayed across the footer." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-blue-600/10 text-blue-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(FacebookIcon, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Facebook Page URL" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "url",
                    value: data.facebook_url,
                    onChange: (e) => setData("facebook_url", e.target.value),
                    placeholder: "https://facebook.com/star.tech.ltd",
                    className: "w-full text-xs px-3.5 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-red-600/10 text-red-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(YoutubeIcon, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "YouTube Channel URL" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "url",
                    value: data.youtube_url,
                    onChange: (e) => setData("youtube_url", e.target.value),
                    placeholder: "https://youtube.com/@techshoppers",
                    className: "w-full text-xs px-3.5 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-pink-600/10 text-pink-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(InstagramIcon, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Instagram Profile URL" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "url",
                    value: data.instagram_url,
                    onChange: (e) => setData("instagram_url", e.target.value),
                    placeholder: "https://instagram.com/techshoppers",
                    className: "w-full text-xs px-3.5 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(TwitterIcon, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Twitter / X Profile URL" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "url",
                    value: data.twitter_url,
                    onChange: (e) => setData("twitter_url", e.target.value),
                    placeholder: "https://x.com/techshoppers",
                    className: "w-full text-xs px-3.5 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-blue-700/10 text-blue-700 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(LinkedinIcon, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "LinkedIn Page URL" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "url",
                    value: data.linkedin_url,
                    onChange: (e) => setData("linkedin_url", e.target.value),
                    placeholder: "https://linkedin.com/company/star-tech-engineering-ltd",
                    className: "w-full text-xs px-3.5 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        activeTab === "footer" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900", children: "Footer Content & Delivery Charges" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Configure footer summary text, copyright statement, and default delivery rates." })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Footer About Text / Bio" }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                rows: 3,
                value: data.footer_about,
                onChange: (e) => setData("footer_about", e.target.value),
                placeholder: "Tech Shoppers is Bangladesh's largest Computer, Laptop & Gaming accessory retailer.",
                className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
              }
            ),
            errors.footer_about && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.footer_about })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Copyright Notice" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: data.footer_copyright,
                onChange: (e) => setData("footer_copyright", e.target.value),
                placeholder: "© 2026 Tech Shoppers | All Rights Reserved",
                className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#EF4A23]/30 focus:border-[#EF4A23]"
              }
            ),
            errors.footer_copyright && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 mt-1", children: errors.footer_copyright })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "pt-2 border-t border-gray-100", children: [
            /* @__PURE__ */ jsxs("h4", { className: "text-xs font-bold text-gray-900 mb-3 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(Truck, { className: "w-4 h-4 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: "Default Delivery Fees" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Inside Dhaka Delivery (৳)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    value: data.delivery_charge_inside,
                    onChange: (e) => setData("delivery_charge_inside", e.target.value),
                    placeholder: "60",
                    className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Outside Dhaka Delivery (৳)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    value: data.delivery_charge_outside,
                    onChange: (e) => setData("delivery_charge_outside", e.target.value),
                    placeholder: "120",
                    className: "w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#EF4A23]"
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-4 bg-white border border-gray-200 rounded-2xl shadow-sm", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500", children: "Make sure to save changes after updating any fields." }),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "submit",
              disabled: processing,
              className: "inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#EF4A23] hover:bg-[#d43e1c] text-white text-xs font-bold shadow-lg shadow-orange-500/20 disabled:opacity-50 transition",
              children: [
                /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: processing ? "Saving..." : "Save Settings" })
              ]
            }
          )
        ] })
      ] })
    ] })
  ] });
}
export {
  Index as default
};
