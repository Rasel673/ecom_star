import { jsxs, jsx } from "react/jsx-runtime";
import "react";
import { useForm } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { Truck, CreditCard, Banknote, Smartphone, ShieldCheck } from "lucide-react";
function Checkout({
  cartItems,
  cart = [],
  subtotal = 0,
  discount = 0,
  coupon = null,
  shippingInside = 60,
  shippingOutside = 120,
  user = null
}) {
  const items = cartItems || (Array.isArray(cart) ? cart : cart?.items || []);
  const { data, setData, post, processing, errors } = useForm({
    customer_name: user?.name || "",
    customer_email: user?.email || "",
    customer_phone: user?.phone || "",
    customer_address: user?.address || "",
    city: "Dhaka",
    zone: "",
    notes: "",
    payment_method: "cod"
  });
  const shippingCost = data.city === "Dhaka" ? shippingInside : shippingOutside;
  const finalTotal = Math.max(0, subtotal - discount + shippingCost);
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("checkout.store"));
  };
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: "Checkout - Complete Order", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-black text-gray-900 mb-6", children: "Checkout" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "grid grid-cols-1 lg:grid-cols-12 gap-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-8 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 border-b pb-3 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Truck, { className: "w-5 h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "1. Delivery Details" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                "Full Name ",
                /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  required: true,
                  value: data.customer_name,
                  onChange: (e) => setData("customer_name", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  placeholder: "Rahim Ahmed"
                }
              ),
              errors.customer_name && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.customer_name })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                "Phone Number ",
                /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  required: true,
                  value: data.customer_phone,
                  onChange: (e) => setData("customer_phone", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  placeholder: "017XXXXXXXX"
                }
              ),
              errors.customer_phone && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.customer_phone })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Email Address" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "email",
                  value: data.customer_email,
                  onChange: (e) => setData("customer_email", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  placeholder: "example@gmail.com"
                }
              ),
              errors.customer_email && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.customer_email })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                "City / Region ",
                /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
              ] }),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  value: data.city,
                  onChange: (e) => setData("city", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  children: [
                    /* @__PURE__ */ jsxs("option", { value: "Dhaka", children: [
                      "Inside Dhaka (৳",
                      shippingInside,
                      ")"
                    ] }),
                    /* @__PURE__ */ jsxs("option", { value: "Outside Dhaka", children: [
                      "Outside Dhaka (৳",
                      shippingOutside,
                      ")"
                    ] })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Zone / Area" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.zone,
                  onChange: (e) => setData("zone", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  placeholder: "e.g. Mirpur, Dhanmondi, Uttara"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                "Complete Delivery Address ",
                /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
              ] }),
              /* @__PURE__ */ jsx(
                "textarea",
                {
                  required: true,
                  rows: "2",
                  value: data.customer_address,
                  onChange: (e) => setData("customer_address", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  placeholder: "House, Road, Area, Landmark"
                }
              ),
              errors.customer_address && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.customer_address })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Order Notes (Optional)" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.notes,
                  onChange: (e) => setData("notes", e.target.value),
                  className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                  placeholder: "Special instructions for delivery rider..."
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 border-b pb-3 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(CreditCard, { className: "w-5 h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "2. Payment Method" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs", children: [
            /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition ${data.payment_method === "cod" ? "border-[#EF4A23] bg-orange-50/30" : "border-gray-200 hover:bg-gray-50"}`, children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "radio",
                  name: "payment_method",
                  value: "cod",
                  checked: data.payment_method === "cod",
                  onChange: () => setData("payment_method", "cod"),
                  className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900", children: [
                  /* @__PURE__ */ jsx(Banknote, { className: "w-4 h-4 text-emerald-600" }),
                  /* @__PURE__ */ jsx("span", { children: "Cash on Delivery" })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-0.5", children: "Pay in cash when you receive goods" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition ${data.payment_method === "bkash" ? "border-[#EF4A23] bg-orange-50/30" : "border-gray-200 hover:bg-gray-50"}`, children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "radio",
                  name: "payment_method",
                  value: "bkash",
                  checked: data.payment_method === "bkash",
                  onChange: () => setData("payment_method", "bkash"),
                  className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900", children: [
                  /* @__PURE__ */ jsx(Smartphone, { className: "w-4 h-4 text-pink-600" }),
                  /* @__PURE__ */ jsx("span", { children: "bKash Payment" })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-0.5", children: "Instant mobile banking payment" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition ${data.payment_method === "nagad" ? "border-[#EF4A23] bg-orange-50/30" : "border-gray-200 hover:bg-gray-50"}`, children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "radio",
                  name: "payment_method",
                  value: "nagad",
                  checked: data.payment_method === "nagad",
                  onChange: () => setData("payment_method", "nagad"),
                  className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900", children: [
                  /* @__PURE__ */ jsx(Smartphone, { className: "w-4 h-4 text-orange-600" }),
                  /* @__PURE__ */ jsx("span", { children: "Nagad Payment" })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-0.5", children: "Direct mobile payment" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition ${data.payment_method === "card" ? "border-[#EF4A23] bg-orange-50/30" : "border-gray-200 hover:bg-gray-50"}`, children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "radio",
                  name: "payment_method",
                  value: "card",
                  checked: data.payment_method === "card",
                  onChange: () => setData("payment_method", "card"),
                  className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900", children: [
                  /* @__PURE__ */ jsx(CreditCard, { className: "w-4 h-4 text-blue-600" }),
                  /* @__PURE__ */ jsx("span", { children: "Credit / Debit Card" })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-0.5", children: "Visa, Mastercard, AMEX" })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-4", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 sticky top-24 space-y-4", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900 border-b pb-3", children: "Order Overview" }),
        /* @__PURE__ */ jsx("div", { className: "space-y-3 max-h-60 overflow-y-auto pr-1", children: items.map((item) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
            /* @__PURE__ */ jsx(
              "img",
              {
                src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=60",
                alt: item.name,
                className: "w-10 h-10 object-contain rounded border p-0.5 shrink-0"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "truncate", children: [
              /* @__PURE__ */ jsx("p", { className: "font-semibold text-gray-900 truncate", children: item.name }),
              /* @__PURE__ */ jsxs("p", { className: "text-gray-400 text-[11px]", children: [
                "Qty: ",
                item.quantity
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-800 shrink-0", children: [
            "৳",
            (item.price * item.quantity).toLocaleString()
          ] })
        ] }, item.id)) }),
        /* @__PURE__ */ jsxs("div", { className: "pt-4 border-t space-y-2 text-xs text-gray-600", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Subtotal" }),
            /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-900", children: [
              "৳",
              subtotal.toLocaleString()
            ] })
          ] }),
          discount > 0 && /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-emerald-600 font-bold", children: [
            /* @__PURE__ */ jsx("span", { children: "Voucher Discount" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "-৳",
              discount.toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Delivery Fee" }),
            /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-900", children: [
              "৳",
              shippingCost
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-3 border-t flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-gray-900", children: "Final Total" }),
          /* @__PURE__ */ jsxs("span", { className: "text-2xl font-black text-[#EF4A23]", children: [
            "৳",
            finalTotal.toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "w-full bg-[#EF4A23] hover:bg-[#d63c17] disabled:opacity-50 text-white font-bold text-sm py-3.5 px-4 rounded-xl shadow-md hover:shadow-orange-500/20 transition flex items-center justify-center gap-2",
            children: /* @__PURE__ */ jsx("span", { children: processing ? "Processing Order..." : "Confirm Order" })
          }
        ),
        /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-400 text-center flex items-center justify-center gap-1", children: [
          /* @__PURE__ */ jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-600" }),
          /* @__PURE__ */ jsx("span", { children: "Safe & Secure 256-Bit SSL Checkout" })
        ] })
      ] }) })
    ] })
  ] });
}
export {
  Checkout as default
};
