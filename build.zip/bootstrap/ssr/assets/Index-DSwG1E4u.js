import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { useForm, Head, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { Sparkles, Globe, Share2, ShieldCheck, BarChart3, Layers, Terminal, Code, ArrowRightLeft, ExternalLink, CheckCircle2, AlertCircle, Eye, Laptop, Smartphone, Save, Upload, Trash2, Check, Copy, Plus } from "lucide-react";
function SeoIndex({
  settings = {},
  stats = {},
  robotsContent = "",
  redirects = [],
  sitemapUrl = "",
  robotsUrl = ""
}) {
  const [activeTab, setActiveTab] = useState("audit");
  const [previewDevice, setPreviewDevice] = useState("desktop");
  const [copiedField, setCopiedField] = useState(null);
  const [editingRedirect, setEditingRedirect] = useState(null);
  const [showRedirectModal, setShowRedirectModal] = useState(false);
  const siteName = settings?.site_name || "Tech Shoppers";
  const siteTagline = settings?.site_tagline || "Leading Computer & Laptop Shop in Bangladesh";
  const generalForm = useForm({
    seo_meta_title: settings.seo_meta_title || "",
    seo_meta_description: settings.seo_meta_description || "",
    seo_meta_keywords: settings.seo_meta_keywords || "",
    seo_author: settings.seo_author || siteName,
    seo_canonical_base: settings.seo_canonical_base || "",
    seo_robots_index: settings.seo_robots_index || "index",
    seo_robots_follow: settings.seo_robots_follow || "follow",
    seo_robots_advanced: settings.seo_robots_advanced || "max-image-preview:large"
  });
  const submitGeneral = (e) => {
    e.preventDefault();
    generalForm.post(route("admin.seo.general"), { preserveScroll: true });
  };
  const socialForm = useForm({
    seo_og_title: settings.seo_og_title || "",
    seo_og_description: settings.seo_og_description || "",
    seo_og_type: settings.seo_og_type || "website",
    seo_twitter_card: settings.seo_twitter_card || "summary_large_image",
    seo_twitter_site: settings.seo_twitter_site || "",
    seo_twitter_creator: settings.seo_twitter_creator || "",
    seo_fb_app_id: settings.seo_fb_app_id || "",
    seo_og_image_file: null,
    seo_og_image_url: settings.seo_og_image || "",
    remove_seo_og_image: false
  });
  const [ogPreview, setOgPreview] = useState(settings.seo_og_image || null);
  const handleOgFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      socialForm.setData("seo_og_image_file", file);
      socialForm.setData("remove_seo_og_image", false);
      setOgPreview(URL.createObjectURL(file));
    }
  };
  const removeOgImage = () => {
    socialForm.setData("seo_og_image_file", null);
    socialForm.setData("seo_og_image_url", "");
    socialForm.setData("remove_seo_og_image", true);
    setOgPreview(null);
  };
  const submitSocial = (e) => {
    e.preventDefault();
    socialForm.post(route("admin.seo.social"), { preserveScroll: true });
  };
  const webmasterForm = useForm({
    seo_google_verification: settings.seo_google_verification || "",
    seo_bing_verification: settings.seo_bing_verification || "",
    seo_pinterest_verification: settings.seo_pinterest_verification || "",
    seo_yandex_verification: settings.seo_yandex_verification || ""
  });
  const submitWebmaster = (e) => {
    e.preventDefault();
    webmasterForm.post(route("admin.seo.webmaster"), { preserveScroll: true });
  };
  const analyticsForm = useForm({
    seo_ga4_id: settings.seo_ga4_id || "",
    seo_gtm_id: settings.seo_gtm_id || "",
    seo_fb_pixel_id: settings.seo_fb_pixel_id || "",
    seo_custom_head_scripts: settings.seo_custom_head_scripts || "",
    seo_custom_body_scripts: settings.seo_custom_body_scripts || ""
  });
  const submitAnalytics = (e) => {
    e.preventDefault();
    analyticsForm.post(route("admin.seo.analytics"), { preserveScroll: true });
  };
  const sitemapForm = useForm({
    seo_sitemap_include_products: settings.seo_sitemap_include_products ?? "1",
    seo_sitemap_include_categories: settings.seo_sitemap_include_categories ?? "1",
    seo_sitemap_include_brands: settings.seo_sitemap_include_brands ?? "1",
    seo_sitemap_include_pages: settings.seo_sitemap_include_pages ?? "1",
    seo_sitemap_include_custom: settings.seo_sitemap_include_custom ?? "1",
    seo_sitemap_products_priority: settings.seo_sitemap_products_priority || "0.8",
    seo_sitemap_products_freq: settings.seo_sitemap_products_freq || "daily",
    seo_sitemap_categories_priority: settings.seo_sitemap_categories_priority || "0.9",
    seo_sitemap_categories_freq: settings.seo_sitemap_categories_freq || "weekly",
    seo_sitemap_pages_priority: settings.seo_sitemap_pages_priority || "0.6",
    seo_sitemap_pages_freq: settings.seo_sitemap_pages_freq || "monthly"
  });
  const submitSitemap = (e) => {
    e.preventDefault();
    sitemapForm.post(route("admin.seo.sitemap"), { preserveScroll: true });
  };
  const robotsForm = useForm({
    robots_content: robotsContent || ""
  });
  const submitRobots = (e) => {
    e.preventDefault();
    robotsForm.post(route("admin.seo.robots"), { preserveScroll: true });
  };
  const applyRobotsPreset = (preset) => {
    const origin = window.location.origin;
    if (preset === "ecommerce") {
      robotsForm.setData("robots_content", `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /cart
Disallow: /checkout
Disallow: /profile
Disallow: /dashboard
Disallow: /login
Disallow: /register

Sitemap: ${origin}/sitemap.xml`);
    } else if (preset === "allow_all") {
      robotsForm.setData("robots_content", `User-agent: *
Allow: /

Sitemap: ${origin}/sitemap.xml`);
    } else if (preset === "block_all") {
      robotsForm.setData("robots_content", `User-agent: *
Disallow: /`);
    }
  };
  const schemaForm = useForm({
    seo_schema_org_enabled: settings.seo_schema_org_enabled ?? "1",
    seo_schema_org_name: settings.seo_schema_org_name || siteName,
    seo_schema_org_logo: settings.seo_schema_org_logo || settings.site_logo || "",
    seo_schema_org_phone: settings.seo_schema_org_phone || settings.hotline || settings.phone || "",
    seo_schema_org_email: settings.seo_schema_org_email || settings.email || "",
    seo_schema_org_address: settings.seo_schema_org_address || settings.address || "",
    seo_schema_search_enabled: settings.seo_schema_search_enabled ?? "1",
    seo_schema_product_enabled: settings.seo_schema_product_enabled ?? "1",
    seo_schema_breadcrumbs_enabled: settings.seo_schema_breadcrumbs_enabled ?? "1"
  });
  const submitSchema = (e) => {
    e.preventDefault();
    schemaForm.post(route("admin.seo.schema"), { preserveScroll: true });
  };
  const redirectForm = useForm({
    source_path: "",
    target_path: "",
    status_code: "301",
    is_active: true
  });
  const handleCreateOrUpdateRedirect = (e) => {
    e.preventDefault();
    if (editingRedirect) {
      redirectForm.put(route("admin.seo.redirects.update", editingRedirect.id), {
        preserveScroll: true,
        onSuccess: () => {
          setEditingRedirect(null);
          setShowRedirectModal(false);
          redirectForm.reset();
        }
      });
    } else {
      redirectForm.post(route("admin.seo.redirects.store"), {
        preserveScroll: true,
        onSuccess: () => {
          setShowRedirectModal(false);
          redirectForm.reset();
        }
      });
    }
  };
  const startEditRedirect = (red) => {
    setEditingRedirect(red);
    redirectForm.setData({
      source_path: red.source_path,
      target_path: red.target_path,
      status_code: String(red.status_code),
      is_active: red.is_active
    });
    setShowRedirectModal(true);
  };
  const deleteRedirect = (id) => {
    if (confirm("Are you sure you want to delete this redirection rule?")) {
      router.delete(route("admin.seo.redirects.destroy", id), { preserveScroll: true });
    }
  };
  const toggleRedirect = (id) => {
    router.patch(route("admin.seo.redirects.toggle", id), {}, { preserveScroll: true });
  };
  const copyToClipboard = (text, fieldName) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2e3);
  };
  const serpTitle = generalForm.data.seo_meta_title || `${siteName} | ${siteTagline}`;
  const serpDesc = generalForm.data.seo_meta_description || `${siteName} is Bangladesh's top e-commerce platform offering best prices on laptops, gaming components, PC builds and tech gadgets.`;
  const canonicalDomain = generalForm.data.seo_canonical_base || (typeof window !== "undefined" ? window.location.origin : "https://techshoppers.com.bd");
  const tabs = [
    { id: "audit", label: "SEO Audit & Simulator", icon: Sparkles, badge: `${stats.seo_score || 0}%` },
    { id: "meta", label: "Global Meta & Robots", icon: Globe },
    { id: "social", label: "Open Graph & Social", icon: Share2 },
    { id: "webmaster", label: "Webmaster Verification", icon: ShieldCheck },
    { id: "analytics", label: "Analytics & Tracking", icon: BarChart3 },
    { id: "sitemap", label: "XML Sitemap", icon: Layers },
    { id: "robots", label: "Robots.txt Editor", icon: Terminal },
    { id: "schema", label: "Schema (JSON-LD)", icon: Code },
    { id: "redirects", label: "301 URL Redirects", icon: ArrowRightLeft, count: redirects.length }
  ];
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "SEO & Webmaster Suite", children: [
    /* @__PURE__ */ jsx(Head, { children: /* @__PURE__ */ jsx("title", { children: "SEO & Webmaster Suite | Admin" }) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-r from-[#081621] via-[#0F2438] to-[#1E3A5F] rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-gray-800", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-[#EF4A23]/20 via-transparent to-transparent pointer-events-none" }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-orange-400 text-xs font-semibold uppercase tracking-wider mb-3", children: [
              /* @__PURE__ */ jsx(Sparkles, { className: "w-3.5 h-3.5" }),
              "Comprehensive Search Engine Optimization Engine"
            ] }),
            /* @__PURE__ */ jsx("h1", { className: "text-2xl sm:text-3xl font-extrabold tracking-tight", children: "SEO Control Panel & Webmaster Suite" }),
            /* @__PURE__ */ jsx("p", { className: "text-gray-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed", children: "Complete native SEO suite replacing Rank Math & Yoast. Full control over Meta tags, XML Sitemap, Robots.txt, Open Graph, Webmaster Verification, Google Analytics 4, Tag Manager, Schema.org Structured Data, and 301 Redirections." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 bg-white/5 border border-white/10 backdrop-blur-md rounded-2xl p-4 shrink-0", children: [
            /* @__PURE__ */ jsxs("div", { className: "relative w-16 h-16 flex items-center justify-center", children: [
              /* @__PURE__ */ jsxs("svg", { className: "w-16 h-16 transform -rotate-90", children: [
                /* @__PURE__ */ jsx(
                  "circle",
                  {
                    cx: "32",
                    cy: "32",
                    r: "28",
                    stroke: "currentColor",
                    strokeWidth: "6",
                    className: "text-white/10",
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "circle",
                  {
                    cx: "32",
                    cy: "32",
                    r: "28",
                    stroke: "currentColor",
                    strokeWidth: "6",
                    strokeDasharray: 2 * Math.PI * 28,
                    strokeDashoffset: 2 * Math.PI * 28 * (1 - (stats.seo_score || 0) / 100),
                    strokeLinecap: "round",
                    className: stats.seo_score >= 80 ? "text-emerald-400" : stats.seo_score >= 50 ? "text-amber-400" : "text-rose-400",
                    fill: "transparent"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("span", { className: "absolute text-sm font-black text-white", children: [
                stats.seo_score || 0,
                "%"
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "text-xs uppercase font-bold text-gray-400", children: "SEO Health Score" }),
              /* @__PURE__ */ jsx("div", { className: "text-sm font-bold text-white mt-0.5", children: stats.seo_score >= 80 ? "Optimized" : stats.seo_score >= 50 ? "Good Progress" : "Needs Setup" }),
              /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400 mt-0.5", children: [
                stats.products_with_meta,
                " of ",
                stats.total_products,
                " products indexed"
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 pt-5 border-t border-white/10 flex flex-wrap items-center gap-3 text-xs", children: [
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: sitemapUrl,
              target: "_blank",
              rel: "noreferrer",
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg transition font-medium",
              children: [
                /* @__PURE__ */ jsx(Layers, { className: "w-3.5 h-3.5 text-orange-400" }),
                "View sitemap.xml",
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3 text-gray-400" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: robotsUrl,
              target: "_blank",
              rel: "noreferrer",
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg transition font-medium",
              children: [
                /* @__PURE__ */ jsx(Terminal, { className: "w-3.5 h-3.5 text-blue-400" }),
                "View robots.txt",
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3 text-gray-400" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: `https://search.google.com/test/rich-results?url=${encodeURIComponent(canonicalDomain)}`,
              target: "_blank",
              rel: "noreferrer",
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg transition font-medium",
              children: [
                /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400" }),
                "Google Rich Results Test",
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3 text-gray-400" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: `https://developers.facebook.com/tools/debug/?q=${encodeURIComponent(canonicalDomain)}`,
              target: "_blank",
              rel: "noreferrer",
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg transition font-medium",
              children: [
                /* @__PURE__ */ jsx(Share2, { className: "w-3.5 h-3.5 text-sky-400" }),
                "Facebook Sharing Debugger",
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3 text-gray-400" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: `https://pagespeed.web.dev/report?url=${encodeURIComponent(canonicalDomain)}`,
              target: "_blank",
              rel: "noreferrer",
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg transition font-medium",
              children: [
                /* @__PURE__ */ jsx(BarChart3, { className: "w-3.5 h-3.5 text-amber-400" }),
                "PageSpeed Insights",
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3 text-gray-400" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-2 overflow-x-auto", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 min-w-max", children: tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return /* @__PURE__ */ jsxs(
          "button",
          {
            onClick: () => setActiveTab(tab.id),
            className: `flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition ${isActive ? "bg-[#081621] text-white shadow" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"}`,
            children: [
              /* @__PURE__ */ jsx(Icon, { className: `w-4 h-4 ${isActive ? "text-[#EF4A23]" : "text-gray-400"}` }),
              /* @__PURE__ */ jsx("span", { children: tab.label }),
              tab.badge && /* @__PURE__ */ jsx("span", { className: `text-[10px] px-1.5 py-0.5 rounded-full font-bold ${isActive ? "bg-[#EF4A23] text-white" : "bg-gray-100 text-gray-700"}`, children: tab.badge }),
              tab.count !== void 0 && /* @__PURE__ */ jsx("span", { className: `text-[10px] px-1.5 py-0.5 rounded-full font-bold ${isActive ? "bg-white/20 text-white" : "bg-gray-200 text-gray-700"}`, children: tab.count })
            ]
          },
          tab.id
        );
      }) }) }),
      activeTab === "audit" && /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200 shadow-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "text-xs text-gray-500 font-medium", children: "Catalog Products" }),
            /* @__PURE__ */ jsx("div", { className: "text-2xl font-black text-gray-900 mt-1", children: stats.total_products || 0 }),
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5" }),
              stats.products_with_meta,
              " with custom SEO tags"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200 shadow-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "text-xs text-gray-500 font-medium", children: "Categories Indexed" }),
            /* @__PURE__ */ jsx("div", { className: "text-2xl font-black text-gray-900 mt-1", children: stats.total_categories || 0 }),
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-blue-600 font-semibold mt-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5" }),
              stats.categories_with_meta,
              " configured"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200 shadow-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "text-xs text-gray-500 font-medium", children: "CMS Pages & Brands" }),
            /* @__PURE__ */ jsx("div", { className: "text-2xl font-black text-gray-900 mt-1", children: (stats.total_pages || 0) + (stats.total_brands || 0) }),
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-purple-600 font-semibold mt-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsx(Globe, { className: "w-3.5 h-3.5" }),
              "Dynamic in sitemap.xml"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200 shadow-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "text-xs text-gray-500 font-medium", children: "Active 301 Redirects" }),
            /* @__PURE__ */ jsx("div", { className: "text-2xl font-black text-[#EF4A23] mt-1", children: stats.total_redirects || 0 }),
            /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-500 font-semibold mt-1", children: "Protecting SEO backlinks" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2 mb-4", children: [
            /* @__PURE__ */ jsx(ShieldCheck, { className: "w-5 h-5 text-emerald-600" }),
            "Automated Technical SEO Audit Checklist"
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3.5", children: [
            { key: "meta_title", title: "Global Meta Title Configured", desc: "Provides the search snippet title for your homepage and fallbacks." },
            { key: "meta_description", title: "Global Meta Description Provided", desc: "Increases click-through rate (CTR) on Google search result pages." },
            { key: "og_image", title: "Social Share Image (OG Image) Active", desc: "Ensures rich image previews when shared on Facebook, WhatsApp & LinkedIn." },
            { key: "google_verification", title: "Google Search Console Verification", desc: "Verifies domain ownership in Google Search Console for ranking reports." },
            { key: "analytics_tracking", title: "Google Analytics 4 / GTM Connected", desc: "Tracks traffic, conversion rates, ecommerce transactions, and bounce rates." },
            { key: "robots_txt", title: "Robots.txt Directives Functional", desc: "Instructs search spiders which directories are allowed or disallowed." },
            { key: "schema_org", title: "Schema.org JSON-LD Structured Data", desc: "Enables Google Rich Results, Organization knowledge graph & product snippets." },
            { key: "sitemap_active", title: "Dynamic XML Sitemap Active", desc: "Automatically feeds new products and categories to search crawlers." }
          ].map((chk, i) => {
            const passed = stats.audit_checks?.[chk.key];
            return /* @__PURE__ */ jsxs(
              "div",
              {
                className: `flex items-start gap-3 p-3.5 rounded-xl border transition ${passed ? "bg-emerald-50/50 border-emerald-200" : "bg-rose-50/50 border-rose-200"}`,
                children: [
                  passed ? /* @__PURE__ */ jsx(CheckCircle2, { className: "w-5 h-5 text-emerald-600 shrink-0 mt-0.5" }) : /* @__PURE__ */ jsx(AlertCircle, { className: "w-5 h-5 text-rose-600 shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsxs("div", { className: "text-xs font-bold text-gray-900 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsx("span", { children: chk.title }),
                      /* @__PURE__ */ jsx("span", { className: `text-[10px] font-bold px-1.5 py-0.2 rounded ${passed ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`, children: passed ? "Passed" : "Action Required" })
                    ] }),
                    /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-600 mt-0.5 leading-snug", children: chk.desc })
                  ] })
                ]
              },
              i
            );
          }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(Eye, { className: "w-5 h-5 text-blue-600" }),
                "Live Google SERP Simulator (Desktop & Mobile)"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "This is how your website snippet currently looks in Google Search results." })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 bg-gray-100 p-1 rounded-xl text-xs font-semibold", children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  onClick: () => setPreviewDevice("desktop"),
                  className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${previewDevice === "desktop" ? "bg-white shadow text-gray-900" : "text-gray-500 hover:text-gray-900"}`,
                  children: [
                    /* @__PURE__ */ jsx(Laptop, { className: "w-3.5 h-3.5" }),
                    "Desktop"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                "button",
                {
                  onClick: () => setPreviewDevice("mobile"),
                  className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${previewDevice === "mobile" ? "bg-white shadow text-gray-900" : "text-gray-500 hover:text-gray-900"}`,
                  children: [
                    /* @__PURE__ */ jsx(Smartphone, { className: "w-3.5 h-3.5" }),
                    "Mobile"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "max-w-2xl bg-white p-4 sm:p-6 rounded-2xl border border-gray-200 font-sans shadow-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 mb-2 text-xs text-gray-700", children: [
              /* @__PURE__ */ jsx("div", { className: "w-7 h-7 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center font-black text-xs text-orange-600", children: settings.site_logo ? /* @__PURE__ */ jsx("img", { src: settings.site_logo, alt: siteName, className: "w-4 h-4 object-contain" }) : "TS" }),
              /* @__PURE__ */ jsxs("div", { className: "truncate", children: [
                /* @__PURE__ */ jsx("div", { className: "font-semibold text-gray-900 text-xs", children: siteName }),
                /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-500 truncate", children: canonicalDomain })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "a",
              {
                href: canonicalDomain,
                target: "_blank",
                rel: "noreferrer",
                className: "text-lg sm:text-xl font-medium text-[#1a0dab] hover:underline cursor-pointer block leading-tight truncate",
                children: serpTitle
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-xs sm:text-sm text-[#4d5156] mt-1.5 leading-relaxed line-clamp-2", children: serpDesc })
          ] })
        ] })
      ] }),
      activeTab === "meta" && /* @__PURE__ */ jsxs("form", { onSubmit: submitGeneral, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900", children: "Global Meta Tags & Canonical Directives" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Control the default title format, descriptions, keywords and search crawler indexing rules." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Global Meta Title / Homepage Title" }),
              /* @__PURE__ */ jsxs("span", { className: `text-[11px] font-semibold ${generalForm.data.seo_meta_title.length > 60 ? "text-amber-600" : "text-emerald-600"}`, children: [
                generalForm.data.seo_meta_title.length,
                " / 60 optimal chars"
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: generalForm.data.seo_meta_title,
                onChange: (e) => generalForm.setData("seo_meta_title", e.target.value),
                placeholder: "e.g. Tech Shoppers | Leading Computer, Laptop & Component Shop in Bangladesh",
                className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Recommended length: 50-60 characters. Appears as the headline in Google search results." })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Global Meta Description" }),
              /* @__PURE__ */ jsxs("span", { className: `text-[11px] font-semibold ${generalForm.data.seo_meta_description.length > 160 ? "text-amber-600" : "text-emerald-600"}`, children: [
                generalForm.data.seo_meta_description.length,
                " / 160 optimal chars"
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                rows: "3",
                value: generalForm.data.seo_meta_description,
                onChange: (e) => generalForm.setData("seo_meta_description", e.target.value),
                placeholder: "e.g. Buy Desktop PC, Laptop, Gaming Component, Monitor, Graphics Card, Processor at best price in Bangladesh from Tech Shoppers with official warranty.",
                className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Optimal length: 140-160 characters. Provide a compelling call-to-action to maximize search click-throughs." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Meta Keywords (Comma separated)" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: generalForm.data.seo_meta_keywords,
                  onChange: (e) => generalForm.setData("seo_meta_keywords", e.target.value),
                  placeholder: "computer shop bd, gaming pc, laptop price in bangladesh, star tech, ryzen processor",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Author / Publisher Name" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: generalForm.data.seo_author,
                  onChange: (e) => generalForm.setData("seo_author", e.target.value),
                  placeholder: "Tech Shoppers Limited",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Canonical URL Base Domain" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "url",
                value: generalForm.data.seo_canonical_base,
                onChange: (e) => generalForm.setData("seo_canonical_base", e.target.value),
                placeholder: "https://techshoppers.com.bd (leave blank for automatic current domain)",
                className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Prevents duplicate content penalties by indicating the primary canonical domain." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border-t border-gray-100 pt-5 space-y-4", children: [
          /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Terminal, { className: "w-4 h-4 text-orange-600" }),
            "Robots Meta Tag Settings"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-xl border border-gray-200", children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-800 block mb-2", children: "Search Engine Indexing" }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer", children: [
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "radio",
                      name: "seo_robots_index",
                      value: "index",
                      checked: generalForm.data.seo_robots_index === "index",
                      onChange: (e) => generalForm.setData("seo_robots_index", e.target.value),
                      className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                    }
                  ),
                  /* @__PURE__ */ jsxs("span", { children: [
                    /* @__PURE__ */ jsx("strong", { children: "Index:" }),
                    " Allow search engines to index this site (Recommended)"
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-medium text-rose-700 cursor-pointer", children: [
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "radio",
                      name: "seo_robots_index",
                      value: "noindex",
                      checked: generalForm.data.seo_robots_index === "noindex",
                      onChange: (e) => generalForm.setData("seo_robots_index", e.target.value),
                      className: "text-rose-600 focus:ring-rose-600"
                    }
                  ),
                  /* @__PURE__ */ jsxs("span", { children: [
                    /* @__PURE__ */ jsx("strong", { children: "Noindex:" }),
                    " Block search engines (Staging / Development only!)"
                  ] })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-xl border border-gray-200", children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-800 block mb-2", children: "Link Following" }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer", children: [
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "radio",
                      name: "seo_robots_follow",
                      value: "follow",
                      checked: generalForm.data.seo_robots_follow === "follow",
                      onChange: (e) => generalForm.setData("seo_robots_follow", e.target.value),
                      className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                    }
                  ),
                  /* @__PURE__ */ jsxs("span", { children: [
                    /* @__PURE__ */ jsx("strong", { children: "Follow:" }),
                    " Crawl links on this site (Recommended)"
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer", children: [
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "radio",
                      name: "seo_robots_follow",
                      value: "nofollow",
                      checked: generalForm.data.seo_robots_follow === "nofollow",
                      onChange: (e) => generalForm.setData("seo_robots_follow", e.target.value),
                      className: "text-[#EF4A23] focus:ring-[#EF4A23]"
                    }
                  ),
                  /* @__PURE__ */ jsxs("span", { children: [
                    /* @__PURE__ */ jsx("strong", { children: "Nofollow:" }),
                    " Do not pass link equity / follow links"
                  ] })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Advanced Robots Directives" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: generalForm.data.seo_robots_advanced,
                onChange: (e) => generalForm.setData("seo_robots_advanced", e.target.value),
                placeholder: "max-image-preview:large, max-snippet:-1, max-video-preview:-1",
                className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-500 mt-1", children: [
              /* @__PURE__ */ jsx("code", { children: "max-image-preview:large" }),
              " enables Google Discover large card previews, boosting mobile organic reach."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: generalForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              generalForm.processing ? "Saving Changes..." : "Save Meta Settings"
            ]
          }
        ) })
      ] }),
      activeTab === "social" && /* @__PURE__ */ jsxs("form", { onSubmit: submitSocial, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900", children: "Social Media & Open Graph Previews" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Control how your website appears when shared on Facebook, WhatsApp, Twitter (X), Telegram and LinkedIn." })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-2", children: "Default Social Share Image (Open Graph Image)" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-12 gap-6 items-start", children: [
            /* @__PURE__ */ jsxs("div", { className: "md:col-span-7 space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-semibold rounded-xl cursor-pointer border border-gray-300 transition", children: [
                  /* @__PURE__ */ jsx(Upload, { className: "w-4 h-4 text-orange-600" }),
                  "Upload High-Res OG Image",
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      onChange: handleOgFileChange,
                      className: "hidden"
                    }
                  )
                ] }),
                ogPreview && /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: removeOgImage,
                    className: "flex items-center gap-1.5 px-3 py-2 text-rose-600 hover:bg-rose-50 text-xs font-semibold rounded-xl transition",
                    children: [
                      /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" }),
                      "Remove Image"
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-[11px] text-gray-500 font-semibold mb-1", children: "Or Direct Image URL:" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: socialForm.data.seo_og_image_url,
                    onChange: (e) => {
                      socialForm.setData("seo_og_image_url", e.target.value);
                      setOgPreview(e.target.value);
                    },
                    placeholder: "https://example.com/assets/banner-og.jpg",
                    className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-500", children: [
                "Optimal dimensions: ",
                /* @__PURE__ */ jsx("strong", { children: "1200 x 630 pixels" }),
                " (Aspect ratio 1.91:1). Recommended format: PNG or WebP under 2MB."
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "md:col-span-5 bg-gray-50 p-3 rounded-2xl border border-gray-200", children: [
              /* @__PURE__ */ jsx("div", { className: "text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2", children: "Live Facebook / WhatsApp Preview" }),
              /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-xl overflow-hidden border border-gray-200 shadow-sm", children: [
                /* @__PURE__ */ jsx("div", { className: "h-36 bg-gray-200 flex items-center justify-center overflow-hidden", children: ogPreview ? /* @__PURE__ */ jsx("img", { src: ogPreview, alt: "OG Preview", className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxs("div", { className: "text-gray-400 text-xs font-semibold flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsx(Share2, { className: "w-4 h-4" }),
                  "No OG Image Uploaded"
                ] }) }),
                /* @__PURE__ */ jsxs("div", { className: "p-3", children: [
                  /* @__PURE__ */ jsx("div", { className: "text-[10px] text-gray-400 uppercase font-bold truncate", children: canonicalDomain }),
                  /* @__PURE__ */ jsx("div", { className: "text-xs font-bold text-gray-900 mt-0.5 truncate", children: socialForm.data.seo_og_title || siteName }),
                  /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-500 mt-1 line-clamp-2", children: socialForm.data.seo_og_description || siteTagline })
                ] })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Open Graph Title (Leave empty to use Meta Title)" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: socialForm.data.seo_og_title,
                onChange: (e) => socialForm.setData("seo_og_title", e.target.value),
                placeholder: siteName,
                className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Open Graph Description" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: socialForm.data.seo_og_description,
                onChange: (e) => socialForm.setData("seo_og_description", e.target.value),
                placeholder: siteTagline,
                className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border-t border-gray-100 pt-5 space-y-4", children: [
          /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: "Twitter (X) Card Details" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Twitter Card Type" }),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  value: socialForm.data.seo_twitter_card,
                  onChange: (e) => socialForm.setData("seo_twitter_card", e.target.value),
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]",
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "summary_large_image", children: "Summary with Large Image (Recommended)" }),
                    /* @__PURE__ */ jsx("option", { value: "summary", children: "Summary Small Square" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Twitter Site Handle" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: socialForm.data.seo_twitter_site,
                  onChange: (e) => socialForm.setData("seo_twitter_site", e.target.value),
                  placeholder: "@TechShoppersBD",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Facebook App ID" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: socialForm.data.seo_fb_app_id,
                  onChange: (e) => socialForm.setData("seo_fb_app_id", e.target.value),
                  placeholder: "e.g. 102938475619283",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: socialForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              socialForm.processing ? "Saving..." : "Save Social Settings"
            ]
          }
        ) })
      ] }),
      activeTab === "webmaster" && /* @__PURE__ */ jsxs("form", { onSubmit: submitWebmaster, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900", children: "Search Engine Webmaster Verification" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Add meta verification codes to verify ownership in Google Search Console, Bing Webmaster, Pinterest and Yandex." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 hover:border-gray-300 transition", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("span", { className: "w-5 h-5 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs", children: "G" }),
                "Google Search Console Verification"
              ] }),
              /* @__PURE__ */ jsxs(
                "a",
                {
                  href: "https://search.google.com/search-console",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "text-[11px] text-blue-600 hover:underline flex items-center gap-1 font-semibold",
                  children: [
                    "Open Google Search Console ",
                    /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: webmasterForm.data.seo_google_verification,
                onChange: (e) => webmasterForm.setData("seo_google_verification", e.target.value),
                placeholder: 'Paste verification code or full tag e.g. <meta name="google-site-verification" content="xyz...">',
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: 'Choose "HTML tag" verification method in Google Search Console and paste the code here.' })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 hover:border-gray-300 transition", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("span", { className: "w-5 h-5 rounded-full bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold text-xs", children: "B" }),
                "Bing & Yahoo Webmaster Tools (msvalidate.01)"
              ] }),
              /* @__PURE__ */ jsxs(
                "a",
                {
                  href: "https://www.bing.com/webmasters",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "text-[11px] text-cyan-600 hover:underline flex items-center gap-1 font-semibold",
                  children: [
                    "Open Bing Webmasters ",
                    /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: webmasterForm.data.seo_bing_verification,
                onChange: (e) => webmasterForm.setData("seo_bing_verification", e.target.value),
                placeholder: "e.g. 74E23C623485ABC098901234...",
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 hover:border-gray-300 transition", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("span", { className: "w-5 h-5 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center font-bold text-xs", children: "P" }),
                "Pinterest Domain Verification (p:domain_verify)"
              ] }),
              /* @__PURE__ */ jsxs(
                "a",
                {
                  href: "https://www.pinterest.com/settings/claim",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "text-[11px] text-rose-600 hover:underline flex items-center gap-1 font-semibold",
                  children: [
                    "Claim on Pinterest ",
                    /* @__PURE__ */ jsx(ExternalLink, { className: "w-3 h-3" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: webmasterForm.data.seo_pinterest_verification,
                onChange: (e) => webmasterForm.setData("seo_pinterest_verification", e.target.value),
                placeholder: "e.g. a87dfb6a78c909e782bc4...",
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 hover:border-gray-300 transition", children: [
            /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between mb-1.5", children: /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx("span", { className: "w-5 h-5 rounded-full bg-red-50 text-red-600 flex items-center justify-center font-bold text-xs", children: "Y" }),
              "Yandex Webmaster Verification"
            ] }) }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: webmasterForm.data.seo_yandex_verification,
                onChange: (e) => webmasterForm.setData("seo_yandex_verification", e.target.value),
                placeholder: "e.g. 5a1b3c4d5e6f...",
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: webmasterForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              webmasterForm.processing ? "Verifying..." : "Save Verification Codes"
            ]
          }
        ) })
      ] }),
      activeTab === "analytics" && /* @__PURE__ */ jsxs("form", { onSubmit: submitAnalytics, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900", children: "Analytics, Tracking & Custom Scripts" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Seamlessly inject Google Analytics 4, Tag Manager, Facebook Pixel and custom head/body tracking scripts." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Google Analytics 4 Measurement ID" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: analyticsForm.data.seo_ga4_id,
                onChange: (e) => analyticsForm.setData("seo_ga4_id", e.target.value),
                placeholder: "G-XXXXXXXXXX",
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Automatic gtag.js script injection." })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Google Tag Manager (GTM) Container ID" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: analyticsForm.data.seo_gtm_id,
                onChange: (e) => analyticsForm.setData("seo_gtm_id", e.target.value),
                placeholder: "GTM-XXXXXXX",
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Injected in <head> and <noscript> body." })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Facebook (Meta) Pixel ID" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: analyticsForm.data.seo_fb_pixel_id,
                onChange: (e) => analyticsForm.setData("seo_fb_pixel_id", e.target.value),
                placeholder: "e.g. 123456789012345",
                className: "w-full text-xs font-mono font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23] focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Fires standard PageView events." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4 border-t border-gray-100 pt-5", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-900 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Code, { className: "w-4 h-4 text-purple-600" }),
                "Custom Header Scripts (<head> injection)"
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 font-mono", children: "Raw HTML / JavaScript" })
            ] }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                rows: "4",
                value: analyticsForm.data.seo_custom_head_scripts,
                onChange: (e) => analyticsForm.setData("seo_custom_head_scripts", e.target.value),
                placeholder: "<!-- Paste custom verification, Hotjar, Clarity or custom meta tags here -->",
                className: "w-full text-xs font-mono bg-gray-900 text-emerald-400 border-gray-800 rounded-xl p-3 focus:ring-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-900 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Code, { className: "w-4 h-4 text-blue-600" }),
                "Custom Body / Footer Scripts (before </body>)"
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 font-mono", children: "Raw HTML / JavaScript" })
            ] }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                rows: "4",
                value: analyticsForm.data.seo_custom_body_scripts,
                onChange: (e) => analyticsForm.setData("seo_custom_body_scripts", e.target.value),
                placeholder: "<!-- Paste live chat widget, Tawk.to, WhatsApp popups or conversion tracking scripts here -->",
                className: "w-full text-xs font-mono bg-gray-900 text-emerald-400 border-gray-800 rounded-xl p-3 focus:ring-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: analyticsForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              analyticsForm.processing ? "Saving..." : "Save Tracking Scripts"
            ]
          }
        ) })
      ] }),
      activeTab === "sitemap" && /* @__PURE__ */ jsxs("form", { onSubmit: submitSitemap, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Layers, { className: "w-5 h-5 text-orange-600" }),
              "XML Sitemap Configuration"
            ] }),
            /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 mt-0.5", children: [
              "Generated real-time at ",
              /* @__PURE__ */ jsx("code", { children: "/sitemap.xml" }),
              " following standard sitemaps.org XML protocol."
            ] })
          ] }),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: sitemapUrl,
              target: "_blank",
              rel: "noreferrer",
              className: "inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow transition shrink-0",
              children: [
                "Open Live XML Sitemap ",
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3.5 h-3.5" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsx("div", { className: "text-xs font-bold text-gray-800 uppercase tracking-wider", children: "Include Post Types & Models" }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border border-gray-200 bg-gray-50/50", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  id: "chk_prod",
                  checked: sitemapForm.data.seo_sitemap_include_products === "1",
                  onChange: (e) => sitemapForm.setData("seo_sitemap_include_products", e.target.checked ? "1" : "0"),
                  className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("label", { htmlFor: "chk_prod", className: "cursor-pointer", children: [
                /* @__PURE__ */ jsxs("div", { className: "text-xs font-bold text-gray-900", children: [
                  "Products (",
                  stats.total_products || 0,
                  " items)"
                ] }),
                /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-500", children: "Includes active product pages with lastmod date." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] text-gray-500 font-bold block mb-1", children: "Priority" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sitemapForm.data.seo_sitemap_products_priority,
                    onChange: (e) => sitemapForm.setData("seo_sitemap_products_priority", e.target.value),
                    className: "text-xs font-semibold rounded-lg border-gray-300 py-1",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "1.0", children: "1.0 (Highest)" }),
                      /* @__PURE__ */ jsx("option", { value: "0.9", children: "0.9" }),
                      /* @__PURE__ */ jsx("option", { value: "0.8", children: "0.8 (Default)" }),
                      /* @__PURE__ */ jsx("option", { value: "0.7", children: "0.7" }),
                      /* @__PURE__ */ jsx("option", { value: "0.5", children: "0.5" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] text-gray-500 font-bold block mb-1", children: "Frequency" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sitemapForm.data.seo_sitemap_products_freq,
                    onChange: (e) => sitemapForm.setData("seo_sitemap_products_freq", e.target.value),
                    className: "text-xs font-semibold rounded-lg border-gray-300 py-1",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "hourly", children: "Hourly" }),
                      /* @__PURE__ */ jsx("option", { value: "daily", children: "Daily" }),
                      /* @__PURE__ */ jsx("option", { value: "weekly", children: "Weekly" }),
                      /* @__PURE__ */ jsx("option", { value: "monthly", children: "Monthly" })
                    ]
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border border-gray-200 bg-gray-50/50", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  id: "chk_cat",
                  checked: sitemapForm.data.seo_sitemap_include_categories === "1",
                  onChange: (e) => sitemapForm.setData("seo_sitemap_include_categories", e.target.checked ? "1" : "0"),
                  className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("label", { htmlFor: "chk_cat", className: "cursor-pointer", children: [
                /* @__PURE__ */ jsxs("div", { className: "text-xs font-bold text-gray-900", children: [
                  "Categories & Subcategories (",
                  stats.total_categories || 0,
                  " items)"
                ] }),
                /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-500", children: "Crucial for ranking high-volume category search queries." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] text-gray-500 font-bold block mb-1", children: "Priority" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sitemapForm.data.seo_sitemap_categories_priority,
                    onChange: (e) => sitemapForm.setData("seo_sitemap_categories_priority", e.target.value),
                    className: "text-xs font-semibold rounded-lg border-gray-300 py-1",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "1.0", children: "1.0" }),
                      /* @__PURE__ */ jsx("option", { value: "0.9", children: "0.9 (Default)" }),
                      /* @__PURE__ */ jsx("option", { value: "0.8", children: "0.8" }),
                      /* @__PURE__ */ jsx("option", { value: "0.7", children: "0.7" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] text-gray-500 font-bold block mb-1", children: "Frequency" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sitemapForm.data.seo_sitemap_categories_freq,
                    onChange: (e) => sitemapForm.setData("seo_sitemap_categories_freq", e.target.value),
                    className: "text-xs font-semibold rounded-lg border-gray-300 py-1",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "daily", children: "Daily" }),
                      /* @__PURE__ */ jsx("option", { value: "weekly", children: "Weekly" }),
                      /* @__PURE__ */ jsx("option", { value: "monthly", children: "Monthly" })
                    ]
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border border-gray-200 bg-gray-50/50", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  id: "chk_pages",
                  checked: sitemapForm.data.seo_sitemap_include_pages === "1",
                  onChange: (e) => sitemapForm.setData("seo_sitemap_include_pages", e.target.checked ? "1" : "0"),
                  className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsxs("label", { htmlFor: "chk_pages", className: "cursor-pointer", children: [
                /* @__PURE__ */ jsxs("div", { className: "text-xs font-bold text-gray-900", children: [
                  "CMS Dynamic Pages (",
                  stats.total_pages || 0,
                  " pages)"
                ] }),
                /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-500", children: "Terms, About Us, Privacy Policy, EMI guide, etc." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] text-gray-500 font-bold block mb-1", children: "Priority" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sitemapForm.data.seo_sitemap_pages_priority,
                    onChange: (e) => sitemapForm.setData("seo_sitemap_pages_priority", e.target.value),
                    className: "text-xs font-semibold rounded-lg border-gray-300 py-1",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "0.7", children: "0.7" }),
                      /* @__PURE__ */ jsx("option", { value: "0.6", children: "0.6 (Default)" }),
                      /* @__PURE__ */ jsx("option", { value: "0.5", children: "0.5" }),
                      /* @__PURE__ */ jsx("option", { value: "0.3", children: "0.3" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] text-gray-500 font-bold block mb-1", children: "Frequency" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sitemapForm.data.seo_sitemap_pages_freq,
                    onChange: (e) => sitemapForm.setData("seo_sitemap_pages_freq", e.target.value),
                    className: "text-xs font-semibold rounded-lg border-gray-300 py-1",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "weekly", children: "Weekly" }),
                      /* @__PURE__ */ jsx("option", { value: "monthly", children: "Monthly" })
                    ]
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: sitemapForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              sitemapForm.processing ? "Saving..." : "Save Sitemap Settings"
            ]
          }
        ) })
      ] }),
      activeTab === "robots" && /* @__PURE__ */ jsxs("form", { onSubmit: submitRobots, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Terminal, { className: "w-5 h-5 text-gray-800" }),
              "Live Robots.txt File Editor"
            ] }),
            /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 mt-0.5", children: [
              "Changes are written directly to ",
              /* @__PURE__ */ jsx("code", { children: "public/robots.txt" }),
              " and served live to web crawlers."
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-500", children: "Presets:" }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => applyRobotsPreset("ecommerce"),
                className: "px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-semibold rounded-lg transition",
                children: "E-Commerce Standard"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => applyRobotsPreset("allow_all"),
                className: "px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-lg transition",
                children: "Allow All"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => applyRobotsPreset("block_all"),
                className: "px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-semibold rounded-lg transition",
                children: "Block All"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            "textarea",
            {
              rows: "12",
              value: robotsForm.data.robots_content,
              onChange: (e) => robotsForm.setData("robots_content", e.target.value),
              className: "w-full text-xs font-mono bg-gray-950 text-gray-200 border border-gray-800 rounded-xl p-4 focus:ring-[#EF4A23] leading-relaxed"
            }
          ),
          /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-500 mt-2", children: [
            "Tip: Keep ",
            /* @__PURE__ */ jsx("code", { children: "Disallow: /admin/" }),
            ", ",
            /* @__PURE__ */ jsx("code", { children: "Disallow: /cart" }),
            " and ",
            /* @__PURE__ */ jsx("code", { children: "Disallow: /checkout" }),
            " to prevent wasting crawl budget on private transactional routes."
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: robotsForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              robotsForm.processing ? "Writing File..." : "Save & Publish robots.txt"
            ]
          }
        ) })
      ] }),
      activeTab === "schema" && /* @__PURE__ */ jsxs("form", { onSubmit: submitSchema, className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Code, { className: "w-5 h-5 text-indigo-600" }),
            "Schema.org Structured Data (Rich Snippets)"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Google uses Schema markup to show price ranges, review stars, stock status, sitelinks search box, and business knowledge panels." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/50", children: [
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-bold text-gray-900 cursor-pointer", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  checked: schemaForm.data.seo_schema_org_enabled === "1",
                  onChange: (e) => schemaForm.setData("seo_schema_org_enabled", e.target.checked ? "1" : "0"),
                  className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsx("span", { children: "Organization Schema" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Company logo, contact numbers and social profiles." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/50", children: [
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-bold text-gray-900 cursor-pointer", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  checked: schemaForm.data.seo_schema_search_enabled === "1",
                  onChange: (e) => schemaForm.setData("seo_schema_search_enabled", e.target.checked ? "1" : "0"),
                  className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsx("span", { children: "Sitelinks SearchBox Schema" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Enables direct store search box in Google SERPs." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 rounded-xl border border-gray-200 bg-gray-50/50", children: [
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-bold text-gray-900 cursor-pointer", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  checked: schemaForm.data.seo_schema_product_enabled === "1",
                  onChange: (e) => schemaForm.setData("seo_schema_product_enabled", e.target.checked ? "1" : "0"),
                  className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsx("span", { children: "Product Rich Snippets" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 mt-1", children: "Outputs BDT price, stock status, ratings and brand." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4 border-t border-gray-100 pt-5", children: [
          /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: "Organization Knowledge Graph Details" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Legal Business Name" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: schemaForm.data.seo_schema_org_name,
                  onChange: (e) => schemaForm.setData("seo_schema_org_name", e.target.value),
                  placeholder: "Tech Shoppers Ltd",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Support Hotline" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: schemaForm.data.seo_schema_org_phone,
                  onChange: (e) => schemaForm.setData("seo_schema_org_phone", e.target.value),
                  placeholder: "+8801700000000",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Official Email" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "email",
                  value: schemaForm.data.seo_schema_org_email,
                  onChange: (e) => schemaForm.setData("seo_schema_org_email", e.target.value),
                  placeholder: "support@techshoppers.com.bd",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", children: "Physical Store Address" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: schemaForm.data.seo_schema_org_address,
                  onChange: (e) => schemaForm.setData("seo_schema_org_address", e.target.value),
                  placeholder: "Level 4, Multiplan Center, Elephant Road, Dhaka",
                  className: "w-full text-xs font-medium border-gray-300 rounded-xl focus:ring-[#EF4A23]"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border-t border-gray-100 pt-5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-2", children: [
            /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-800 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(Terminal, { className: "w-4 h-4 text-emerald-600" }),
              "Active JSON-LD Structured Data Output (Live Preview)"
            ] }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => copyToClipboard(JSON.stringify({
                  "@context": "https://schema.org",
                  "@type": "Organization",
                  "name": schemaForm.data.seo_schema_org_name,
                  "url": canonicalDomain,
                  "telephone": schemaForm.data.seo_schema_org_phone
                }, null, 2), "schema_json"),
                className: "text-xs text-orange-600 font-semibold hover:underline flex items-center gap-1",
                children: [
                  copiedField === "schema_json" ? /* @__PURE__ */ jsx(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsx(Copy, { className: "w-3.5 h-3.5" }),
                  copiedField === "schema_json" ? "Copied!" : "Copy JSON-LD"
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx("pre", { className: "text-xs font-mono bg-gray-950 text-emerald-400 p-4 rounded-xl overflow-x-auto border border-gray-800", children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              ...schemaForm.data.seo_schema_org_enabled === "1" ? [{
                "@type": "Organization",
                "name": schemaForm.data.seo_schema_org_name,
                "url": canonicalDomain,
                "telephone": schemaForm.data.seo_schema_org_phone || void 0,
                "address": schemaForm.data.seo_schema_org_address || void 0
              }] : [],
              ...schemaForm.data.seo_schema_search_enabled === "1" ? [{
                "@type": "WebSite",
                "name": siteName,
                "url": canonicalDomain,
                "potentialAction": {
                  "@type": "SearchAction",
                  "target": `${canonicalDomain}/search?q={search_term_string}`,
                  "query-input": "required name=search_term_string"
                }
              }] : []
            ]
          }, null, 2) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: schemaForm.processing,
            className: "flex items-center gap-2 px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white font-bold text-xs rounded-xl shadow transition",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              schemaForm.processing ? "Saving..." : "Save Schema Settings"
            ]
          }
        ) })
      ] }),
      activeTab === "redirects" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(ArrowRightLeft, { className: "w-5 h-5 text-orange-600" }),
              "301 / 302 URL Redirection Manager"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Safely redirect deprecated URLs to new product, category, or campaign pages without losing search rankings or 404s." })
          ] }),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                setEditingRedirect(null);
                redirectForm.reset();
                setShowRedirectModal(true);
              },
              className: "flex items-center gap-2 px-4 py-2.5 bg-[#EF4A23] hover:bg-[#d63d1a] text-white text-xs font-bold rounded-xl shadow transition shrink-0",
              children: [
                /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" }),
                "Add Redirection Rule"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "overflow-x-auto rounded-xl border border-gray-200", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 text-gray-600 font-bold uppercase tracking-wider border-b border-gray-200", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "py-3 px-4", children: "Source URL" }),
            /* @__PURE__ */ jsx("th", { className: "py-3 px-4", children: "Destination Target" }),
            /* @__PURE__ */ jsx("th", { className: "py-3 px-4", children: "Code" }),
            /* @__PURE__ */ jsx("th", { className: "py-3 px-4", children: "Hits" }),
            /* @__PURE__ */ jsx("th", { className: "py-3 px-4", children: "Status" }),
            /* @__PURE__ */ jsx("th", { className: "py-3 px-4 text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100 font-medium", children: redirects.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "6", className: "py-8 text-center text-gray-400", children: 'No 301/302 redirects configured yet. Click "Add Redirection Rule" above to create one.' }) }) : redirects.map((red) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/80 transition", children: [
            /* @__PURE__ */ jsx("td", { className: "py-3 px-4 font-mono text-gray-800", children: red.source_path }),
            /* @__PURE__ */ jsx("td", { className: "py-3 px-4 font-mono text-blue-600 truncate max-w-xs", children: red.target_path }),
            /* @__PURE__ */ jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxs("span", { className: `px-2 py-0.5 rounded font-bold text-[10px] ${red.status_code === 301 ? "bg-emerald-100 text-emerald-800" : "bg-blue-100 text-blue-800"}`, children: [
              red.status_code,
              " ",
              red.status_code === 301 ? "Permanent" : "Temporary"
            ] }) }),
            /* @__PURE__ */ jsx("td", { className: "py-3 px-4 text-gray-600 font-semibold", children: red.hits || 0 }),
            /* @__PURE__ */ jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => toggleRedirect(red.id),
                className: `px-2 py-0.5 rounded text-[10px] font-bold transition ${red.is_active ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-200" : "bg-gray-200 text-gray-600 hover:bg-gray-300"}`,
                children: red.is_active ? "Active" : "Disabled"
              }
            ) }),
            /* @__PURE__ */ jsxs("td", { className: "py-3 px-4 text-right space-x-2", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => startEditRedirect(red),
                  className: "text-xs text-blue-600 hover:underline font-semibold",
                  children: "Edit"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => deleteRedirect(red.id),
                  className: "text-xs text-rose-600 hover:underline font-semibold",
                  children: "Delete"
                }
              )
            ] })
          ] }, red.id)) })
        ] }) }),
        showRedirectModal && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-3", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: editingRedirect ? "Edit Redirection Rule" : "Create 301 / 302 Redirection" }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowRedirectModal(false),
                className: "text-gray-400 hover:text-gray-600 text-xs font-bold",
                children: "✕"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("form", { onSubmit: handleCreateOrUpdateRedirect, className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Source Old URL / Path" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: redirectForm.data.source_path,
                  onChange: (e) => redirectForm.setData("source_path", e.target.value),
                  placeholder: "/old-dell-laptop",
                  required: true,
                  className: "w-full text-xs font-mono border-gray-300 rounded-xl focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400 mt-1", children: "Relative path starting with a slash." })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Destination Target URL" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: redirectForm.data.target_path,
                  onChange: (e) => redirectForm.setData("target_path", e.target.value),
                  placeholder: "/product/dell-inspiron-15",
                  required: true,
                  className: "w-full text-xs font-mono border-gray-300 rounded-xl focus:ring-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Status Code" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: redirectForm.data.status_code,
                    onChange: (e) => redirectForm.setData("status_code", e.target.value),
                    className: "w-full text-xs font-semibold rounded-xl border-gray-300",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "301", children: "301 (Moved Permanently)" }),
                      /* @__PURE__ */ jsx("option", { value: "302", children: "302 (Found / Temporary)" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Rule State" }),
                /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-xs font-semibold text-gray-700 pt-2 cursor-pointer", children: [
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "checkbox",
                      checked: redirectForm.data.is_active,
                      onChange: (e) => redirectForm.setData("is_active", e.target.checked),
                      className: "w-4 h-4 text-[#EF4A23] rounded focus:ring-[#EF4A23]"
                    }
                  ),
                  /* @__PURE__ */ jsx("span", { children: "Active" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2 pt-4 border-t", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setShowRedirectModal(false),
                  className: "px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-xl transition",
                  children: "Cancel"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "submit",
                  disabled: redirectForm.processing,
                  className: "px-5 py-2 bg-[#EF4A23] hover:bg-[#d63d1a] text-white text-xs font-bold rounded-xl shadow transition",
                  children: redirectForm.processing ? "Saving..." : editingRedirect ? "Update Rule" : "Save Rule"
                }
              )
            ] })
          ] })
        ] }) })
      ] })
    ] })
  ] });
}
export {
  SeoIndex as default
};
