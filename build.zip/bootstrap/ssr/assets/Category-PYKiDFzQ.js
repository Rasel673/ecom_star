import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { P as ProductCard } from "./ProductCard-Ck3qGjy2.js";
import { ChevronRight, Filter, RotateCcw, SlidersHorizontal, X } from "lucide-react";
function Category({
  category,
  products,
  brands = [],
  filters = {},
  seo = {}
}) {
  const [minPrice, setMinPrice] = useState(filters.min_price || "");
  const [maxPrice, setMaxPrice] = useState(filters.max_price || "");
  const [selectedBrand, setSelectedBrand] = useState(filters.brand_id || "");
  const [selectedStock, setSelectedStock] = useState(filters.stock_status || "");
  const [sortBy, setSortBy] = useState(filters.sort || "latest");
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const activeFilterCount = [
    filters.min_price || filters.max_price,
    filters.brand_id,
    filters.stock_status
  ].filter(Boolean).length;
  const applyFilter = (newParams = {}) => {
    const query = {
      ...filters,
      min_price: minPrice || void 0,
      max_price: maxPrice || void 0,
      brand: selectedBrand || void 0,
      stock: selectedStock || void 0,
      sort: sortBy || void 0,
      ...newParams
    };
    Object.keys(query).forEach((key) => query[key] === void 0 && delete query[key]);
    router.get(route("category.show", category.slug), query, { preserveScroll: true });
  };
  const handleSortChange = (e) => {
    const val = e.target.value;
    setSortBy(val);
    applyFilter({ sort: val });
  };
  const handleBrandChange = (brandId) => {
    const newBrand = selectedBrand === brandId ? "" : brandId;
    setSelectedBrand(newBrand);
    applyFilter({ brand: newBrand });
  };
  const handleStockChange = (stockStatus) => {
    const newStock = selectedStock === stockStatus ? "" : stockStatus;
    setSelectedStock(newStock);
    applyFilter({ stock: newStock });
  };
  const handlePriceFilter = (e) => {
    e.preventDefault();
    applyFilter();
    setMobileFilterOpen(false);
  };
  const handleResetFilters = () => {
    setMinPrice("");
    setMaxPrice("");
    setSelectedBrand("");
    setSelectedStock("");
    router.get(route("category.show", category.slug), { sort: sortBy }, { preserveScroll: true });
    setMobileFilterOpen(false);
  };
  const FilterContent = () => /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
    category.children && category.children.length > 0 && /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-xl border border-gray-200 shadow-sm", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider mb-2.5 pb-2 border-b", children: "Sub Categories" }),
      /* @__PURE__ */ jsx("ul", { className: "space-y-1 text-xs", children: category.children.map((sub) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("category.show", sub.slug),
          onClick: () => setMobileFilterOpen(false),
          className: "flex items-center justify-between text-gray-600 hover:text-[#EF4A23] hover:font-medium py-1 transition",
          children: [
            /* @__PURE__ */ jsx("span", { children: sub.name }),
            /* @__PURE__ */ jsx(ChevronRight, { className: "w-3 h-3 text-gray-400" })
          ]
        }
      ) }, sub.id)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-xl border border-gray-200 shadow-sm", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider mb-2.5 pb-2 border-b", children: "Price Range (৳)" }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handlePriceFilter, className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              placeholder: "Min",
              value: minPrice,
              onChange: (e) => setMinPrice(e.target.value),
              className: "w-full text-xs p-2 rounded-lg border border-gray-300 focus:border-[#EF4A23] focus:ring-1 focus:ring-[#EF4A23]"
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "-" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              placeholder: "Max",
              value: maxPrice,
              onChange: (e) => setMaxPrice(e.target.value),
              className: "w-full text-xs p-2 rounded-lg border border-gray-300 focus:border-[#EF4A23] focus:ring-1 focus:ring-[#EF4A23]"
            }
          )
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            className: "w-full bg-[#081621] hover:bg-[#EF4A23] text-white text-xs font-bold py-2 rounded-lg transition",
            children: "Apply Price"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-xl border border-gray-200 shadow-sm", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider mb-2.5 pb-2 border-b", children: "Availability" }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-xs", children: [
        /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer text-gray-700", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              checked: selectedStock === "in_stock",
              onChange: () => handleStockChange("in_stock"),
              className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
            }
          ),
          /* @__PURE__ */ jsx("span", { children: "In Stock" })
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer text-gray-700", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              checked: selectedStock === "upcoming",
              onChange: () => handleStockChange("upcoming"),
              className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
            }
          ),
          /* @__PURE__ */ jsx("span", { children: "Upcoming" })
        ] })
      ] })
    ] }),
    brands.length > 0 && /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-xl border border-gray-200 shadow-sm", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider mb-2.5 pb-2 border-b", children: "Brand" }),
      /* @__PURE__ */ jsx("div", { className: "space-y-2 max-h-56 overflow-y-auto text-xs pr-1", children: brands.map((b) => /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer text-gray-700", children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "checkbox",
            checked: Number(selectedBrand) === b.id,
            onChange: () => handleBrandChange(b.id),
            className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
          }
        ),
        /* @__PURE__ */ jsx("span", { children: b.name })
      ] }, b.id)) })
    ] })
  ] });
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: seo.title, description: seo.description, children: [
    /* @__PURE__ */ jsxs("nav", { className: "flex items-center gap-1.5 text-[11px] sm:text-xs text-gray-500 mb-4 sm:mb-6 overflow-x-auto whitespace-nowrap pb-1", children: [
      /* @__PURE__ */ jsx(Link, { href: route("home"), className: "hover:text-[#EF4A23] shrink-0", children: "Home" }),
      /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-gray-400 shrink-0" }),
      category.parent && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Link, { href: route("category.show", category.parent.slug), className: "hover:text-[#EF4A23] shrink-0", children: category.parent.name }),
        /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-gray-400 shrink-0" })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold shrink-0", children: category.name })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "lg:hidden bg-white rounded-xl border border-gray-200 p-3 mb-4 flex items-center justify-between gap-3 shadow-sm sticky top-14 z-30", children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => setMobileFilterOpen(true),
          className: "flex items-center gap-2 text-xs font-bold bg-gray-100 hover:bg-gray-200 text-gray-800 px-3.5 py-2 rounded-lg transition",
          children: [
            /* @__PURE__ */ jsx(Filter, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Filter" }),
            activeFilterCount > 0 && /* @__PURE__ */ jsx("span", { className: "bg-[#EF4A23] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-black", children: activeFilterCount })
          ]
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 text-xs", children: [
        /* @__PURE__ */ jsx("span", { className: "text-gray-500 hidden xs:inline", children: "Sort:" }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            value: sortBy,
            onChange: handleSortChange,
            className: "text-xs font-semibold bg-gray-50 border border-gray-300 rounded-lg py-1.5 px-2.5 text-gray-800 focus:outline-none focus:border-[#EF4A23]",
            children: [
              /* @__PURE__ */ jsx("option", { value: "latest", children: "Latest" }),
              /* @__PURE__ */ jsx("option", { value: "price_low", children: "Price: Low to High" }),
              /* @__PURE__ */ jsx("option", { value: "price_high", children: "Price: High to Low" }),
              /* @__PURE__ */ jsx("option", { value: "popular", children: "Popularity" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-4 gap-6 sm:gap-8", children: [
      /* @__PURE__ */ jsxs("aside", { className: "hidden lg:block lg:col-span-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-gray-500", children: "Filter By" }),
          activeFilterCount > 0 && /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: handleResetFilters,
              className: "text-[11px] text-[#EF4A23] hover:underline font-semibold flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsx(RotateCcw, { className: "w-3 h-3" }),
                " Reset"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsx(FilterContent, {})
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "hidden lg:flex bg-white p-4 rounded-xl border border-gray-200 shadow-sm mb-6 items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h1", { className: "text-lg md:text-xl font-black text-gray-900", children: category.name }),
            /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 mt-0.5", children: [
              "Showing ",
              products.data.length,
              " of ",
              products.total,
              " products"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500 font-medium", children: "Sort By:" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: sortBy,
                onChange: handleSortChange,
                className: "text-xs font-semibold bg-gray-50 border border-gray-300 rounded-lg p-2 text-gray-700 focus:outline-none focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "latest", children: "Latest Products" }),
                  /* @__PURE__ */ jsx("option", { value: "price_low", children: "Price: Low to High" }),
                  /* @__PURE__ */ jsx("option", { value: "price_high", children: "Price: High to Low" }),
                  /* @__PURE__ */ jsx("option", { value: "popular", children: "Most Popular" })
                ]
              }
            )
          ] })
        ] }),
        products.data.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-3 sm:gap-5", children: products.data.map((product) => /* @__PURE__ */ jsx(ProductCard, { product }, product.id)) }) : /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 p-8 sm:p-12 text-center", children: [
          /* @__PURE__ */ jsx(SlidersHorizontal, { className: "w-12 h-12 text-gray-300 mx-auto mb-3" }),
          /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-800", children: "No Products Found" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1 max-w-sm mx-auto", children: "No products matched your current filters. Try resetting the filters or adjusting price range." }),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: handleResetFilters,
              className: "mt-4 px-4 py-2 bg-[#EF4A23] text-white text-xs font-bold rounded-lg hover:bg-[#d63c17] transition",
              children: "Reset All Filters"
            }
          )
        ] }),
        products.links && products.links.length > 3 && /* @__PURE__ */ jsx("div", { className: "mt-8 flex justify-center overflow-x-auto py-2", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm", children: products.links.map((link, idx) => /* @__PURE__ */ jsx(
          Link,
          {
            href: link.url || "#",
            dangerouslySetInnerHTML: { __html: link.label },
            className: `px-3 py-1.5 text-xs rounded-lg transition font-medium ${link.active ? "bg-[#EF4A23] text-white font-bold" : "text-gray-700 hover:bg-gray-100"}`
          },
          idx
        )) }) })
      ] })
    ] }),
    mobileFilterOpen && /* @__PURE__ */ jsxs("div", { className: "fixed inset-0 z-50 lg:hidden flex", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "fixed inset-0 bg-black/60 backdrop-blur-sm",
          onClick: () => setMobileFilterOpen(false)
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "relative ml-auto w-4/5 max-w-xs bg-[#F2F4F8] h-full flex flex-col shadow-2xl z-10 animate-in slide-in-from-right duration-250", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 bg-white border-b border-gray-200 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Filter, { className: "w-4 h-4 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("h3", { className: "font-bold text-sm text-gray-900", children: "Filter Products" })
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setMobileFilterOpen(false),
              className: "p-1 text-gray-400 hover:text-gray-600 rounded-lg",
              children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto p-4", children: /* @__PURE__ */ jsx(FilterContent, {}) }),
        /* @__PURE__ */ jsxs("div", { className: "p-3 bg-white border-t border-gray-200 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: handleResetFilters,
              className: "flex-1 py-2 text-xs font-bold text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition",
              children: "Reset"
            }
          ),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: () => setMobileFilterOpen(false),
              className: "flex-1 py-2 text-xs font-bold text-white bg-[#EF4A23] rounded-lg hover:bg-[#d63c17] transition",
              children: [
                "Apply (",
                products.total,
                ")"
              ]
            }
          )
        ] })
      ] })
    ] })
  ] });
}
export {
  Category as default
};
