import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { usePage, useForm, Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { ShoppingBag, Cpu, Heart, Clock, MessageSquare, User, LogOut, CreditCard, Truck, Check, Copy, ExternalLink, Printer, ChevronUp, ChevronDown, Package, ArrowRight, Trash2, ShoppingCart, Send, ShieldCheck } from "lucide-react";
function Dashboard({
  orders = [],
  pcBuilds = [],
  wishlists = [],
  messages = [],
  preOrders = [],
  userStats = {},
  activeDeliveryOrder = null,
  activeTab: initialTab = "orders"
}) {
  const { auth, settings } = usePage().props;
  const [currentTab, setCurrentTab] = useState(initialTab);
  const [selectedOrderForPrint, setSelectedOrderForPrint] = useState(null);
  const [expandedOrder, setExpandedOrder] = useState(null);
  const [copiedTracking, setCopiedTracking] = useState(false);
  const {
    data: messageData,
    setData: setMessageData,
    post: postMessage,
    processing: messageProcessing,
    reset: resetMessage
  } = useForm({
    subject: "",
    order_number: "",
    message: ""
  });
  const handleSendMessage = (e) => {
    e.preventDefault();
    postMessage(route("customer.message.store"), {
      preserveScroll: true,
      onSuccess: () => resetMessage()
    });
  };
  const handleLoadPcBuild = (build) => {
    if (build.components) {
      localStorage.setItem("startech_pc_build", JSON.stringify(build.components));
      router.visit(route("pcbuilder.index"));
    }
  };
  const handleDeletePcBuild = (buildId) => {
    if (confirm("Are you sure you want to delete this saved PC build?")) {
      router.delete(route("customer.pcbuild.delete", buildId), { preserveScroll: true });
    }
  };
  const handleRemoveWishlist = (productId) => {
    router.post(route("customer.wishlist.toggle"), { product_id: productId }, { preserveScroll: true });
  };
  const handleAddToCartFromWishlist = (productId) => {
    router.post(route("cart.add"), { product_id: productId, quantity: 1 }, { preserveScroll: true });
  };
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopiedTracking(true);
    setTimeout(() => setCopiedTracking(false), 2e3);
  };
  const handlePrintOrder = (order) => {
    setSelectedOrderForPrint(order);
    setTimeout(() => window.print(), 100);
  };
  const tabs = [
    { id: "orders", name: "Order History", icon: ShoppingBag, count: orders?.length || 0 },
    { id: "pc_builds", name: "Saved PC Builds", icon: Cpu, count: pcBuilds?.length || 0 },
    { id: "wishlist", name: "Favorites / Wishlist", icon: Heart, count: wishlists?.length || 0 },
    { id: "pre_orders", name: "Pre-Orders", icon: Clock, count: preOrders?.length || 0 },
    {
      id: "messages",
      name: "Message to Admin",
      icon: MessageSquare,
      count: messages?.length || 0,
      hasUnread: (userStats?.unreadRepliesCount || 0) > 0
    },
    { id: "profile", name: "Account Profile", icon: User }
  ];
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: `My Account - ${settings?.site_name || "Tech Shoppers"}`, children: [
    /* @__PURE__ */ jsxs("div", { className: "print:hidden max-w-6xl mx-auto py-2 sm:py-4 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-r from-[#081621] via-[#112538] to-[#081621] text-white rounded-3xl p-5 sm:p-7 shadow-xl border border-gray-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 relative overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 relative z-10", children: [
          /* @__PURE__ */ jsx("div", { className: "w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-[#EF4A23] text-white font-black text-2xl flex items-center justify-center shadow-lg border-2 border-orange-400/30", children: auth.user?.name?.charAt(0) || "U" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsx("h1", { className: "text-xl sm:text-2xl font-black", children: auth.user?.name }),
              userStats?.membershipTier && /* @__PURE__ */ jsx("span", { className: `text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full text-white bg-gradient-to-r ${userStats.tierBadgeColor || "from-orange-500 to-red-600"} shadow-sm`, children: userStats.membershipTier })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-3 text-xs text-gray-300 mt-1", children: [
              /* @__PURE__ */ jsx("span", { children: auth.user?.email }),
              auth.user?.phone && /* @__PURE__ */ jsxs("span", { className: "text-gray-400 font-mono", children: [
                "| ",
                auth.user.phone
              ] }),
              userStats?.rewardPoints !== void 0 && /* @__PURE__ */ jsxs("span", { className: "text-amber-400 font-bold bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20", children: [
                "⭐ ",
                Number(userStats.rewardPoints).toLocaleString(),
                " Star Points"
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2.5 w-full sm:w-auto relative z-10", children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/pc-builder",
              className: "flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 text-xs bg-white/10 hover:bg-white/20 text-white font-bold py-2.5 px-3.5 rounded-xl border border-white/10 transition",
              children: [
                /* @__PURE__ */ jsx(Cpu, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "PC Builder" })
              ]
            }
          ),
          auth.user?.role === "admin" && /* @__PURE__ */ jsx(
            Link,
            {
              href: route("admin.dashboard"),
              className: "flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2.5 px-3.5 rounded-xl transition shadow-md",
              children: /* @__PURE__ */ jsx("span", { children: "Admin Panel →" })
            }
          ),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("logout"),
              method: "post",
              as: "button",
              className: "flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 text-xs bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-white font-bold py-2.5 px-3.5 rounded-xl border border-rose-500/30 transition shadow-sm",
              title: `Sign out of your ${settings?.site_name || "Tech Shoppers"} account`,
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: "Log Out" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "absolute right-0 top-0 bottom-0 w-80 bg-gradient-to-l from-orange-600/10 to-transparent pointer-events-none" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-2xl border border-gray-200/90 shadow-sm flex items-center gap-3.5", children: [
          /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-orange-50 text-[#EF4A23] flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(CreditCard, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider block", children: "Total Spent" }),
            /* @__PURE__ */ jsxs("span", { className: "text-base sm:text-lg font-black text-gray-900 block", children: [
              "৳",
              Number(userStats?.totalSpent || 0).toLocaleString()
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-2xl border border-gray-200/90 shadow-sm flex items-center gap-3.5", children: [
          /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(ShoppingBag, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider block", children: "Orders Placed" }),
            /* @__PURE__ */ jsxs("span", { className: "text-base sm:text-lg font-black text-gray-900 block", children: [
              userStats?.totalOrders || 0,
              " Orders"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-2xl border border-gray-200/90 shadow-sm flex items-center gap-3.5", children: [
          /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(Cpu, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider block", children: "Saved PC Rigs" }),
            /* @__PURE__ */ jsxs("span", { className: "text-base sm:text-lg font-black text-gray-900 block", children: [
              pcBuilds?.length || 0,
              " Builds"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-4 rounded-2xl border border-gray-200/90 shadow-sm flex items-center gap-3.5", children: [
          /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(Clock, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider block", children: "Pre-Orders" }),
            /* @__PURE__ */ jsxs("span", { className: "text-base sm:text-lg font-black text-gray-900 block", children: [
              preOrders?.length || 0,
              " Bookings"
            ] })
          ] })
        ] })
      ] }),
      activeDeliveryOrder && (activeDeliveryOrder.courier_tracking_id || activeDeliveryOrder.courier_consignment_id) && /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-r from-blue-900 via-indigo-900 to-[#081621] text-white p-4 sm:p-5 rounded-2xl shadow-lg border border-blue-700/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3.5", children: [
          /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-400/30 flex items-center justify-center shrink-0 animate-pulse", children: /* @__PURE__ */ jsx(Truck, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-xs uppercase font-bold tracking-wider text-blue-300", children: "Live Parcel Tracking" }),
              /* @__PURE__ */ jsxs("span", { className: "text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-2 py-0.5 rounded-full", children: [
                "Dispatched via ",
                activeDeliveryOrder.courier_name || "Courier"
              ] })
            ] }),
            /* @__PURE__ */ jsxs("h4", { className: "text-sm font-bold text-white mt-0.5", children: [
              "Order #",
              activeDeliveryOrder.order_number,
              " • Tracking ID: ",
              /* @__PURE__ */ jsx("span", { className: "font-mono text-amber-300", children: activeDeliveryOrder.courier_tracking_id || activeDeliveryOrder.courier_consignment_id })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 w-full sm:w-auto", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => copyToClipboard(activeDeliveryOrder.courier_tracking_id || activeDeliveryOrder.courier_consignment_id),
              className: "px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1.5 transition text-white border border-white/10",
              children: [
                copiedTracking ? /* @__PURE__ */ jsx(Check, { className: "w-3.5 h-3.5 text-emerald-400" }) : /* @__PURE__ */ jsx(Copy, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: copiedTracking ? "Copied" : "Copy Tracking" })
              ]
            }
          ),
          activeDeliveryOrder.courier_tracking_url && /* @__PURE__ */ jsxs(
            "a",
            {
              href: activeDeliveryOrder.courier_tracking_url,
              target: "_blank",
              rel: "noreferrer",
              className: "px-3.5 py-1.5 rounded-lg bg-[#EF4A23] hover:bg-[#d63c17] text-xs font-bold flex items-center gap-1.5 transition text-white shadow-md",
              children: [
                /* @__PURE__ */ jsx("span", { children: "Track Live" }),
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-3.5 h-3.5" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200 p-1.5 shadow-sm overflow-x-auto whitespace-nowrap flex items-center gap-1", children: tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;
        return /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: () => setCurrentTab(tab.id),
            className: `flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition shrink-0 relative ${isActive ? "bg-[#081621] text-white shadow-sm" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"}`,
            children: [
              /* @__PURE__ */ jsx(Icon, { className: `w-4 h-4 ${isActive ? "text-[#EF4A23]" : "text-gray-400"}` }),
              /* @__PURE__ */ jsx("span", { children: tab.name }),
              tab.count !== void 0 && /* @__PURE__ */ jsx("span", { className: `text-[10px] px-1.5 py-0.2 rounded-full font-black ${isActive ? "bg-[#EF4A23] text-white" : "bg-gray-200 text-gray-700"}`, children: tab.count }),
              tab.hasUnread && /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-red-500 absolute top-2 right-2 animate-ping" })
            ]
          },
          tab.id
        );
      }) }),
      currentTab === "orders" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-3", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm sm:text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(ShoppingBag, { className: "w-5 h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "Purchase & Order History (",
              orders?.length || 0,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500", children: "Track shipments & print invoices" })
        ] }),
        orders?.length > 0 ? /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100 space-y-3 pt-1", children: orders.map((order) => {
          const isExpanded = expandedOrder === order.id;
          return /* @__PURE__ */ jsxs("div", { className: "pt-3 pb-2 rounded-xl bg-gray-50/50 p-4 border border-gray-100 space-y-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxs("span", { className: "font-mono font-bold text-gray-900 text-sm", children: [
                    "#",
                    order.order_number
                  ] }),
                  /* @__PURE__ */ jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${order.order_status === "delivered" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : order.order_status === "shipped" ? "bg-blue-50 text-blue-700 border border-blue-200" : order.order_status === "pending" ? "bg-amber-50 text-amber-700 border border-amber-200" : "bg-gray-100 text-gray-700"}`, children: order.order_status }),
                  /* @__PURE__ */ jsxs("span", { className: "px-2 py-0.5 rounded-full text-[10px] uppercase font-semibold bg-gray-100 text-gray-600", children: [
                    order.payment_method,
                    " (",
                    order.payment_status,
                    ")"
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-gray-500 text-[11px]", children: [
                  "Placed on ",
                  new Date(order.created_at).toLocaleDateString(),
                  " at ",
                  new Date(order.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                  " • ",
                  order.items?.length || 0,
                  " item(s)"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 self-end sm:self-center", children: [
                /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 block uppercase font-medium", children: "Total" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-base font-black text-[#EF4A23]", children: [
                    "৳",
                    Number(order.total).toLocaleString()
                  ] })
                ] }),
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handlePrintOrder(order),
                    className: "px-3 py-1.5 bg-white border border-gray-300 hover:bg-gray-100 text-gray-800 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shadow-sm",
                    children: [
                      /* @__PURE__ */ jsx(Printer, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                      /* @__PURE__ */ jsx("span", { children: "Print Invoice" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setExpandedOrder(isExpanded ? null : order.id),
                    className: "p-1.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition",
                    title: "Toggle Details",
                    children: isExpanded ? /* @__PURE__ */ jsx(ChevronUp, { className: "w-4 h-4" }) : /* @__PURE__ */ jsx(ChevronDown, { className: "w-4 h-4" })
                  }
                )
              ] })
            ] }),
            order.courier_name && /* @__PURE__ */ jsxs("div", { className: "bg-blue-50/80 border border-blue-200/80 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2 text-xs", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(Truck, { className: "w-4 h-4 text-blue-600 shrink-0" }),
                /* @__PURE__ */ jsxs("span", { className: "text-blue-900 font-medium", children: [
                  "Courier: ",
                  /* @__PURE__ */ jsx("strong", { className: "capitalize", children: order.courier_name })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("span", { className: "text-gray-500 font-mono text-[11px]", children: "Tracking ID:" }),
                /* @__PURE__ */ jsx("span", { className: "font-mono font-bold bg-white px-2 py-0.5 rounded border border-blue-300 text-blue-700", children: order.courier_tracking_id }),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => copyToClipboard(order.courier_tracking_id),
                    className: "text-gray-400 hover:text-gray-700",
                    title: "Copy",
                    children: copiedTracking ? /* @__PURE__ */ jsx(Check, { className: "w-3.5 h-3.5 text-emerald-600" }) : /* @__PURE__ */ jsx(Copy, { className: "w-3.5 h-3.5" })
                  }
                )
              ] })
            ] }),
            isExpanded && /* @__PURE__ */ jsxs("div", { className: "pt-2 border-t border-gray-200", children: [
              /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
                /* @__PURE__ */ jsx("thead", { className: "text-[10px] text-gray-400 uppercase font-semibold border-b", children: /* @__PURE__ */ jsxs("tr", { children: [
                  /* @__PURE__ */ jsx("th", { className: "py-2", children: "Item Description" }),
                  /* @__PURE__ */ jsx("th", { className: "py-2 text-center", children: "Qty" }),
                  /* @__PURE__ */ jsx("th", { className: "py-2 text-right", children: "Price" }),
                  /* @__PURE__ */ jsx("th", { className: "py-2 text-right", children: "Subtotal" })
                ] }) }),
                /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: order.items?.map((item) => /* @__PURE__ */ jsxs("tr", { children: [
                  /* @__PURE__ */ jsx("td", { className: "py-2.5 font-medium text-gray-900", children: item.product_name }),
                  /* @__PURE__ */ jsx("td", { className: "py-2.5 text-center font-bold", children: item.quantity }),
                  /* @__PURE__ */ jsxs("td", { className: "py-2.5 text-right", children: [
                    "৳",
                    Number(item.unit_price).toLocaleString()
                  ] }),
                  /* @__PURE__ */ jsxs("td", { className: "py-2.5 text-right font-bold text-gray-900", children: [
                    "৳",
                    Number(item.total_price).toLocaleString()
                  ] })
                ] }, item.id)) })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "pt-2 text-right text-xs text-gray-600", children: /* @__PURE__ */ jsxs("span", { children: [
                "Shipping to: ",
                /* @__PURE__ */ jsxs("strong", { children: [
                  order.customer_address,
                  ", ",
                  order.city
                ] })
              ] }) })
            ] })
          ] }, order.id);
        }) }) : /* @__PURE__ */ jsxs("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsx(Package, { className: "w-12 h-12 text-gray-300 mx-auto mb-2" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-gray-700", children: "No Orders Placed Yet" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mt-1 mb-4", children: "Discover genuine computer parts and laptops with official warranty." }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/",
              className: "inline-flex items-center gap-1.5 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2 px-4 rounded-xl transition",
              children: [
                /* @__PURE__ */ jsx("span", { children: "Browse Shop" }),
                /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
              ]
            }
          )
        ] })
      ] }),
      currentTab === "pc_builds" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-3", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm sm:text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Cpu, { className: "w-5 h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "Saved PC Builds History (",
              pcBuilds?.length || 0,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: "/pc-builder",
              className: "text-xs bg-[#081621] hover:bg-[#EF4A23] text-white font-bold px-3 py-1.5 rounded-lg transition",
              children: "+ Build New PC"
            }
          )
        ] }),
        pcBuilds?.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-1", children: pcBuilds.map((build) => {
          const componentsCount = build.components ? Object.keys(build.components).length : 0;
          return /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 border border-gray-200 rounded-2xl p-4.5 space-y-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-2", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h3", { className: "font-bold text-gray-900 text-sm leading-snug", children: build.name }),
                /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-400", children: [
                  "Saved on ",
                  new Date(build.created_at).toLocaleDateString()
                ] })
              ] }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleDeletePcBuild(build.id),
                  className: "p-1 text-gray-400 hover:text-rose-600 transition",
                  title: "Delete Build",
                  children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between py-2 border-y border-gray-200/80 text-xs", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 block uppercase", children: "Components" }),
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-800", children: [
                  componentsCount,
                  " Items"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 block uppercase", children: "Est. Wattage" }),
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-emerald-600", children: [
                  "~",
                  build.total_wattage || 350,
                  "W"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 block uppercase", children: "Total Cost" }),
                /* @__PURE__ */ jsxs("span", { className: "font-black text-[#EF4A23] text-sm", children: [
                  "৳",
                  Number(build.total_price).toLocaleString()
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2 pt-1", children: /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => handleLoadPcBuild(build),
                className: "flex-1 bg-[#081621] hover:bg-[#122738] text-white text-xs font-bold py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsx(Cpu, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                  /* @__PURE__ */ jsx("span", { children: "Load in PC Builder" })
                ]
              }
            ) })
          ] }, build.id);
        }) }) : /* @__PURE__ */ jsxs("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsx(Cpu, { className: "w-12 h-12 text-gray-300 mx-auto mb-2" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-gray-700", children: "No Custom PC Builds Saved" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mt-1 mb-4", children: 'Use our Live PC Builder tool and click "Save to Account" to store your configurations!' }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/pc-builder",
              className: "inline-flex items-center gap-1.5 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2 px-4 rounded-xl transition",
              children: [
                /* @__PURE__ */ jsx("span", { children: "Open PC Builder" }),
                /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
              ]
            }
          )
        ] })
      ] }),
      currentTab === "wishlist" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-3", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm sm:text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Heart, { className: "w-5 h-5 text-rose-500 fill-current" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "Favorite Products (",
              wishlists?.length || 0,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500", children: "Bookmarked items for quick purchase" })
        ] }),
        wishlists?.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-1", children: wishlists.map((w) => {
          const p = w.product;
          if (!p) return null;
          const price = p.special_price || p.regular_price;
          return /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-col justify-between space-y-3 group", children: [
            /* @__PURE__ */ jsxs("div", { className: "relative text-center", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleRemoveWishlist(p.id),
                  className: "absolute top-0 right-0 p-1.5 text-gray-400 hover:text-rose-600 transition",
                  title: "Remove from Wishlist",
                  children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsx(Link, { href: route("product.show", p.slug), children: /* @__PURE__ */ jsx(
                "img",
                {
                  src: p.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=300",
                  alt: p.name,
                  className: "w-28 h-28 object-contain mx-auto group-hover:scale-105 transition"
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("product.show", p.slug),
                  className: "text-xs font-bold text-gray-900 hover:text-[#EF4A23] line-clamp-2 leading-snug",
                  children: p.name
                }
              ),
              /* @__PURE__ */ jsxs("span", { className: "text-sm font-black text-[#EF4A23] mt-1.5 block", children: [
                "৳",
                Number(price).toLocaleString()
              ] })
            ] }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => handleAddToCartFromWishlist(p.id),
                className: "w-full bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2 rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm",
                children: [
                  /* @__PURE__ */ jsx(ShoppingCart, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsx("span", { children: "Add to Cart" })
                ]
              }
            )
          ] }, w.id);
        }) }) : /* @__PURE__ */ jsxs("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsx(Heart, { className: "w-12 h-12 text-gray-300 mx-auto mb-2" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-gray-700", children: "Your Wishlist is Empty" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mt-1 mb-4", children: "Click the heart icon on any product to save it here for later." }),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: "/",
              className: "inline-flex items-center gap-1.5 bg-[#EF4A23] text-white text-xs font-bold py-2 px-4 rounded-xl transition",
              children: /* @__PURE__ */ jsx("span", { children: "Explore Catalog" })
            }
          )
        ] })
      ] }),
      currentTab === "pre_orders" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-3", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm sm:text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Clock, { className: "w-5 h-5 text-amber-500" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "Upcoming & Pre-Orders (",
              preOrders?.length || 0,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500", children: "Advance bookings for high-demand items" })
        ] }),
        preOrders?.length > 0 ? /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100 space-y-3 pt-1", children: preOrders.map((po) => /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 rounded-2xl p-4 border border-gray-200 space-y-2 text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("span", { className: "font-mono font-bold text-gray-900 text-sm", children: [
                "#",
                po.pre_order_number
              ] }),
              /* @__PURE__ */ jsx("span", { className: `ml-2 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${po.status === "confirmed" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : po.status === "ready_to_ship" ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`, children: po.status })
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "text-gray-400 text-[11px]", children: [
              "Booked on ",
              new Date(po.created_at).toLocaleDateString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              po.product && /* @__PURE__ */ jsx(
                "img",
                {
                  src: po.product.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                  alt: po.product.name,
                  className: "w-12 h-12 object-contain rounded-lg border bg-white p-1"
                }
              ),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900", children: po.product?.name || "Pre-order product" }),
                /* @__PURE__ */ jsxs("p", { className: "text-gray-500 text-[11px]", children: [
                  "Qty: ",
                  po.quantity,
                  " item(s)"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 block uppercase", children: "Price" }),
              /* @__PURE__ */ jsxs("span", { className: "text-sm font-black text-[#EF4A23]", children: [
                "৳",
                Number(po.unit_price * po.quantity).toLocaleString()
              ] })
            ] })
          ] }),
          po.expected_date && /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-blue-700 bg-blue-50 p-2 rounded-lg mt-1", children: [
            "Expected Stock Arrival: ",
            /* @__PURE__ */ jsx("strong", { children: po.expected_date })
          ] })
        ] }, po.id)) }) : /* @__PURE__ */ jsxs("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsx(Clock, { className: "w-12 h-12 text-gray-300 mx-auto mb-2" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-gray-700", children: "No Pre-Orders Placed" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mt-1", children: "When high-demand items are upcoming or awaiting shipment, you can book them via Pre-Order." })
        ] })
      ] }),
      currentTab === "messages" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b pb-3", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm sm:text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(MessageSquare, { className: "w-5 h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Support Tickets & Messages to Admin" })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 mt-0.5", children: [
            "Send direct queries, warranty questions, or order inquiries directly to ",
            settings?.site_name || "Tech Shoppers",
            " Support"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("form", { onSubmit: handleSendMessage, className: "bg-gray-50 p-4 sm:p-5 rounded-2xl border border-gray-200 space-y-3.5", children: [
          /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider", children: "Send New Message to Admin" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                "Subject ",
                /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  required: true,
                  value: messageData.subject,
                  onChange: (e) => setMessageData("subject", e.target.value),
                  placeholder: "e.g. Warranty Claim / Order Inquiry / Product Compatibility",
                  className: "w-full p-2.5 rounded-xl border border-gray-300 focus:border-[#EF4A23]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Order # (Optional)" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: messageData.order_number,
                  onChange: (e) => setMessageData("order_number", e.target.value),
                  placeholder: "e.g. ST-261008-001",
                  className: "w-full p-2.5 rounded-xl border border-gray-300 focus:border-[#EF4A23] font-mono"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 text-xs mb-1", children: [
              "Your Message ",
              /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
            ] }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                required: true,
                rows: "3",
                value: messageData.message,
                onChange: (e) => setMessageData("message", e.target.value),
                placeholder: "Please describe your question or issue in detail...",
                className: "w-full p-2.5 rounded-xl border border-gray-300 focus:border-[#EF4A23] text-xs"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "submit",
              disabled: messageProcessing,
              className: "bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold px-5 py-2.5 rounded-xl transition flex items-center gap-1.5 shadow-sm",
              children: [
                /* @__PURE__ */ jsx(Send, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: messageProcessing ? "Sending..." : "Send Message" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("h3", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider", children: [
            "Previous Inquiries (",
            messages?.length || 0,
            ")"
          ] }),
          messages?.length > 0 ? /* @__PURE__ */ jsx("div", { className: "space-y-3", children: messages.map((m) => /* @__PURE__ */ jsxs("div", { className: "bg-white border border-gray-200 rounded-2xl p-4 space-y-3 text-xs shadow-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 border-b pb-2", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-900 text-sm", children: m.subject }),
                m.order_number && /* @__PURE__ */ jsxs("span", { className: "ml-2 font-mono text-[11px] bg-gray-100 text-gray-700 px-2 py-0.5 rounded", children: [
                  "Ref #",
                  m.order_number
                ] })
              ] }),
              /* @__PURE__ */ jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${m.status === "replied" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`, children: m.status === "replied" ? "Replied by Admin" : "Pending Reply" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-gray-700 bg-gray-50/50 p-3 rounded-xl leading-relaxed", children: [
              /* @__PURE__ */ jsx("p", { children: m.message }),
              /* @__PURE__ */ jsxs("span", { className: "text-[10px] text-gray-400 block mt-1.5", children: [
                "Sent on ",
                new Date(m.created_at).toLocaleString()
              ] })
            ] }),
            m.admin_reply && /* @__PURE__ */ jsxs("div", { className: "bg-orange-50/80 border border-orange-200/80 rounded-xl p-3 text-orange-950 space-y-1", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 font-bold text-xs text-[#EF4A23]", children: [
                /* @__PURE__ */ jsx(ShieldCheck, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Official Admin Reply:" })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-xs leading-relaxed", children: m.admin_reply }),
              m.replied_at && /* @__PURE__ */ jsxs("span", { className: "text-[10px] text-orange-800/60 block", children: [
                "Replied at ",
                new Date(m.replied_at).toLocaleString()
              ] })
            ] })
          ] }, m.id)) }) : /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 text-center py-6", children: "No previous messages." })
        ] })
      ] }),
      currentTab === "profile" && /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-3", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-sm sm:text-base font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(User, { className: "w-5 h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Customer Profile Details" })
          ] }),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("profile.edit"),
              className: "text-xs bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold px-3 py-1.5 rounded-lg transition",
              children: "Edit Profile"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-1", children: [
            /* @__PURE__ */ jsx("span", { className: "text-gray-400 text-[10px] uppercase font-bold", children: "Full Name" }),
            /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 text-sm", children: auth.user?.name })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-1", children: [
            /* @__PURE__ */ jsx("span", { className: "text-gray-400 text-[10px] uppercase font-bold", children: "Email Address" }),
            /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 text-sm", children: auth.user?.email })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-1", children: [
            /* @__PURE__ */ jsx("span", { className: "text-gray-400 text-[10px] uppercase font-bold", children: "Contact Phone" }),
            /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 text-sm font-mono", children: auth.user?.phone || "Not provided" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-1", children: [
            /* @__PURE__ */ jsx("span", { className: "text-gray-400 text-[10px] uppercase font-bold", children: "Default Delivery Address" }),
            /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 text-sm", children: auth.user?.address || "Not provided" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-3 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-rose-50/60 p-4 rounded-2xl border border-rose-100 mt-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-xs font-bold text-rose-900 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4 text-rose-600" }),
              /* @__PURE__ */ jsx("span", { children: "Account Session & Logout" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-rose-700/80 mt-0.5", children: "Safely end your session on this device. You will need to log back in next time." })
          ] }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("logout"),
              method: "post",
              as: "button",
              className: "shrink-0 inline-flex items-center justify-center gap-1.5 text-xs bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 px-4 rounded-xl transition shadow-sm",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: "Log Out of Account" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    selectedOrderForPrint && /* @__PURE__ */ jsxs("div", { className: "hidden print:block text-black bg-white p-6 sm:p-8 font-sans text-xs w-full max-w-full m-0", children: [
      /* @__PURE__ */ jsx("style", { dangerouslySetInnerHTML: {
        __html: `
                            @media print {
                                header, nav, footer, aside, .print\\:hidden, #app > div > div.print\\:hidden {
                                    display: none !important;
                                    visibility: hidden !important;
                                    height: 0 !important;
                                    opacity: 0 !important;
                                    pointer-events: none !important;
                                }
                                body, html {
                                    background: white !important;
                                    color: black !important;
                                    margin: 0 !important;
                                    padding: 0 !important;
                                }
                                main {
                                    padding: 0 !important;
                                    margin: 0 !important;
                                    max-width: 100% !important;
                                    width: 100% !important;
                                }
                            }
                        `
      } }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-start border-b-2 border-black pb-4 mb-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h1", { className: "text-xl font-black uppercase", style: { color: settings?.primary_color || "#EF4A23" }, children: settings?.site_name || "Tech Shoppers" }),
          /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-600", children: settings?.site_tagline || "Leading Computer, Laptop & Component Retailer in Bangladesh" }),
          /* @__PURE__ */ jsxs("p", { className: "text-[9px] text-gray-500", children: [
            "Hub: ",
            settings?.address || "Pragati Sharani, Dhaka 1212",
            " | Hotline: ",
            settings?.hotline || "16793"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-base font-black", children: "CUSTOMER INVOICE" }),
          /* @__PURE__ */ jsxs("p", { className: "font-mono text-sm font-bold", children: [
            "#",
            selectedOrderForPrint.order_number
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-gray-500", children: [
            "Date: ",
            new Date(selectedOrderForPrint.created_at).toLocaleDateString()
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h3", { className: "font-bold text-gray-700 text-[10px] uppercase border-b pb-1 mb-1", children: "Customer & Delivery:" }),
          /* @__PURE__ */ jsx("p", { className: "font-bold text-sm", children: selectedOrderForPrint.customer_name }),
          /* @__PURE__ */ jsx("p", { className: "font-mono font-bold", children: selectedOrderForPrint.customer_phone }),
          /* @__PURE__ */ jsx("p", { className: "leading-snug", children: selectedOrderForPrint.customer_address }),
          /* @__PURE__ */ jsxs("p", { className: "font-bold", children: [
            selectedOrderForPrint.city,
            " ",
            selectedOrderForPrint.zone && `(${selectedOrderForPrint.zone})`
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-bold text-gray-700 text-[10px] uppercase border-b pb-1 mb-1", children: "Payment & Shipping:" }),
          /* @__PURE__ */ jsxs("p", { children: [
            "Payment Method: ",
            /* @__PURE__ */ jsx("strong", { className: "uppercase", children: selectedOrderForPrint.payment_method })
          ] }),
          /* @__PURE__ */ jsxs("p", { children: [
            "Payment Status: ",
            /* @__PURE__ */ jsx("strong", { className: "uppercase", children: selectedOrderForPrint.payment_status })
          ] }),
          selectedOrderForPrint.courier_name && /* @__PURE__ */ jsxs("p", { children: [
            "Courier: ",
            /* @__PURE__ */ jsxs("strong", { children: [
              selectedOrderForPrint.courier_name,
              " (",
              selectedOrderForPrint.courier_tracking_id,
              ")"
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs mb-6 border border-black", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-100 border-b border-black", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-2 border-r border-black", children: "SL" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 border-r border-black", children: "Product Item" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 text-center border-r border-black", children: "Quantity" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 text-right border-r border-black", children: "Unit Price" }),
          /* @__PURE__ */ jsx("th", { className: "p-2 text-right", children: "Total Price" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-300", children: selectedOrderForPrint.items?.map((item, idx) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { className: "p-2 text-center border-r border-gray-300", children: idx + 1 }),
          /* @__PURE__ */ jsx("td", { className: "p-2 font-bold border-r border-gray-300", children: item.product_name }),
          /* @__PURE__ */ jsx("td", { className: "p-2 text-center border-r border-gray-300", children: item.quantity }),
          /* @__PURE__ */ jsxs("td", { className: "p-2 text-right border-r border-gray-300", children: [
            "৳",
            Number(item.unit_price).toLocaleString()
          ] }),
          /* @__PURE__ */ jsxs("td", { className: "p-2 text-right font-black", children: [
            "৳",
            Number(item.total_price).toLocaleString()
          ] })
        ] }, item.id)) }),
        /* @__PURE__ */ jsxs("tfoot", { className: "border-t-2 border-black font-bold", children: [
          /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { colSpan: "4", className: "p-2 text-right", children: "Subtotal:" }),
            /* @__PURE__ */ jsxs("td", { className: "p-2 text-right", children: [
              "৳",
              Number(selectedOrderForPrint.subtotal || selectedOrderForPrint.total).toLocaleString()
            ] })
          ] }),
          Number(selectedOrderForPrint.shipping_cost) > 0 && /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { colSpan: "4", className: "p-2 text-right", children: "Delivery Charge:" }),
            /* @__PURE__ */ jsxs("td", { className: "p-2 text-right", children: [
              "৳",
              Number(selectedOrderForPrint.shipping_cost).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
            /* @__PURE__ */ jsx("td", { colSpan: "4", className: "p-2.5 text-right text-sm", children: "Total Payable Amount:" }),
            /* @__PURE__ */ jsxs("td", { className: "p-2.5 text-right text-base font-black", children: [
              "৳",
              Number(selectedOrderForPrint.total).toLocaleString()
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 pt-4 border-t border-gray-400 text-center text-[9px] text-gray-500", children: [
        "Thank you for shopping with ",
        settings?.site_name || "Tech Shoppers",
        "! | Hotline: ",
        settings?.hotline || "16793",
        " ",
        settings?.email ? `| Email: ${settings.email}` : ""
      ] })
    ] })
  ] });
}
export {
  Dashboard as default
};
