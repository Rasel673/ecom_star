import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link, usePage } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { ChevronLeft, ChevronRight, Laptop, MessageSquareWarning, Home as Home$1, Settings, ThermometerSnowflake, X, Search, ArrowRight, Gamepad2, Watch, Wifi, Keyboard, Tv, Cpu, Monitor, Sparkles, Flame } from "lucide-react";
import { P as ProductCard } from "./ProductCard-Ck3qGjy2.js";
function HeroSlider({ banners = [] }) {
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    if (!banners.length) return;
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length);
    }, 5e3);
    return () => clearInterval(interval);
  }, [banners.length]);
  if (!banners.length) return null;
  const nextSlide = () => setCurrent((prev) => (prev + 1) % banners.length);
  const prevSlide = () => setCurrent((prev) => (prev - 1 + banners.length) % banners.length);
  const banner = banners[current];
  return /* @__PURE__ */ jsxs("div", { className: "relative rounded-2xl overflow-hidden bg-gray-900 shadow-md group h-[190px] xs:h-[240px] sm:h-[320px] md:h-[380px] lg:h-[400px]", children: [
    /* @__PURE__ */ jsxs(Link, { href: banner.link || "#", className: "block w-full h-full relative", children: [
      /* @__PURE__ */ jsx(
        "img",
        {
          src: banner.image,
          alt: banner.title || "Tech Shoppers Promo",
          className: "w-full h-full object-cover"
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex flex-col justify-end p-6 md:p-8", children: [
        banner.title && /* @__PURE__ */ jsx("h2", { className: "text-xl md:text-3xl font-extrabold text-white tracking-tight drop-shadow-md", children: banner.title }),
        banner.subtitle && /* @__PURE__ */ jsx("p", { className: "text-sm md:text-base text-gray-200 mt-1 max-w-xl drop-shadow", children: banner.subtitle })
      ] })
    ] }),
    banners.length > 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: prevSlide,
          className: "absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition opacity-0 group-hover:opacity-100",
          title: "Previous",
          children: /* @__PURE__ */ jsx(ChevronLeft, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: nextSlide,
          className: "absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition opacity-0 group-hover:opacity-100",
          title: "Next",
          children: /* @__PURE__ */ jsx(ChevronRight, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10", children: banners.map((_, idx) => /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setCurrent(idx),
          className: `h-2 rounded-full transition-all duration-300 ${current === idx ? "w-6 bg-[#EF4A23]" : "w-2 bg-white/60 hover:bg-white"}`
        },
        idx
      )) })
    ] })
  ] });
}
function QuickServicesBar({ settings = {} }) {
  const [showAcModal, setShowAcModal] = useState(false);
  const [showLaptopFinderModal, setShowLaptopFinderModal] = useState(false);
  const [roomLength, setRoomLength] = useState(12);
  const [roomWidth, setRoomWidth] = useState(12);
  const [isTopFloor, setIsTopFloor] = useState(false);
  const [sunlight, setSunlight] = useState("moderate");
  const [occupants, setOccupants] = useState("1-2");
  const roomSqFt = roomLength * roomWidth;
  let calculatedTon = 1;
  if (roomSqFt <= 120) calculatedTon = 1;
  else if (roomSqFt <= 180) calculatedTon = 1.5;
  else if (roomSqFt <= 250) calculatedTon = 2;
  else if (roomSqFt <= 320) calculatedTon = 2.5;
  else calculatedTon = 3;
  if (isTopFloor && calculatedTon < 3) calculatedTon += 0.5;
  if (sunlight === "high" && calculatedTon < 3) calculatedTon += 0.5;
  if (occupants === "5+" && calculatedTon < 3) calculatedTon += 0.5;
  const btuRating = Math.round(calculatedTon * 12e3);
  const [laptopBudget, setLaptopBudget] = useState("all");
  const [laptopPurpose, setLaptopPurpose] = useState("all");
  const todayDate = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long"
  });
  const marqueeNotice = settings?.announcement || `${todayDate}, All our branch showrooms and outlets are open today. Customer Care & Hotline ${settings?.hotline || "16793"} is active from 10:00 AM to 8:00 PM across Bangladesh.`;
  return /* @__PURE__ */ jsxs("section", { className: "mb-10", children: [
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-full py-2.5 px-4 sm:px-6 border border-gray-200/80 shadow-xs mb-5 flex items-center justify-between text-xs overflow-hidden gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
        /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-[#EF4A23] animate-ping" }),
        /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-xs font-bold text-[#EF4A23] uppercase tracking-wider bg-orange-50 border border-orange-200/60 px-2 py-0.5 rounded-full", children: "Notice" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "overflow-hidden whitespace-nowrap flex-1 text-right sm:text-left", children: /* @__PURE__ */ jsx("span", { className: "text-gray-600 font-medium text-[11px] sm:text-xs inline-block", children: marqueeNotice }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4", children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => setShowLaptopFinderModal(true),
          className: "bg-white hover:bg-orange-50/20 border border-gray-200/80 hover:border-orange-300 rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 sm:gap-4 shadow-xs hover:shadow-md transition group text-left w-full",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23] text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform", children: /* @__PURE__ */ jsx(Laptop, { className: "w-6 h-6 text-white" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { className: "text-sm sm:text-base font-black text-gray-900 group-hover:text-[#EF4A23] transition-colors leading-tight", children: "Laptop Finder" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Find Your Laptop Easily" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/page/service-complain",
          className: "bg-white hover:bg-orange-50/20 border border-gray-200/80 hover:border-orange-300 rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 sm:gap-4 shadow-xs hover:shadow-md transition group text-left",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23] text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform", children: /* @__PURE__ */ jsx(MessageSquareWarning, { className: "w-6 h-6 text-white" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { className: "text-sm sm:text-base font-black text-gray-900 group-hover:text-[#EF4A23] transition-colors leading-tight", children: "Raise a Complain" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Share your experience" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => setShowAcModal(true),
          className: "bg-white hover:bg-orange-50/20 border border-gray-200/80 hover:border-orange-300 rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 sm:gap-4 shadow-xs hover:shadow-md transition group text-left w-full",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23] text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform", children: /* @__PURE__ */ jsx(Home$1, { className: "w-6 h-6 text-white" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { className: "text-sm sm:text-base font-black text-gray-900 group-hover:text-[#EF4A23] transition-colors leading-tight", children: "AC Ton Calculator" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Find Perfect AC." })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/page/service-complain",
          className: "bg-white hover:bg-orange-50/20 border border-gray-200/80 hover:border-orange-300 rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 sm:gap-4 shadow-xs hover:shadow-md transition group text-left",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23] text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform", children: /* @__PURE__ */ jsx(Settings, { className: "w-6 h-6 text-white" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { className: "text-sm sm:text-base font-black text-gray-900 group-hover:text-[#EF4A23] transition-colors leading-tight", children: "Servicing Center" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Repair Your Device" })
            ] })
          ]
        }
      )
    ] }),
    showAcModal && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4", children: /* @__PURE__ */ jsxs(
      "div",
      {
        className: "relative bg-white rounded-3xl shadow-2xl max-w-xl w-full border border-gray-100 overflow-hidden animate-scale-up",
        onClick: (e) => e.stopPropagation(),
        children: [
          /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 bg-gradient-to-r from-gray-900 via-[#112538] to-gray-900 text-white flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-orange-500/20 text-[#EF4A23] flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(ThermometerSnowflake, { className: "w-5 h-5 text-orange-400" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h3", { className: "text-base font-black text-white", children: "Air Conditioner (AC) Ton Calculator" }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-300", children: "Calculate exact cooling capacity for your room" })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowAcModal(false),
                className: "text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition",
                children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-5 sm:p-6 space-y-5", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700 block mb-2", children: "Room Dimensions (Feet)" }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-500 block mb-1", children: [
                    "Length: ",
                    roomLength,
                    " ft"
                  ] }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "range",
                      min: "8",
                      max: "30",
                      value: roomLength,
                      onChange: (e) => setRoomLength(Number(e.target.value)),
                      className: "w-full accent-[#EF4A23]"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-500 block mb-1", children: [
                    "Width: ",
                    roomWidth,
                    " ft"
                  ] }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "range",
                      min: "8",
                      max: "30",
                      value: roomWidth,
                      onChange: (e) => setRoomWidth(Number(e.target.value)),
                      className: "w-full accent-[#EF4A23]"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mt-2 text-right", children: /* @__PURE__ */ jsxs("span", { className: "text-xs font-semibold text-gray-600 bg-gray-100 px-2.5 py-1 rounded-lg", children: [
                "Total Floor Area: ",
                /* @__PURE__ */ jsxs("strong", { className: "text-gray-900", children: [
                  roomSqFt,
                  " sq ft"
                ] })
              ] }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-gray-100", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700 block mb-1.5", children: "Sunlight Exposure" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: sunlight,
                    onChange: (e) => setSunlight(e.target.value),
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "low", children: "Shaded / Low Sunlight" }),
                      /* @__PURE__ */ jsx("option", { value: "moderate", children: "Moderate Direct Sun" }),
                      /* @__PURE__ */ jsx("option", { value: "high", children: "Heavy Sun / West Facing" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700 block mb-1.5", children: "Floor Level" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: isTopFloor ? "top" : "middle",
                    onChange: (e) => setIsTopFloor(e.target.value === "top"),
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "middle", children: "Ground or Middle Floor" }),
                      /* @__PURE__ */ jsx("option", { value: "top", children: "Top Floor / Roof Direct" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-br from-[#081621] to-[#112538] text-white p-5 rounded-2xl border border-gray-800 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 uppercase tracking-wider block", children: "Recommended AC Capacity" }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-2 mt-0.5", children: [
                  /* @__PURE__ */ jsxs("span", { className: "text-3xl font-black text-[#EF4A23]", children: [
                    calculatedTon.toFixed(1),
                    " Ton"
                  ] }),
                  /* @__PURE__ */ jsxs("span", { className: "text-xs text-gray-300", children: [
                    "(",
                    btuRating.toLocaleString(),
                    " BTU/hr)"
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-400 mt-1", children: [
                  "Optimal cooling for ~",
                  roomSqFt,
                  " sq. ft room dimensions"
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(ThermometerSnowflake, { className: "w-6 h-6" }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: "/search?q=air+conditioner",
                onClick: () => setShowAcModal(false),
                className: "text-xs font-bold text-[#EF4A23] hover:underline flex items-center gap-1",
                children: [
                  /* @__PURE__ */ jsx("span", { children: "Browse Air Conditioners" }),
                  /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5" })
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowAcModal(false),
                className: "px-5 py-2 bg-[#081621] hover:bg-[#112538] text-white text-xs font-bold rounded-xl transition",
                children: "Done"
              }
            )
          ] })
        ]
      }
    ) }),
    showLaptopFinderModal && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4", children: /* @__PURE__ */ jsxs(
      "div",
      {
        className: "relative bg-white rounded-3xl shadow-2xl max-w-xl w-full border border-gray-100 overflow-hidden animate-scale-up",
        onClick: (e) => e.stopPropagation(),
        children: [
          /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 bg-gradient-to-r from-gray-900 via-[#112538] to-gray-900 text-white flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-orange-500/20 text-[#EF4A23] flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(Laptop, { className: "w-5 h-5 text-orange-400" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h3", { className: "text-base font-black text-white", children: "Laptop Finder Assistant" }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-300", children: "Find the ideal laptop matching your exact budget & needs" })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowLaptopFinderModal(false),
                className: "text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition",
                children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-5 sm:p-6 space-y-5", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-800 block mb-2", children: "1. Select Your Budget Range" }),
              /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-2 text-xs", children: [
                { id: "all", label: "Any Budget" },
                { id: "45000", label: "Under ৳45,000" },
                { id: "75000", label: "৳45,000 - ৳75,000" },
                { id: "120000", label: "৳75,000 - ৳120,000" },
                { id: "premium", label: "৳120,000+" }
              ].map((b) => /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setLaptopBudget(b.id),
                  className: `p-2.5 rounded-xl border text-center font-bold transition ${laptopBudget === b.id ? "bg-[#081621] text-white border-[#081621]" : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700"}`,
                  children: b.label
                },
                b.id
              )) })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-800 block mb-2", children: "2. Primary Usage / Purpose" }),
              /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-2 text-xs", children: [
                { id: "all", label: "All Laptops" },
                { id: "gaming", label: "Gaming & High Performance" },
                { id: "student", label: "Student / Everyday Office" },
                { id: "ultrabook", label: "Slim Ultrabook & Battery Life" }
              ].map((p) => /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setLaptopPurpose(p.id),
                  className: `p-2.5 rounded-xl border text-center font-bold transition ${laptopPurpose === p.id ? "bg-[#EF4A23] text-white border-[#EF4A23]" : "bg-white hover:bg-gray-50 border-gray-200 text-gray-700"}`,
                  children: p.label
                },
                p.id
              )) })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "px-5 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between", children: /* @__PURE__ */ jsxs(
            Link,
            {
              href: laptopPurpose === "gaming" ? "/category/gaming-laptop" : "/category/laptop",
              onClick: () => setShowLaptopFinderModal(false),
              className: "w-full py-2.5 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-md",
              children: [
                /* @__PURE__ */ jsx(Search, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "View Matching Laptops" })
              ]
            }
          ) })
        ]
      }
    ) })
  ] });
}
const iconMap = {
  "Monitor": Monitor,
  "Laptop": Laptop,
  "Cpu": Cpu,
  "Tv": Tv,
  "Keyboard": Keyboard,
  "Wifi": Wifi,
  "Watch": Watch,
  "Gamepad2": Gamepad2
};
function Home({
  heroBanners = [],
  promoBanners = [],
  featuredCategories = [],
  featuredProducts = [],
  popularProducts = [],
  latestProducts = [],
  brands = [],
  seo = {}
}) {
  const { settings } = usePage().props;
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: seo.title, description: seo.description, children: [
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10", children: [
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsx(HeroSlider, { banners: heroBanners }) }),
      /* @__PURE__ */ jsx("div", { className: "hidden lg:flex flex-col gap-4 justify-between", children: promoBanners.slice(0, 2).map((promo, idx) => /* @__PURE__ */ jsxs(
        Link,
        {
          href: promo.link || "#",
          className: "relative flex-1 rounded-2xl overflow-hidden group shadow-md bg-gray-900 border border-gray-800",
          children: [
            /* @__PURE__ */ jsx(
              "img",
              {
                src: promo.image,
                alt: promo.title || "Promo",
                className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-5", children: [
              /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-white leading-snug drop-shadow", children: promo.title }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-orange-400 mt-1 font-semibold flex items-center gap-1", children: [
                "View Details ",
                /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
              ] })
            ] })
          ]
        },
        idx
      )) })
    ] }),
    /* @__PURE__ */ jsx(QuickServicesBar, { settings }),
    /* @__PURE__ */ jsxs("div", { className: "mb-12", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-6", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Featured Categories" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Get your desired product from featured category!" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 sm:grid-cols-4 md:grid-cols-8 gap-2 sm:gap-3", children: featuredCategories.map((cat) => {
        const IconComponent = iconMap[cat.icon] || Cpu;
        return /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("category.show", cat.slug),
            className: "bg-white hover:bg-[#081621] border border-gray-200 hover:border-[#081621] rounded-xl p-2.5 sm:p-4 flex flex-col items-center justify-center gap-1.5 sm:gap-2 text-center group transition-all duration-200 shadow-sm hover:shadow-md",
            children: [
              /* @__PURE__ */ jsx("div", { className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-50 group-hover:bg-[#EF4A23] flex items-center justify-center text-[#EF4A23] group-hover:text-white transition", children: /* @__PURE__ */ jsx(IconComponent, { className: "w-5 h-5 sm:w-6 sm:h-6" }) }),
              /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-xs font-bold text-gray-800 group-hover:text-white transition line-clamp-1", children: cat.name })
            ]
          },
          cat.id
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-10 sm:mb-14", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4 sm:mb-6 border-b border-gray-200 pb-2 sm:pb-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2", children: [
            /* @__PURE__ */ jsx(Sparkles, { className: "w-4 h-4 sm:w-5 sm:h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("h2", { className: "text-lg sm:text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Featured Products" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Check & get your desired product!" })
        ] }),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("category.show", "desktop"),
            className: "text-xs font-bold text-[#EF4A23] hover:text-[#d63c17] flex items-center gap-1 transition",
            children: [
              "View All ",
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5", children: featuredProducts.map((product) => /* @__PURE__ */ jsx(ProductCard, { product }, product.id)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-10 sm:mb-14", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4 sm:mb-6 border-b border-gray-200 pb-2 sm:pb-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2", children: [
            /* @__PURE__ */ jsx(Flame, { className: "w-4 h-4 sm:w-5 sm:h-5 text-amber-500" }),
            /* @__PURE__ */ jsx("h2", { className: "text-lg sm:text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Top Trending & Popular" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Most in-demand computer hardware and tech accessories" })
        ] }),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("category.show", "component"),
            className: "text-xs font-bold text-[#EF4A23] hover:text-[#d63c17] flex items-center gap-1 transition",
            children: [
              "Explore More ",
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5", children: popularProducts.map((product) => /* @__PURE__ */ jsx(ProductCard, { product }, product.id)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-14 bg-gradient-to-r from-[#081621] via-[#112538] to-[#081621] rounded-2xl p-6 md:p-10 border border-gray-800 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "max-w-xl", children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs font-bold tracking-widest text-[#EF4A23] uppercase bg-orange-500/10 border border-orange-500/20 px-3 py-1 rounded-full", children: "Custom Tool" }),
        /* @__PURE__ */ jsx("h3", { className: "text-2xl md:text-3xl font-black mt-3 leading-tight", children: "Build Your Dream PC With Live Compatibility Check" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-300 mt-2", children: "Select CPU, Motherboard, GPU, RAM, Storage, Power Supply & Casing. Calculate wattage, get instant price breakdown, and order directly." })
      ] }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/pc-builder",
          className: "inline-flex items-center gap-2 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg hover:shadow-orange-500/20 transition",
          children: [
            /* @__PURE__ */ jsx(Cpu, { className: "w-5 h-5" }),
            /* @__PURE__ */ jsx("span", { children: "Start PC Builder" }),
            /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 ml-1" })
          ]
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-14", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-6", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Top Brands" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Authorized distributors of world's best tech giants" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4", children: brands.map((brand) => /* @__PURE__ */ jsx(
        "div",
        {
          className: "bg-white border border-gray-200/90 rounded-xl p-4 flex flex-col items-center justify-center text-center shadow-sm hover:border-[#EF4A23] transition group",
          children: /* @__PURE__ */ jsx("span", { className: "text-sm font-extrabold text-gray-800 group-hover:text-[#EF4A23] transition", children: brand.name })
        },
        brand.id
      )) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 p-6 md:p-8 text-xs text-gray-600 space-y-4", children: [
      /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 uppercase tracking-wide", children: [
        settings?.site_tagline || "Leading Computer, Laptop & Component Shop in Bangladesh",
        " - ",
        settings?.site_name || "Tech Shoppers"
      ] }),
      /* @__PURE__ */ jsx("p", { children: settings?.footer_about || `${settings?.site_name || "Tech Shoppers"} is Bangladesh's largest retail and online shop for computers, laptops, PC gaming components, gadgets, and office electronics, delivering genuine products with official warranty, exceptional customer service, and unmatched competitive prices.` })
    ] })
  ] });
}
export {
  Home as default
};
