import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { usePage, useForm, Head, Link } from "@inertiajs/react";
import { Sparkles, ShoppingBag, Cpu, Clock, ShieldCheck, CheckCircle2, Mail, Lock, EyeOff, Eye, ArrowRight, Shield } from "lucide-react";
function Login({ status, canResetPassword }) {
  const { settings } = usePage().props;
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: true
  });
  const [showPassword, setShowPassword] = useState(false);
  const submit = (e) => {
    e.preventDefault();
    post(route("login"), {
      onFinish: () => reset("password")
    });
  };
  const fillDemoCustomer = () => {
    setData({
      email: "customer@gmail.com",
      password: "password123",
      remember: true
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-[#F4F7F9] flex flex-col justify-between text-gray-800", children: [
    /* @__PURE__ */ jsx(Head, { title: `Customer Login - ${settings?.site_name || "Tech Shoppers"}` }),
    /* @__PURE__ */ jsx("header", { className: "bg-white border-b border-gray-200 py-3.5 px-4 sm:px-8", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto flex items-center justify-between", children: [
      /* @__PURE__ */ jsx(Link, { href: route("home"), className: "flex items-center gap-2 group", children: settings?.site_logo ? /* @__PURE__ */ jsx(
        "img",
        {
          src: settings.site_logo,
          alt: settings?.site_name || "Logo",
          className: "max-h-8 max-w-[150px] object-contain"
        }
      ) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("span", { className: "text-2xl font-black tracking-tight text-[#081621] group-hover:opacity-90", children: settings?.site_name ? settings.site_name.split(" ")[0] : "TECH" }),
        /* @__PURE__ */ jsx(
          "span",
          {
            className: "text-2xl font-black tracking-tight",
            style: { color: settings?.primary_color || "#EF4A23" },
            children: settings?.site_name ? settings.site_name.split(" ").slice(1).join(" ") || "SHOPPERS" : "SHOPPERS"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-xs", children: [
        /* @__PURE__ */ jsxs("span", { className: "text-gray-500 hidden sm:inline", children: [
          "New to ",
          settings?.site_name || "Tech Shoppers",
          "?"
        ] }),
        /* @__PURE__ */ jsx(
          Link,
          {
            href: route("register"),
            className: "font-bold hover:underline",
            style: { color: settings?.primary_color || "#EF4A23" },
            children: "Create an Account"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("main", { className: "flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-10", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-4xl bg-white rounded-3xl shadow-xl border border-gray-200/90 overflow-hidden grid grid-cols-1 md:grid-cols-12", children: [
      /* @__PURE__ */ jsxs("div", { className: "hidden md:flex md:col-span-5 bg-gradient-to-br from-[#081621] via-[#112538] to-[#081621] p-8 text-white flex-col justify-between relative overflow-hidden", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute -right-16 -top-16 w-56 h-56 rounded-full bg-orange-600/15 blur-2xl pointer-events-none" }),
        /* @__PURE__ */ jsx("div", { className: "absolute -left-16 -bottom-16 w-56 h-56 rounded-full bg-blue-600/15 blur-2xl pointer-events-none" }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
          /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 text-[11px] font-bold mb-6", children: [
            /* @__PURE__ */ jsx(Sparkles, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxs("span", { children: [
              settings?.site_name || "Tech Shoppers",
              " Customer Portal"
            ] })
          ] }),
          /* @__PURE__ */ jsx("h2", { className: "text-2xl font-black leading-tight mb-2", children: "Welcome Back, Tech Enthusiast." }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-300 leading-relaxed mb-8", children: "Sign in to unlock member perks, custom build tools, and fast checkout on Bangladesh's #1 tech store." }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-4 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 text-[#EF4A23]", children: /* @__PURE__ */ jsx(ShoppingBag, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h4", { className: "font-bold text-white", children: "Live Order Tracking & Invoices" }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-400 text-[11px]", children: "Print official invoices & track Steadfast / RedX shipments." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 text-amber-400", children: /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h4", { className: "font-bold text-white", children: "Saved PC Builder History" }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-400 text-[11px]", children: "Save custom gaming rigs and reload anytime." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 text-emerald-400", children: /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h4", { className: "font-bold text-white", children: "Priority Pre-Orders" }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-400 text-[11px]", children: "Reserve upcoming stock with guaranteed availability." })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 pt-8 border-t border-gray-800/80 flex items-center gap-2 text-[11px] text-gray-400", children: [
          /* @__PURE__ */ jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }),
          /* @__PURE__ */ jsx("span", { children: "100% Genuine Products & Official Warranty" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "md:col-span-7 p-6 sm:p-10 flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsx("h1", { className: "text-xl sm:text-2xl font-black text-gray-900 tracking-tight", children: "Customer Sign In" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Enter your credentials to manage orders, wishlist, and builds." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mb-6 p-3 bg-orange-50/70 border border-orange-200/80 rounded-2xl flex items-center justify-between gap-3 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-[#EF4A23] animate-pulse" }),
              /* @__PURE__ */ jsx("span", { className: "text-gray-700 font-medium", children: "Quick Demo Customer:" }),
              /* @__PURE__ */ jsx("code", { className: "bg-orange-100 text-[#EF4A23] px-1.5 py-0.5 rounded text-[11px] font-bold", children: "customer@gmail.com" })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: fillDemoCustomer,
                className: "px-2.5 py-1 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-[11px] font-bold rounded-lg transition shadow-sm",
                children: "Autofill"
              }
            )
          ] }),
          status && /* @__PURE__ */ jsxs("div", { className: "mb-5 p-3 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-semibold border border-emerald-200 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsx("span", { children: status })
          ] }),
          /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1.5", htmlFor: "email", children: "Email Address" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400", children: /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4" }) }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    id: "email",
                    type: "email",
                    name: "email",
                    value: data.email,
                    autoComplete: "username",
                    required: true,
                    onChange: (e) => setData("email", e.target.value),
                    placeholder: "e.g. yourname@example.com",
                    className: `w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border transition ${errors.email ? "border-rose-300 focus:border-rose-500 focus:ring-rose-200 bg-rose-50/20" : "border-gray-300 focus:border-[#EF4A23] focus:ring-orange-100 bg-white"} focus:outline-none focus:ring-4`
                  }
                )
              ] }),
              errors.email && /* @__PURE__ */ jsx("p", { className: "mt-1.5 text-xs text-rose-600 font-medium", children: errors.email })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700", htmlFor: "password", children: "Password" }),
                canResetPassword && /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("password.request"),
                    className: "text-[11px] font-semibold text-[#EF4A23] hover:underline",
                    children: "Forgot Password?"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400", children: /* @__PURE__ */ jsx(Lock, { className: "w-4 h-4" }) }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    id: "password",
                    type: showPassword ? "text" : "password",
                    name: "password",
                    value: data.password,
                    autoComplete: "current-password",
                    required: true,
                    onChange: (e) => setData("password", e.target.value),
                    placeholder: "••••••••",
                    className: `w-full pl-10 pr-10 py-2.5 text-xs rounded-xl border transition ${errors.password ? "border-rose-300 focus:border-rose-500 focus:ring-rose-200 bg-rose-50/20" : "border-gray-300 focus:border-[#EF4A23] focus:ring-orange-100 bg-white"} focus:outline-none focus:ring-4`
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowPassword(!showPassword),
                    className: "absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 transition",
                    children: showPassword ? /* @__PURE__ */ jsx(EyeOff, { className: "w-4 h-4" }) : /* @__PURE__ */ jsx(Eye, { className: "w-4 h-4" })
                  }
                )
              ] }),
              errors.password && /* @__PURE__ */ jsx("p", { className: "mt-1.5 text-xs text-rose-600 font-medium", children: errors.password })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between pt-1", children: /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer select-none", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  name: "remember",
                  checked: data.remember,
                  onChange: (e) => setData("remember", e.target.checked),
                  className: "w-4 h-4 text-[#EF4A23] border-gray-300 rounded focus:ring-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-600", children: "Keep me logged in" })
            ] }) }),
            /* @__PURE__ */ jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsxs(
              "button",
              {
                type: "submit",
                disabled: processing,
                className: "w-full py-3 px-4 rounded-xl bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/35 transition disabled:opacity-50",
                children: [
                  /* @__PURE__ */ jsx("span", { children: processing ? "Signing In..." : "Sign In to Account" }),
                  /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4" })
                ]
              }
            ) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 text-center text-xs text-gray-500", children: [
            "Don't have a ",
            settings?.site_name || "Tech Shoppers",
            " account?",
            " ",
            /* @__PURE__ */ jsx(
              Link,
              {
                href: route("register"),
                className: "font-bold text-[#EF4A23] hover:underline",
                children: "Register Now"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-8 pt-4 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-400", children: [
          /* @__PURE__ */ jsx("span", { children: "Internal Staff Member?" }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("admin.login"),
              className: "font-bold text-gray-700 hover:text-[#EF4A23] transition flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsx(Shield, { className: "w-3.5 h-3.5 text-gray-500" }),
                /* @__PURE__ */ jsx("span", { children: "Admin Portal →" })
              ]
            }
          )
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("footer", { className: "py-4 text-center text-xs text-gray-400 border-t border-gray-200 bg-white", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " ",
      settings?.site_name || "Tech Shoppers",
      ". All Rights Reserved."
    ] })
  ] });
}
export {
  Login as default
};
