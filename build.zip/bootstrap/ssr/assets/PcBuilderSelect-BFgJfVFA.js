import { jsxs, jsx } from "react/jsx-runtime";
import "react";
import { Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { ArrowLeft, Plus } from "lucide-react";
function PcBuilderSelect({ componentSlug, slotId, category, products }) {
  const handleSelectProduct = (product) => {
    let saved = {};
    try {
      saved = JSON.parse(localStorage.getItem("startech_pc_build") || "{}");
    } catch (e) {
    }
    const regularPrice = parseFloat(product.regular_price) || 0;
    const specialPrice = product.special_price ? parseFloat(product.special_price) : null;
    const effectivePrice = specialPrice !== null && specialPrice > 0 ? specialPrice : regularPrice;
    const cleanProduct = {
      id: product.id,
      name: product.name,
      slug: product.slug,
      thumbnail: product.thumbnail,
      regular_price: regularPrice,
      special_price: specialPrice,
      price: effectivePrice,
      model: product.model
    };
    const targetKey = slotId || componentSlug;
    saved[targetKey] = cleanProduct;
    localStorage.setItem("startech_pc_build", JSON.stringify(saved));
    router.visit(route("pcbuilder.index"));
  };
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: `Choose ${category?.name || "Component"} - PC Builder`, children: [
    /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between mb-6", children: /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("pcbuilder.index"),
          className: "inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#EF4A23] font-semibold mb-2",
          children: [
            /* @__PURE__ */ jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsx("span", { children: "Back to PC Builder" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs("h1", { className: "text-xl md:text-2xl font-black text-gray-900", children: [
        "Select ",
        category?.name || "Component"
      ] })
    ] }) }),
    products.data.length > 0 ? /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden divide-y divide-gray-100", children: products.data.map((product) => {
      const reg = parseFloat(product.regular_price) || 0;
      const spec = product.special_price ? parseFloat(product.special_price) : null;
      const displayPrice = spec !== null && spec > 0 ? spec : reg;
      return /* @__PURE__ */ jsxs("div", { className: "p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-gray-50/50 transition", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 flex-1", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              src: product.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
              alt: product.name,
              className: "w-16 h-16 object-contain rounded-lg border border-gray-100 p-1 bg-white shrink-0"
            }
          ),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900 hover:text-[#EF4A23] transition", children: product.name }),
            product.key_features && Array.isArray(product.key_features) && /* @__PURE__ */ jsx("ul", { className: "text-xs text-gray-500 mt-1 flex flex-wrap gap-x-4 gap-y-0.5", children: product.key_features.slice(0, 3).map((f, i) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsx("span", { className: "w-1 h-1 rounded-full bg-gray-400" }),
              /* @__PURE__ */ jsx("span", { children: f })
            ] }, i)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 self-end sm:self-center", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-base font-black text-[#EF4A23] block", children: [
              "৳",
              displayPrice.toLocaleString()
            ] }),
            spec !== null && reg > spec && /* @__PURE__ */ jsxs("span", { className: "text-xs text-gray-400 line-through", children: [
              "৳",
              reg.toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => handleSelectProduct(product),
              className: "bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2.5 px-4 rounded-xl flex items-center gap-1.5 transition shadow-sm",
              children: [
                /* @__PURE__ */ jsx(Plus, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: "Add" })
              ]
            }
          )
        ] })
      ] }, product.id);
    }) }) : /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200 p-12 text-center", children: /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-gray-700", children: "No components available in this category." }) })
  ] });
}
export {
  PcBuilderSelect as default
};
