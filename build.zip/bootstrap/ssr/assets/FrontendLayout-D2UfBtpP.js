import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useState, useRef, useEffect } from "react";
import { usePage, Link, router, Head } from "@inertiajs/react";
import { PhoneCall, MapPin, Menu, Search, Cpu, ShoppingCart, ChevronDown, User, LogOut, X, Percent, Gift, Home, ChevronRight, Truck, ShieldCheck, RefreshCw, Mail, CheckCircle2, AlertCircle } from "lucide-react";
function Header() {
  const { auth, cart, settings, categoriesNav = [] } = usePage().props;
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState({});
  const searchRef = useRef(null);
  const mobileSearchRef = useRef(null);
  const userDropdownRef = useRef(null);
  const cartCount = Array.isArray(cart) ? cart.reduce((sum, item) => sum + (Number(item?.quantity) || 1), 0) : Number(cart?.count) || (Array.isArray(cart?.items) ? cart.items.reduce((sum, item) => sum + (Number(item?.quantity) || 1), 0) : 0);
  const cartTotal = Array.isArray(cart) ? cart.reduce((sum, item) => sum + (Number(item?.price) || 0) * (Number(item?.quantity) || 1), 0) : Number(cart?.total) || (Array.isArray(cart?.items) ? cart.items.reduce((sum, item) => sum + (Number(item?.price) || 0) * (Number(item?.quantity) || 1), 0) : 0);
  useEffect(() => {
    if (searchQuery.trim().length >= 2) {
      const timer = setTimeout(() => {
        fetch(`/api/search/autocomplete?q=${encodeURIComponent(searchQuery)}`).then((res) => res.json()).then((data) => {
          setSuggestions(data);
          setShowSuggestions(true);
        }).catch(() => setSuggestions([]));
      }, 250);
      return () => clearTimeout(timer);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchQuery]);
  useEffect(() => {
    function handleClickOutside(e) {
      if (searchRef.current && !searchRef.current.contains(e.target) && mobileSearchRef.current && !mobileSearchRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [mobileMenuOpen]);
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowSuggestions(false);
      setMobileMenuOpen(false);
      router.get(route("search"), { q: searchQuery });
    }
  };
  const toggleCategoryExpand = (catId) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [catId]: !prev[catId]
    }));
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      "header",
      {
        className: "w-full text-white",
        style: { backgroundColor: settings?.header_bg_color || "#081621" },
        children: [
          /* @__PURE__ */ jsx("div", { className: "border-b border-gray-800 text-[11px] sm:text-xs py-1.5 px-3 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center space-x-3 sm:space-x-6 text-gray-300", children: [
              /* @__PURE__ */ jsxs(
                "a",
                {
                  href: `tel:${settings?.hotline || "16793"}`,
                  className: "flex items-center gap-1.5 font-semibold hover:opacity-85 transition",
                  style: { color: settings?.primary_color || "#EF4A23" },
                  children: [
                    /* @__PURE__ */ jsx(PhoneCall, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }),
                    /* @__PURE__ */ jsxs("span", { children: [
                      "Hotline: ",
                      settings?.hotline || "16793"
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "hidden sm:inline font-normal text-gray-400", children: [
                      "(",
                      settings?.working_hours || "10 AM - 7 PM",
                      ")"
                    ] })
                  ]
                }
              ),
              settings?.whatsapp && /* @__PURE__ */ jsxs(
                "a",
                {
                  href: `https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, "")}?text=Hello%20${encodeURIComponent(settings?.site_name || "Tech Shoppers")}%2C%20I%20have%20an%20inquiry.`,
                  target: "_blank",
                  rel: "noreferrer",
                  className: "hidden md:flex items-center gap-1.5 text-emerald-400 font-semibold hover:text-emerald-300 transition",
                  children: [
                    /* @__PURE__ */ jsx("svg", { className: "w-3.5 h-3.5 shrink-0", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" }) }),
                    /* @__PURE__ */ jsxs("span", { children: [
                      "WhatsApp: ",
                      settings.whatsapp
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxs("span", { className: "hidden lg:inline-flex items-center gap-1", children: [
                /* @__PURE__ */ jsx(MapPin, { className: "w-3 h-3 text-gray-400" }),
                " Over 18+ Outlets Nationwide"
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center space-x-2 sm:space-x-4 text-gray-300 text-[11px] sm:text-xs", children: [
              /* @__PURE__ */ jsx(Link, { href: "/page/order-tracking", className: "hover:text-orange-400 transition hidden sm:inline", children: "Order Tracking" }),
              /* @__PURE__ */ jsx("span", { className: "text-gray-600 hidden sm:inline", children: "|" }),
              /* @__PURE__ */ jsx(Link, { href: "/emi-calculation", className: "hover:text-orange-400 transition font-medium", children: "0% EMI Calculator" }),
              /* @__PURE__ */ jsx("span", { className: "text-gray-600", children: "|" }),
              /* @__PURE__ */ jsx(Link, { href: "/page/service-complain", className: "hover:text-orange-400 transition", children: "Warranty & RMA" })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5 flex items-center justify-between gap-3 sm:gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 sm:gap-3", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setMobileMenuOpen(true),
                  className: "lg:hidden text-gray-300 hover:text-white p-1 rounded-lg hover:bg-gray-800 transition",
                  "aria-label": "Open Navigation Menu",
                  children: /* @__PURE__ */ jsx(Menu, { className: "w-6 h-6" })
                }
              ),
              /* @__PURE__ */ jsx(Link, { href: route("home"), className: "flex items-center gap-1.5 group shrink-0", children: settings?.site_logo ? /* @__PURE__ */ jsx(
                "img",
                {
                  src: settings.site_logo,
                  alt: settings?.site_name || "Logo",
                  className: "h-8 sm:h-9 max-w-[170px] object-contain"
                }
              ) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx("span", { className: "text-xl sm:text-2xl font-black tracking-tight text-white group-hover:text-gray-100", children: settings?.site_name ? settings.site_name.split(" ")[0] : "TECH" }),
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    className: "text-xl sm:text-2xl font-black tracking-tight",
                    style: { color: settings?.primary_color || "#EF4A23" },
                    children: settings?.site_name ? settings.site_name.split(" ").slice(1).join(" ") || "SHOPPERS" : "SHOPPERS"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    className: "w-2 h-2 rounded-full animate-pulse",
                    style: { backgroundColor: settings?.primary_color || "#EF4A23" }
                  }
                )
              ] }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "hidden lg:flex flex-1 max-w-2xl relative", ref: searchRef, children: [
              /* @__PURE__ */ jsxs("form", { onSubmit: handleSearchSubmit, className: "relative w-full flex items-center", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: searchQuery,
                    onChange: (e) => setSearchQuery(e.target.value),
                    onFocus: () => suggestions.length > 0 && setShowSuggestions(true),
                    placeholder: "Search laptop, desktop, graphics card, processor, monitor...",
                    className: "w-full bg-[#112233] text-sm text-gray-100 placeholder-gray-400 pl-4 pr-12 py-2.5 rounded-full border border-gray-700 focus:outline-none focus:border-[#EF4A23] focus:ring-1 focus:ring-[#EF4A23] transition-all"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "submit",
                    className: "absolute right-1 top-1 bottom-1 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white rounded-full flex items-center justify-center transition",
                    title: "Search",
                    children: /* @__PURE__ */ jsx(Search, { className: "w-4 h-4" })
                  }
                )
              ] }),
              showSuggestions && suggestions.length > 0 && /* @__PURE__ */ jsxs("div", { className: "absolute top-full left-0 right-0 mt-2 bg-[#0e1d2c] border border-gray-700 rounded-xl shadow-2xl overflow-hidden z-50", children: [
                /* @__PURE__ */ jsx("div", { className: "p-2 border-b border-gray-800 text-xs font-semibold text-gray-400 uppercase tracking-wider", children: "Matching Products" }),
                /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-800/60 max-h-80 overflow-y-auto", children: suggestions.map((item) => /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route("product.show", item.slug),
                    onClick: () => setShowSuggestions(false),
                    className: "flex items-center gap-3 p-3 hover:bg-[#162a3d] transition group",
                    children: [
                      /* @__PURE__ */ jsx(
                        "img",
                        {
                          src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                          alt: item.name,
                          className: "w-10 h-10 object-cover rounded bg-white p-0.5 shrink-0"
                        }
                      ),
                      /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
                        /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-gray-200 group-hover:text-[#EF4A23] truncate transition", children: item.name }),
                        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: item.model || "" })
                      ] }),
                      /* @__PURE__ */ jsx("div", { className: "text-right shrink-0", children: /* @__PURE__ */ jsxs("span", { className: "text-sm font-bold text-[#EF4A23]", children: [
                        "৳",
                        (item.special_price || item.regular_price).toLocaleString()
                      ] }) })
                    ]
                  },
                  item.id
                )) }),
                /* @__PURE__ */ jsx("div", { className: "p-2 bg-[#091520] text-center border-t border-gray-800", children: /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: handleSearchSubmit,
                    className: "text-xs text-orange-400 hover:text-orange-300 font-medium",
                    children: [
                      'View all results for "',
                      searchQuery,
                      '" →'
                    ]
                  }
                ) })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 sm:gap-3", children: [
              /* @__PURE__ */ jsxs(
                Link,
                {
                  href: "/pc-builder",
                  className: "flex items-center gap-1.5 sm:gap-2 text-xs font-semibold bg-[#1a2f42] hover:bg-[#223d56] text-[#EF4A23] px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-lg border border-orange-500/30 transition shadow-sm",
                  children: [
                    /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4 text-[#EF4A23]" }),
                    /* @__PURE__ */ jsxs("div", { className: "text-left hidden xs:block", children: [
                      /* @__PURE__ */ jsx("span", { className: "block text-gray-400 text-[9px] uppercase font-normal leading-none", children: "Custom" }),
                      /* @__PURE__ */ jsx("span", { className: "text-white font-bold text-[11px] sm:text-xs", children: "PC Builder" })
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Link,
                {
                  href: route("cart.index"),
                  className: "relative flex items-center gap-1.5 sm:gap-2 text-xs font-semibold bg-gray-800/80 hover:bg-gray-800 text-white px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg transition",
                  children: [
                    /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                      /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4 sm:w-5 sm:h-5 text-[#EF4A23]" }),
                      cartCount > 0 && /* @__PURE__ */ jsx("span", { className: "absolute -top-2 -right-2 bg-[#EF4A23] text-white text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center animate-pulse", children: cartCount })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "hidden md:block text-left", children: [
                      /* @__PURE__ */ jsx("span", { className: "block text-gray-400 text-[9px] uppercase font-normal leading-none", children: "Cart" }),
                      /* @__PURE__ */ jsxs("span", { children: [
                        "৳",
                        cartTotal.toLocaleString()
                      ] })
                    ] })
                  ]
                }
              ),
              auth?.user ? /* @__PURE__ */ jsxs("div", { className: "relative", ref: userDropdownRef, children: [
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setUserMenuOpen(!userMenuOpen),
                    className: "flex items-center gap-1.5 sm:gap-2 text-xs font-semibold bg-gray-800/80 hover:bg-gray-800 text-white px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg transition",
                    "aria-expanded": userMenuOpen,
                    title: "Account Menu",
                    children: [
                      /* @__PURE__ */ jsx("div", { className: "w-5 h-5 rounded-full bg-[#EF4A23] text-white flex items-center justify-center font-bold text-[10px]", children: auth.user.name?.charAt(0).toUpperCase() || "U" }),
                      /* @__PURE__ */ jsx("span", { className: "hidden sm:inline font-medium text-xs truncate max-w-[85px]", children: auth.user.name.split(" ")[0] }),
                      /* @__PURE__ */ jsx(ChevronDown, { className: `w-3 h-3 text-gray-400 transition-transform duration-200 ${userMenuOpen ? "rotate-180 text-orange-400" : ""}` })
                    ]
                  }
                ),
                userMenuOpen && /* @__PURE__ */ jsxs("div", { className: "absolute right-0 mt-2 w-56 bg-[#0c1a26] border border-gray-700/80 rounded-2xl shadow-2xl py-1.5 z-50 divide-y divide-gray-800/80 text-xs animate-in fade-in zoom-in-95 duration-150", children: [
                  /* @__PURE__ */ jsxs("div", { className: "px-3.5 py-2.5 bg-[#081621]/60", children: [
                    /* @__PURE__ */ jsx("p", { className: "font-bold text-white text-xs truncate", children: auth.user.name }),
                    /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-400 truncate mt-0.5", children: auth.user.email }),
                    auth.user.role === "admin" ? /* @__PURE__ */ jsx("span", { className: "inline-block mt-1 text-[9px] bg-red-500/20 text-red-300 border border-red-500/30 px-1.5 py-0.2 rounded font-mono font-bold uppercase", children: "Admin" }) : /* @__PURE__ */ jsx("span", { className: "inline-block mt-1 text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono font-bold uppercase", children: "Customer" })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "py-1", children: auth.user.role === "admin" ? /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: route("admin.dashboard"),
                      onClick: () => setUserMenuOpen(false),
                      className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                      children: [
                        /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-orange-400" }),
                        /* @__PURE__ */ jsx("span", { children: "Admin Dashboard" })
                      ]
                    }
                  ) : /* @__PURE__ */ jsxs(Fragment, { children: [
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        href: route("dashboard"),
                        onClick: () => setUserMenuOpen(false),
                        className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                        children: [
                          /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-orange-400" }),
                          /* @__PURE__ */ jsx("span", { children: "Customer Account" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        href: "/dashboard?tab=orders",
                        onClick: () => setUserMenuOpen(false),
                        className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                        children: [
                          /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4 text-blue-400" }),
                          /* @__PURE__ */ jsx("span", { children: "Order History" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        href: "/dashboard?tab=pc_builds",
                        onClick: () => setUserMenuOpen(false),
                        className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                        children: [
                          /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4 text-purple-400" }),
                          /* @__PURE__ */ jsx("span", { children: "Saved PC Builds" })
                        ]
                      }
                    )
                  ] }) }),
                  /* @__PURE__ */ jsx("div", { className: "py-1", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: route("logout"),
                      method: "post",
                      as: "button",
                      onClick: () => setUserMenuOpen(false),
                      className: "w-full flex items-center gap-2.5 px-3.5 py-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition font-bold",
                      children: [
                        /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4 text-rose-400" }),
                        /* @__PURE__ */ jsx("span", { children: "Log Out" })
                      ]
                    }
                  ) })
                ] })
              ] }) : /* @__PURE__ */ jsxs(
                Link,
                {
                  href: route("login"),
                  className: "flex items-center gap-1 sm:gap-1.5 text-xs font-semibold bg-[#EF4A23] hover:bg-[#d63c17] text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition shadow-sm",
                  children: [
                    /* @__PURE__ */ jsx(User, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsx("span", { children: "Login" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "lg:hidden px-3 sm:px-6 pb-2.5 pt-0.5", ref: mobileSearchRef, children: [
            /* @__PURE__ */ jsxs("form", { onSubmit: handleSearchSubmit, className: "relative flex items-center", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: searchQuery,
                  onChange: (e) => setSearchQuery(e.target.value),
                  onFocus: () => suggestions.length > 0 && setShowSuggestions(true),
                  placeholder: "Search laptop, desktop, component...",
                  className: "w-full bg-[#112233] text-xs text-gray-100 placeholder-gray-400 pl-3.5 pr-10 py-2 rounded-xl border border-gray-700 focus:outline-none focus:border-[#EF4A23]"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "submit",
                  className: "absolute right-1 top-1 bottom-1 px-3 bg-[#EF4A23] text-white rounded-lg flex items-center justify-center",
                  children: /* @__PURE__ */ jsx(Search, { className: "w-3.5 h-3.5" })
                }
              )
            ] }),
            showSuggestions && suggestions.length > 0 && /* @__PURE__ */ jsx("div", { className: "absolute left-3 right-3 mt-1.5 bg-[#0e1d2c] border border-gray-700 rounded-xl shadow-2xl overflow-hidden z-50", children: /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-800 max-h-64 overflow-y-auto", children: suggestions.map((item) => /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("product.show", item.slug),
                onClick: () => setShowSuggestions(false),
                className: "flex items-center gap-2.5 p-2.5 hover:bg-[#162a3d]",
                children: [
                  /* @__PURE__ */ jsx(
                    "img",
                    {
                      src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=80",
                      alt: item.name,
                      className: "w-8 h-8 object-cover rounded bg-white p-0.5 shrink-0"
                    }
                  ),
                  /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0 text-left", children: [
                    /* @__PURE__ */ jsx("p", { className: "text-xs font-medium text-gray-200 truncate", children: item.name }),
                    /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-[#EF4A23] font-bold", children: [
                      "৳",
                      (item.special_price || item.regular_price).toLocaleString()
                    ] })
                  ] })
                ]
              },
              item.id
            )) }) })
          ] })
        ]
      }
    ),
    mobileMenuOpen && /* @__PURE__ */ jsxs("div", { className: "fixed inset-0 z-50 lg:hidden flex print:hidden", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity",
          onClick: () => setMobileMenuOpen(false)
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "relative w-4/5 max-w-sm bg-[#081621] text-white h-full flex flex-col shadow-2xl z-10 animate-in slide-in-from-left duration-250", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 border-b border-gray-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              href: "/",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-1.5",
              children: settings?.site_logo ? /* @__PURE__ */ jsx("img", { src: settings.site_logo, alt: settings?.site_name || "Logo", className: "h-7 max-w-[140px] object-contain" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx("span", { className: "text-xl font-black text-white", children: settings?.site_name ? settings.site_name.split(" ")[0] : "TECH" }),
                /* @__PURE__ */ jsx("span", { className: "text-xl font-black", style: { color: settings?.primary_color || "#EF4A23" }, children: settings?.site_name ? settings.site_name.split(" ").slice(1).join(" ") || "SHOPPERS" : "SHOPPERS" })
              ] })
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setMobileMenuOpen(false),
              className: "p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-gray-800 transition",
              children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "p-3 bg-[#112233] border-b border-gray-800 flex items-center justify-between text-xs", children: auth?.user ? /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-[#EF4A23] flex items-center justify-center font-bold text-white text-xs shrink-0", children: auth.user.name?.charAt(0) || "U" }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "font-bold text-white truncate max-w-[120px]", children: auth.user.name }),
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: auth.user.role === "admin" ? route("admin.dashboard") : route("dashboard"),
                  onClick: () => setMobileMenuOpen(false),
                  className: "text-[10px] text-orange-400 hover:underline block truncate",
                  children: auth.user.role === "admin" ? "Admin Panel" : "My Account"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("logout"),
              method: "post",
              as: "button",
              onClick: () => setMobileMenuOpen(false),
              className: "shrink-0 flex items-center gap-1 text-[11px] font-bold text-rose-300 hover:text-white bg-rose-500/20 hover:bg-rose-500/30 px-2.5 py-1.5 rounded-lg border border-rose-500/30 transition",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-3.5 h-3.5 text-rose-400" }),
                /* @__PURE__ */ jsx("span", { children: "Logout" })
              ]
            }
          )
        ] }) : /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full", children: [
          /* @__PURE__ */ jsx("span", { className: "text-gray-300", children: "Welcome, Guest" }),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("login"),
              onClick: () => setMobileMenuOpen(false),
              className: "bg-[#EF4A23] text-white font-bold px-3 py-1 rounded-lg text-xs",
              children: "Login / Register"
            }
          )
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 overflow-y-auto divide-y divide-gray-800/80 text-xs", children: [
          /* @__PURE__ */ jsx("div", { className: "p-2 font-bold uppercase text-[10px] text-gray-400 tracking-wider", children: "All Categories" }),
          categoriesNav.map((cat) => {
            const hasChildren = cat.children && cat.children.length > 0;
            const isExpanded = !!expandedCategories[cat.id];
            return /* @__PURE__ */ jsxs("div", { className: "py-0.5", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 hover:bg-[#112233] transition", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("category.show", cat.slug),
                    onClick: () => setMobileMenuOpen(false),
                    className: "flex-1 font-semibold text-gray-200 hover:text-[#EF4A23]",
                    children: cat.name
                  }
                ),
                hasChildren && /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleCategoryExpand(cat.id),
                    className: "p-1 text-gray-400 hover:text-white",
                    children: /* @__PURE__ */ jsx(ChevronDown, { className: `w-4 h-4 transition-transform duration-200 ${isExpanded ? "rotate-180 text-[#EF4A23]" : ""}` })
                  }
                )
              ] }),
              hasChildren && isExpanded && /* @__PURE__ */ jsx("div", { className: "bg-[#0b1b28] py-1 pl-6 pr-4 space-y-1", children: cat.children.map((child) => /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("category.show", child.slug),
                  onClick: () => setMobileMenuOpen(false),
                  className: "block py-1.5 text-[11px] text-gray-400 hover:text-white hover:text-orange-400 transition",
                  children: child.name
                },
                child.id
              )) })
            ] }, cat.id);
          }),
          /* @__PURE__ */ jsx("div", { className: "p-2 font-bold uppercase text-[10px] text-gray-400 tracking-wider", children: "Quick Features" }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/pc-builder",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-orange-400 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Custom PC Builder" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/emi-calculation",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-gray-300 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(Percent, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "0% EMI Calculator" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/page/order-tracking",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-gray-300 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(Gift, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Order Tracking" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: `tel:${settings?.hotline || "16793"}`,
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-emerald-400 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Hotline: ",
                  settings?.hotline || "16793"
                ] })
              ]
            }
          ),
          auth?.user && /* @__PURE__ */ jsx("div", { className: "p-3 border-t border-gray-800/80 mt-2", children: /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("logout"),
              method: "post",
              as: "button",
              onClick: () => setMobileMenuOpen(false),
              className: "w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 font-bold text-xs border border-rose-500/30 transition",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Sign Out" })
              ]
            }
          ) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("nav", { className: "fixed bottom-0 left-0 right-0 z-40 bg-[#081621] border-t border-gray-800 lg:hidden shadow-2xl px-2 py-1.5 flex items-center justify-around text-[10px] text-gray-300 select-none print:hidden", children: [
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/",
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx(Home, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Home" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/",
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx(Gift, { className: "w-4 h-4 text-amber-400" }),
            /* @__PURE__ */ jsx("span", { children: "Offers" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/pc-builder",
          className: "flex flex-col items-center gap-0.5 text-[#EF4A23] font-bold transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-7 h-7 -mt-3.5 rounded-full bg-[#EF4A23] text-white flex items-center justify-center shadow-lg border-2 border-[#081621]", children: /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx("span", { children: "PC Build" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("cart.index"),
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2 relative",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4" }),
              cartCount > 0 && /* @__PURE__ */ jsx("span", { className: "absolute -top-1.5 -right-2 bg-[#EF4A23] text-white text-[9px] font-bold rounded-full h-3.5 w-3.5 flex items-center justify-center", children: cartCount })
            ] }),
            /* @__PURE__ */ jsx("span", { children: "Cart" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: auth?.user ? auth.user.role === "admin" ? route("admin.dashboard") : route("dashboard") : route("login"),
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx(User, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Account" })
          ]
        }
      )
    ] })
  ] });
}
function Navbar() {
  const { categoriesNav, settings } = usePage().props;
  const [activeHover, setActiveHover] = useState(null);
  if (!categoriesNav || categoriesNav.length === 0) return null;
  return /* @__PURE__ */ jsx(
    "nav",
    {
      className: "w-full border-t border-gray-800 text-white relative z-40 hidden lg:block print:hidden",
      style: { backgroundColor: settings?.header_bg_color || "#081621" },
      children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsx("ul", { className: "flex items-center justify-between text-xs font-semibold", children: categoriesNav.map((cat) => {
        const hasChildren = cat.children && cat.children.length > 0;
        return /* @__PURE__ */ jsxs(
          "li",
          {
            className: "relative group py-2.5",
            onMouseEnter: () => setActiveHover(cat.id),
            onMouseLeave: () => setActiveHover(null),
            children: [
              /* @__PURE__ */ jsxs(
                Link,
                {
                  href: route("category.show", cat.slug),
                  className: "flex items-center gap-1 text-gray-200 hover:text-[#EF4A23] transition whitespace-nowrap px-2 py-1",
                  children: [
                    /* @__PURE__ */ jsx("span", { children: cat.name }),
                    hasChildren && /* @__PURE__ */ jsx(ChevronDown, { className: "w-3 h-3 text-gray-400 group-hover:text-[#EF4A23]" })
                  ]
                }
              ),
              hasChildren && activeHover === cat.id && /* @__PURE__ */ jsxs("div", { className: "absolute top-full left-0 w-64 bg-[#0e1e2d] border border-gray-700 rounded-b-lg shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150", children: [
                /* @__PURE__ */ jsxs("div", { className: "text-[11px] font-bold text-gray-400 px-4 py-1.5 uppercase tracking-wider border-b border-gray-800", children: [
                  cat.name,
                  " Categories"
                ] }),
                /* @__PURE__ */ jsx("div", { className: "py-1", children: cat.children.map((child) => /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route("category.show", child.slug),
                    className: "flex items-center justify-between px-4 py-2 text-xs text-gray-300 hover:text-white hover:bg-[#182f45] transition",
                    children: [
                      /* @__PURE__ */ jsx("span", { children: child.name }),
                      /* @__PURE__ */ jsx(ChevronRight, { className: "w-3 h-3 text-gray-500" })
                    ]
                  },
                  child.id
                )) })
              ] })
            ]
          },
          cat.id
        );
      }) }) })
    }
  );
}
const FacebookIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" }) });
const YoutubeIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" }) });
const InstagramIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" }) });
const TwitterIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" }) });
const WhatsAppIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.669-.699c.974.557 1.956.884 3.01.884l.003-.001c3.181 0 5.767-2.586 5.768-5.766 0-1.54-.599-2.989-1.688-4.079-1.09-1.09-2.538-1.69-4.29-1.69zm7.042 12.809c-1.89 1.889-4.398 2.93-7.07 2.93-.007 0-.014 0-.02 0-2.433 0-4.814-.654-6.885-1.891l-4.798 1.258 1.28-4.673c-1.357-2.148-2.073-4.636-2.072-7.189.003-7.513 6.118-13.626 13.633-13.626 3.638 0 7.059 1.417 9.632 3.99 2.573 2.573 3.99 5.993 3.99 9.632 0 3.638-1.417 7.058-3.69 9.569z" }) });
const LinkedinIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" }) });
function Footer() {
  const { settings } = usePage().props;
  const primaryColor = settings?.primary_color || "#EF4A23";
  const footerBgColor = settings?.footer_bg_color || "#081621";
  return /* @__PURE__ */ jsxs(
    "footer",
    {
      className: "w-full text-gray-400 text-xs border-t border-gray-800 pt-12 pb-8 mt-16 print:hidden",
      style: { backgroundColor: footerBgColor },
      children: [
        /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10 border-b border-gray-800", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 text-gray-300", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 p-4 rounded-xl bg-[#0f2131]/70 border border-gray-800", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "w-12 h-12 rounded-full flex items-center justify-center",
                style: { backgroundColor: `${primaryColor}1A`, color: primaryColor },
                children: /* @__PURE__ */ jsx(Truck, { className: "w-6 h-6" })
              }
            ),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h4", { className: "text-sm font-bold text-white", children: "Fast Home Delivery" }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Within 24 Hours in Dhaka & Express Nationwide" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 p-4 rounded-xl bg-[#0f2131]/70 border border-gray-800", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "w-12 h-12 rounded-full flex items-center justify-center",
                style: { backgroundColor: `${primaryColor}1A`, color: primaryColor },
                children: /* @__PURE__ */ jsx(ShieldCheck, { className: "w-6 h-6" })
              }
            ),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h4", { className: "text-sm font-bold text-white", children: "100% Genuine Products" }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Official Brand Warranty & Verified Authentic" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 p-4 rounded-xl bg-[#0f2131]/70 border border-gray-800", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "w-12 h-12 rounded-full flex items-center justify-center",
                style: { backgroundColor: `${primaryColor}1A`, color: primaryColor },
                children: /* @__PURE__ */ jsx(RefreshCw, { className: "w-6 h-6" })
              }
            ),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h4", { className: "text-sm font-bold text-white", children: "Easy Return & Warranty" }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Hassle-free replacement policy & repair support" })
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              "h3",
              {
                className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 pl-2",
                style: { borderColor: primaryColor },
                children: "Support & Helpline"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "p-3 bg-[#0e1d2c]/80 rounded-lg border border-gray-800", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: settings?.working_hours || "10:00 AM - 7:00 PM" }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1", children: [
                  /* @__PURE__ */ jsx(PhoneCall, { className: "w-5 h-5", style: { color: primaryColor } }),
                  /* @__PURE__ */ jsx("span", { className: "text-xl font-black text-white", children: settings?.hotline || "16793" })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-3 bg-[#0e1d2c]/80 rounded-lg border border-gray-800", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: "Store Support" }),
                /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-white", children: settings?.phone || "09678002003" })
              ] }),
              settings?.whatsapp && /* @__PURE__ */ jsxs(
                "a",
                {
                  href: `https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, "")}?text=Hello%20${encodeURIComponent(settings?.site_name || "Support")}%2C%20I%20have%20an%20inquiry.`,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "p-3 bg-[#0e1d2c]/80 hover:bg-[#112437] rounded-lg border border-emerald-500/30 flex items-center justify-between transition group",
                  children: [
                    /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("span", { className: "text-[11px] text-emerald-400 block font-bold", children: "WhatsApp Direct" }),
                      /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-white", children: settings.whatsapp })
                    ] }),
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition", children: /* @__PURE__ */ jsx(WhatsAppIcon, { className: "w-4 h-4" }) })
                  ]
                }
              ),
              settings?.email && /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-400 flex items-center gap-2 pt-1", children: [
                /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4 shrink-0", style: { color: primaryColor } }),
                /* @__PURE__ */ jsx("a", { href: `mailto:${settings.email}`, className: "hover:text-white transition", children: settings.email })
              ] }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-400 flex items-start gap-2 pt-1", children: [
                /* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 shrink-0 mt-0.5", style: { color: primaryColor } }),
                /* @__PURE__ */ jsx("span", { children: settings?.address || "28 Kazi Nazrul Islam Avenue, Banglamotor, Dhaka 1000" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs(
              "h3",
              {
                className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 pl-2",
                style: { borderColor: primaryColor },
                children: [
                  "About ",
                  settings?.site_name?.split(" ")[0] || "Tech Shoppers"
                ]
              }
            ),
            /* @__PURE__ */ jsxs("ul", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/about-us", className: "hover:text-white transition", children: "About Us" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/branches-outlets", className: "hover:text-white transition", children: "Branches & Outlets" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/terms-conditions", className: "hover:text-white transition", children: "Terms and Conditions" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/privacy-policy", className: "hover:text-white transition", children: "Privacy Policy" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/emi-calculation", className: "hover:text-white transition", children: "Reward Points & EMI Policy" }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              "h3",
              {
                className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 pl-2",
                style: { borderColor: primaryColor },
                children: "Customer Help"
              }
            ),
            /* @__PURE__ */ jsxs("ul", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/pc-builder-guide", className: "hover:text-white transition", children: "PC Builder Guide" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/cart", className: "hover:text-white transition", children: "Shopping Cart" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/order-tracking", className: "hover:text-white transition", children: "Order Tracking" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/emi-calculation", className: "hover:text-white transition", children: "EMI Calculation" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/service-complain", className: "hover:text-white transition", children: "Online Service & Complain" }) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/contact-us", className: "hover:text-white transition", children: "Contact Us" }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              "h3",
              {
                className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 pl-2",
                style: { borderColor: primaryColor },
                children: "Stay Connected"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mb-4 leading-relaxed", children: settings?.footer_about || "Tech Shoppers is the leading Computer, Laptop & Gaming accessory retailer in Bangladesh." }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5", children: [
              /* @__PURE__ */ jsx(
                "a",
                {
                  href: settings?.facebook_url || "https://facebook.com",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "w-8 h-8 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center hover:bg-blue-600 hover:text-white transition",
                  title: "Facebook",
                  children: /* @__PURE__ */ jsx(FacebookIcon, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsx(
                "a",
                {
                  href: settings?.youtube_url || "https://youtube.com",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "w-8 h-8 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center hover:bg-red-600 hover:text-white transition",
                  title: "YouTube",
                  children: /* @__PURE__ */ jsx(YoutubeIcon, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsx(
                "a",
                {
                  href: settings?.instagram_url || "https://instagram.com",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "w-8 h-8 rounded-full bg-pink-600/20 text-pink-400 flex items-center justify-center hover:bg-pink-600 hover:text-white transition",
                  title: "Instagram",
                  children: /* @__PURE__ */ jsx(InstagramIcon, { className: "w-4 h-4" })
                }
              ),
              settings?.twitter_url && /* @__PURE__ */ jsx(
                "a",
                {
                  href: settings.twitter_url,
                  target: "_blank",
                  rel: "noreferrer",
                  className: "w-8 h-8 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center hover:bg-sky-500 hover:text-white transition",
                  title: "Twitter / X",
                  children: /* @__PURE__ */ jsx(TwitterIcon, { className: "w-4 h-4" })
                }
              ),
              settings?.linkedin_url && /* @__PURE__ */ jsx(
                "a",
                {
                  href: settings.linkedin_url,
                  target: "_blank",
                  rel: "noreferrer",
                  className: "w-8 h-8 rounded-full bg-blue-700/20 text-blue-300 flex items-center justify-center hover:bg-blue-700 hover:text-white transition",
                  title: "LinkedIn",
                  children: /* @__PURE__ */ jsx(LinkedinIcon, { className: "w-4 h-4" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "mt-6 pt-4 border-t border-gray-800", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-500 block mb-2", children: "Accepted Payment Methods" }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2 text-[10px] font-bold text-gray-300", children: [
                /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-pink-900/40 text-pink-300 rounded border border-pink-700/50", children: "bKash" }),
                /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-orange-900/40 text-orange-300 rounded border border-orange-700/50", children: "Nagad" }),
                /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-purple-900/40 text-purple-300 rounded border border-purple-700/50", children: "Rocket" }),
                /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-blue-900/40 text-blue-300 rounded border border-blue-700/50", children: "VISA" }),
                /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-red-900/40 text-red-300 rounded border border-red-700/50", children: "Mastercard" })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between text-gray-500 text-[11px] gap-4", children: [
          /* @__PURE__ */ jsx("p", { children: settings?.footer_copyright || `© ${(/* @__PURE__ */ new Date()).getFullYear()} ${settings?.site_name || "Tech Shoppers"} | All Rights Reserved` }),
          /* @__PURE__ */ jsx("p", { children: "Powered by Laravel + React + MySQL" })
        ] })
      ]
    }
  );
}
function FrontendLayout({
  children,
  title,
  description,
  image,
  keywords,
  type = "website",
  canonical,
  schema = null
}) {
  const { flash, settings, ziggy } = usePage().props;
  const [alertMessage, setAlertMessage] = useState(null);
  const [alertType, setAlertType] = useState(null);
  useEffect(() => {
    if (flash?.success) {
      setAlertMessage(flash.success);
      setAlertType("success");
      const timer = setTimeout(() => setAlertMessage(null), 5e3);
      return () => clearTimeout(timer);
    }
    if (flash?.error) {
      setAlertMessage(flash.error);
      setAlertType("error");
      const timer = setTimeout(() => setAlertMessage(null), 5e3);
      return () => clearTimeout(timer);
    }
  }, [flash]);
  const siteTitle = settings?.site_name || "Tech Shoppers";
  const siteTagline = settings?.site_tagline || "Leading Computer & Laptop Shop in Bangladesh";
  const metaDesc = description || settings?.seo_meta_description || siteTagline;
  const metaKeywords = keywords || settings?.seo_meta_keywords || "";
  const shareImage = image || settings?.seo_og_image || settings?.site_logo || "";
  const currentUrl = canonical || (typeof window !== "undefined" ? window.location.href : ziggy?.location || "");
  let fullTitle = `${siteTitle} | ${siteTagline}`;
  if (title) {
    if (title.toLowerCase().includes(siteTitle.toLowerCase())) {
      fullTitle = title;
    } else {
      fullTitle = `${title} | ${siteTitle}`;
    }
  } else if (settings?.seo_meta_title) {
    fullTitle = settings.seo_meta_title;
  }
  const robotsValue = `${settings?.seo_robots_index || "index"}, ${settings?.seo_robots_follow || "follow"}${settings?.seo_robots_advanced ? ", " + settings.seo_robots_advanced : ""}`;
  const sameAsProfiles = [
    settings?.facebook_url,
    settings?.youtube_url,
    settings?.instagram_url,
    settings?.twitter_url,
    settings?.linkedin_url
  ].filter(Boolean);
  const organizationSchema = settings?.seo_schema_org_enabled !== "0" ? {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": settings?.seo_schema_org_name || siteTitle,
    "url": settings?.seo_canonical_base || (typeof window !== "undefined" ? window.location.origin : ""),
    "logo": settings?.seo_schema_org_logo || settings?.site_logo || shareImage || void 0,
    "contactPoint": settings?.hotline || settings?.phone ? {
      "@type": "ContactPoint",
      "telephone": settings?.hotline || settings?.phone,
      "contactType": "customer service",
      "areaServed": "BD"
    } : void 0,
    "address": settings?.address ? {
      "@type": "PostalAddress",
      "streetAddress": settings?.address,
      "addressCountry": "BD"
    } : void 0,
    "sameAs": sameAsProfiles.length > 0 ? sameAsProfiles : void 0
  } : null;
  const searchSchema = settings?.seo_schema_search_enabled !== "0" ? {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": siteTitle,
    "url": settings?.seo_canonical_base || (typeof window !== "undefined" ? window.location.origin : ""),
    "potentialAction": {
      "@type": "SearchAction",
      "target": `${settings?.seo_canonical_base || (typeof window !== "undefined" ? window.location.origin : "")}/search?q={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  } : null;
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen flex flex-col bg-[#F2F4F8] text-[#111827] antialiased selection:bg-[#EF4A23] selection:text-white", children: [
    /* @__PURE__ */ jsxs(Head, { children: [
      /* @__PURE__ */ jsx("title", { children: fullTitle }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: metaDesc }),
      metaKeywords && /* @__PURE__ */ jsx("meta", { name: "keywords", content: metaKeywords }),
      settings?.seo_author && /* @__PURE__ */ jsx("meta", { name: "author", content: settings.seo_author }),
      /* @__PURE__ */ jsx("meta", { name: "robots", content: robotsValue }),
      currentUrl && /* @__PURE__ */ jsx("link", { rel: "canonical", href: currentUrl }),
      settings?.site_favicon && /* @__PURE__ */ jsx("link", { rel: "icon", href: settings.site_favicon }),
      /* @__PURE__ */ jsx("meta", { property: "og:title", content: title || settings?.seo_og_title || fullTitle }),
      /* @__PURE__ */ jsx("meta", { property: "og:description", content: metaDesc }),
      shareImage && /* @__PURE__ */ jsx("meta", { property: "og:image", content: shareImage }),
      currentUrl && /* @__PURE__ */ jsx("meta", { property: "og:url", content: currentUrl }),
      /* @__PURE__ */ jsx("meta", { property: "og:site_name", content: siteTitle }),
      /* @__PURE__ */ jsx("meta", { property: "og:type", content: type || settings?.seo_og_type || "website" }),
      /* @__PURE__ */ jsx("meta", { name: "twitter:card", content: settings?.seo_twitter_card || "summary_large_image" }),
      settings?.seo_twitter_site && /* @__PURE__ */ jsx("meta", { name: "twitter:site", content: settings.seo_twitter_site }),
      settings?.seo_twitter_creator && /* @__PURE__ */ jsx("meta", { name: "twitter:creator", content: settings.seo_twitter_creator }),
      /* @__PURE__ */ jsx("meta", { name: "twitter:title", content: title || fullTitle }),
      /* @__PURE__ */ jsx("meta", { name: "twitter:description", content: metaDesc }),
      shareImage && /* @__PURE__ */ jsx("meta", { name: "twitter:image", content: shareImage }),
      settings?.seo_fb_app_id && /* @__PURE__ */ jsx("meta", { property: "fb:app_id", content: settings.seo_fb_app_id }),
      organizationSchema && /* @__PURE__ */ jsx("script", { type: "application/ld+json", children: JSON.stringify(organizationSchema) }),
      searchSchema && /* @__PURE__ */ jsx("script", { type: "application/ld+json", children: JSON.stringify(searchSchema) }),
      schema && /* @__PURE__ */ jsx("script", { type: "application/ld+json", children: JSON.stringify(schema) })
    ] }),
    alertMessage && /* @__PURE__ */ jsx("div", { className: "fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-200", children: /* @__PURE__ */ jsxs("div", { className: `flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl text-sm font-medium border text-white ${alertType === "success" ? "bg-emerald-600 border-emerald-500" : "bg-rose-600 border-rose-500"}`, children: [
      alertType === "success" ? /* @__PURE__ */ jsx(CheckCircle2, { className: "w-5 h-5 shrink-0" }) : /* @__PURE__ */ jsx(AlertCircle, { className: "w-5 h-5 shrink-0" }),
      /* @__PURE__ */ jsx("span", { children: alertMessage }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setAlertMessage(null),
          className: "ml-2 hover:opacity-75",
          children: /* @__PURE__ */ jsx(X, { className: "w-4 h-4" })
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "print:hidden sticky top-0 z-50 shadow-md", children: [
      /* @__PURE__ */ jsx(Header, {}),
      /* @__PURE__ */ jsx(Navbar, {})
    ] }),
    /* @__PURE__ */ jsx("main", { className: "flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 pb-20 lg:pb-8 print:p-0 print:m-0 print:max-w-none print:w-full", children }),
    /* @__PURE__ */ jsx("div", { className: "print:hidden", children: /* @__PURE__ */ jsx(Footer, {}) }),
    settings?.whatsapp && /* @__PURE__ */ jsx("aside", { "aria-label": "WhatsApp Live Chat", className: "fixed bottom-16 lg:bottom-6 right-5 z-40 print:hidden", children: /* @__PURE__ */ jsxs(
      "a",
      {
        href: `https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, "")}?text=Hello%20${encodeURIComponent(siteTitle)}%2C%20I%20have%20an%20inquiry.`,
        target: "_blank",
        rel: "noreferrer",
        className: "group flex items-center gap-2 bg-[#25D366] hover:bg-[#20ba5a] text-white p-3 lg:px-4 lg:py-3 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200",
        title: "Chat with us on WhatsApp",
        children: [
          /* @__PURE__ */ jsx("svg", { className: "w-6 h-6 shrink-0", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" }) }),
          /* @__PURE__ */ jsx("span", { className: "hidden lg:inline text-xs font-bold whitespace-nowrap", children: "Chat on WhatsApp" })
        ]
      }
    ) })
  ] });
}
export {
  FrontendLayout as F
};
