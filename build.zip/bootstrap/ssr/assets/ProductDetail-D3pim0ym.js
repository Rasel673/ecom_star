import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { usePage, Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { P as ProductCard } from "./ProductCard-Ck3qGjy2.js";
import { a as EmiModal } from "./EmiModal-CJooS0JZ.js";
import { ChevronRight, CreditCard, Calculator, Minus, Plus, Clock, Zap, ShoppingCart, Heart, ShieldCheck, Truck, RotateCcw, Star, X } from "lucide-react";
const WhatsAppIcon = ({ className = "w-4 h-4" }) => /* @__PURE__ */ jsx("svg", { className, fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx("path", { d: "M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.669-.699c.974.557 1.956.884 3.01.884l.003-.001c3.181 0 5.767-2.586 5.768-5.766 0-1.54-.599-2.989-1.688-4.079-1.09-1.09-2.538-1.69-4.29-1.69zm7.042 12.809c-1.89 1.889-4.398 2.93-7.07 2.93-.007 0-.014 0-.02 0-2.433 0-4.814-.654-6.885-1.891l-4.798 1.258 1.28-4.673c-1.357-2.148-2.073-4.636-2.072-7.189.003-7.513 6.118-13.626 13.633-13.626 3.638 0 7.059 1.417 9.632 3.99 2.573 2.573 3.99 5.993 3.99 9.632 0 3.638-1.417 7.058-3.69 9.569z" }) });
function ProductDetail({ product, relatedProducts = [], seo = {} }) {
  const { auth, settings } = usePage().props;
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState("specs");
  const [wishlistLoading, setWishlistLoading] = useState(false);
  const [showPreOrderModal, setShowPreOrderModal] = useState(false);
  const [showEmiModal, setShowEmiModal] = useState(false);
  const [preOrderForm, setPreOrderForm] = useState({
    customer_name: auth?.user?.name || "",
    customer_phone: auth?.user?.phone || "",
    customer_email: auth?.user?.email || "",
    delivery_address: "",
    quantity: 1,
    notes: ""
  });
  const [preOrderSubmitting, setPreOrderSubmitting] = useState(false);
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("preorder") === "1") {
        setShowPreOrderModal(true);
      }
    }
  }, []);
  const [reviewForm, setReviewForm] = useState({
    name: auth?.user?.name || "",
    rating: 5,
    comment: ""
  });
  const isUpcoming = product.stock_status !== "in_stock";
  const price = product.special_price || product.regular_price;
  const hasDiscount = product.special_price && product.regular_price > product.special_price;
  const handleWishlistToggle = () => {
    if (!auth?.user) {
      router.visit(route("login"));
      return;
    }
    setWishlistLoading(true);
    router.post(route("customer.wishlist.toggle"), {
      product_id: product.id
    }, {
      preserveScroll: true,
      onFinish: () => setWishlistLoading(false)
    });
  };
  const handlePreOrderSubmit = (e) => {
    e.preventDefault();
    setPreOrderSubmitting(true);
    router.post(route("preorder.store"), {
      product_id: product.id,
      ...preOrderForm
    }, {
      preserveScroll: true,
      onSuccess: () => {
        setShowPreOrderModal(false);
      },
      onFinish: () => setPreOrderSubmitting(false)
    });
  };
  const handleAddToCart = () => {
    router.post(route("cart.add"), {
      product_id: product.id,
      quantity
    }, {
      preserveScroll: true
    });
  };
  const handleBuyNow = () => {
    router.post(route("cart.add"), {
      product_id: product.id,
      quantity
    }, {
      onSuccess: () => router.visit(route("checkout.index"))
    });
  };
  const handleReviewSubmit = (e) => {
    e.preventDefault();
    router.post(route("product.review", product.slug), reviewForm, {
      preserveScroll: true,
      onSuccess: () => setReviewForm({ name: "", rating: 5, comment: "" })
    });
  };
  const currentPrice = product.special_price || product.regular_price;
  const isAvailable = product.stock_status === "in_stock" && (product.quantity > 0 || product.quantity === null);
  const productSchema = settings?.seo_schema_product_enabled !== "0" ? {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": product.name,
    "image": product.thumbnail ? [product.thumbnail] : [],
    "description": seo.description || (product.description ? product.description.replace(/<[^>]+>/g, "").substring(0, 200) : product.name),
    "sku": product.sku || product.model || `PROD-${product.id}`,
    "mpn": product.model || void 0,
    "brand": product.brand ? {
      "@type": "Brand",
      "name": product.brand.name
    } : void 0,
    "offers": {
      "@type": "Offer",
      "url": typeof window !== "undefined" ? window.location.href : "",
      "priceCurrency": "BDT",
      "price": currentPrice,
      "availability": isAvailable ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      "itemCondition": "https://schema.org/NewCondition"
    },
    ...product.reviews && product.reviews.length > 0 ? {
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": (product.reviews.reduce((acc, r) => acc + (r.rating || 5), 0) / product.reviews.length).toFixed(1),
        "reviewCount": product.reviews.length
      }
    } : {}
  } : null;
  return /* @__PURE__ */ jsxs(
    FrontendLayout,
    {
      title: seo.title,
      description: seo.description,
      image: product.thumbnail,
      schema: productSchema,
      children: [
        /* @__PURE__ */ jsxs("nav", { className: "flex items-center gap-1.5 text-[11px] sm:text-xs text-gray-500 mb-4 sm:mb-6 overflow-x-auto whitespace-nowrap pb-1", children: [
          /* @__PURE__ */ jsx(Link, { href: route("home"), className: "hover:text-[#EF4A23] shrink-0", children: "Home" }),
          /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-gray-400 shrink-0" }),
          product.category && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(Link, { href: route("category.show", product.category.slug), className: "hover:text-[#EF4A23] shrink-0", children: product.category.name }),
            /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-gray-400 shrink-0" })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold truncate max-w-xs", children: product.name })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm p-4 sm:p-6 md:p-8 mb-8 sm:mb-10", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8", children: [
          /* @__PURE__ */ jsx("div", { className: "lg:col-span-5 flex flex-col items-center justify-center p-4 bg-gray-50/50 rounded-xl border border-gray-100", children: /* @__PURE__ */ jsx(
            "img",
            {
              src: product.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=600&h=600&fit=crop",
              alt: product.name,
              className: "max-h-64 sm:max-h-96 w-auto object-contain hover:scale-105 transition-transform duration-300"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 flex flex-col justify-between", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h1", { className: "text-lg sm:text-xl md:text-2xl font-black text-gray-900 leading-snug mb-2", children: product.name }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2 sm:gap-3 text-xs text-gray-500 mb-4 pb-4 border-b border-gray-100", children: [
                product.model && /* @__PURE__ */ jsxs("span", { className: "bg-gray-100 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md text-gray-700 font-medium text-[11px] sm:text-xs", children: [
                  "Model: ",
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-900", children: product.model })
                ] }),
                product.sku && /* @__PURE__ */ jsxs("span", { className: "bg-gray-100 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md text-gray-700 font-medium text-[11px] sm:text-xs", children: [
                  "Product ID: ",
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-900", children: product.sku })
                ] }),
                /* @__PURE__ */ jsxs("span", { className: `px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-semibold text-[11px] sm:text-xs ${product.stock_status === "in_stock" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`, children: [
                  "Status: ",
                  product.stock_status === "in_stock" ? "In Stock" : "Upcoming"
                ] })
              ] }),
              product.key_features && Array.isArray(product.key_features) && /* @__PURE__ */ jsxs("div", { className: "mb-5 sm:mb-6", children: [
                /* @__PURE__ */ jsx("h4", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider mb-2", children: "Key Features:" }),
                /* @__PURE__ */ jsx("ul", { className: "grid grid-cols-1 md:grid-cols-2 gap-1.5 sm:gap-2 text-xs text-gray-600", children: product.key_features.map((feature, idx) => /* @__PURE__ */ jsxs("li", { className: "flex items-start gap-1.5", children: [
                  /* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-[#EF4A23] mt-1.5 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { className: "leading-snug", children: feature })
                ] }, idx)) })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "bg-[#fcf8f6] border border-orange-100 rounded-xl p-3.5 sm:p-4 mb-5 sm:mb-6", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-baseline gap-2 sm:gap-3", children: [
                  /* @__PURE__ */ jsxs("span", { className: "text-2xl sm:text-3xl font-black text-[#EF4A23]", children: [
                    "৳",
                    Number(price).toLocaleString()
                  ] }),
                  hasDiscount && /* @__PURE__ */ jsxs(Fragment, { children: [
                    /* @__PURE__ */ jsxs("span", { className: "text-xs sm:text-sm text-gray-400 line-through", children: [
                      "৳",
                      Number(product.regular_price).toLocaleString()
                    ] }),
                    /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-xs bg-[#EF4A23] text-white px-2 py-0.5 rounded font-bold", children: "Cash Discount" })
                  ] })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-[10px] sm:text-[11px] text-gray-500 mt-1", children: "Special Price for Online Order & Cash on Delivery. Card / EMI prices may vary." }),
                price >= 5e3 && /* @__PURE__ */ jsxs("div", { className: "mt-3 pt-3 border-t border-orange-200/60 flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-7 h-7 rounded-lg bg-orange-100 text-[#EF4A23] flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(CreditCard, { className: "w-3.5 h-3.5" }) }),
                    /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-500 font-bold uppercase tracking-wider block", children: "0% EMI Available" }),
                      /* @__PURE__ */ jsxs("span", { className: "text-xs sm:text-sm font-extrabold text-gray-900", children: [
                        "Starts from ",
                        /* @__PURE__ */ jsxs("strong", { className: "text-[#EF4A23]", children: [
                          "৳",
                          Math.round(price / 36).toLocaleString()
                        ] }),
                        /* @__PURE__ */ jsx("span", { className: "text-[11px] font-normal text-gray-500", children: " /mo" })
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setShowEmiModal(true),
                      className: "px-3 py-1.5 text-xs font-bold text-[#EF4A23] hover:text-white bg-white hover:bg-[#EF4A23] border border-[#EF4A23] rounded-lg transition shadow-xs flex items-center gap-1.5",
                      children: [
                        /* @__PURE__ */ jsx(Calculator, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsx("span", { children: "View EMI Plans" })
                      ]
                    }
                  )
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "pt-4 border-t border-gray-100", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between sm:justify-start border border-gray-300 rounded-xl overflow-hidden bg-gray-50 w-full sm:w-auto", children: [
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setQuantity(Math.max(1, quantity - 1)),
                      className: "p-3 sm:p-2.5 hover:bg-gray-200 text-gray-600 transition",
                      children: /* @__PURE__ */ jsx(Minus, { className: "w-4 h-4" })
                    }
                  ),
                  /* @__PURE__ */ jsx("span", { className: "px-4 py-2 font-bold text-sm text-gray-900 min-w-[40px] text-center", children: quantity }),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setQuantity(quantity + 1),
                      className: "p-3 sm:p-2.5 hover:bg-gray-200 text-gray-600 transition",
                      children: /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" })
                    }
                  )
                ] }),
                isUpcoming ? /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowPreOrderModal(true),
                    className: "flex-1 flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm py-3 px-6 rounded-xl shadow-md hover:shadow-amber-500/20 transition",
                    children: [
                      /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsx("span", { children: "Pre-Order Now" })
                    ]
                  }
                ) : /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: handleBuyNow,
                    className: "flex-1 flex items-center justify-center gap-2 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs sm:text-sm py-3 px-6 rounded-xl shadow-md hover:shadow-orange-500/20 transition",
                    children: [
                      /* @__PURE__ */ jsx(Zap, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsx("span", { children: "Buy Now" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: handleAddToCart,
                    className: "flex-1 flex items-center justify-center gap-2 bg-[#081621] hover:bg-[#112538] text-white font-bold text-xs sm:text-sm py-3 px-6 rounded-xl transition shadow-sm",
                    children: [
                      /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsx("span", { children: "Add to Cart" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: handleWishlistToggle,
                    disabled: wishlistLoading,
                    title: auth?.user ? "Save to Favorites" : "Login to save to Favorites",
                    className: "p-3 rounded-xl border border-gray-300 hover:border-red-400 hover:bg-red-50 text-gray-500 hover:text-red-600 transition flex items-center justify-center",
                    children: /* @__PURE__ */ jsx(Heart, { className: "w-5 h-5" })
                  }
                )
              ] }),
              settings?.whatsapp && /* @__PURE__ */ jsxs(
                "a",
                {
                  href: `https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(`Hello ${settings?.site_name || "Tech Shoppers"}, I want to order/inquire about:
Product: ${product.name}
Quantity: ${quantity}
Price: ৳${Number(price * quantity).toLocaleString()}
Link: ${typeof window !== "undefined" ? window.location.href : ""}`)}`,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "w-full mt-3 flex items-center justify-center gap-2.5 py-3 px-5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-emerald-500/25 transition group",
                  children: [
                    /* @__PURE__ */ jsx(WhatsAppIcon, { className: "w-5 h-5 fill-white group-hover:scale-110 transition shrink-0" }),
                    /* @__PURE__ */ jsx("span", { children: "Order / Inquire on WhatsApp" }),
                    /* @__PURE__ */ jsxs("span", { className: "text-[11px] opacity-80 font-normal hidden sm:inline", children: [
                      "(",
                      settings.whatsapp,
                      ")"
                    ] })
                  ]
                }
              ),
              !isUpcoming && /* @__PURE__ */ jsx("div", { className: "mt-3 text-right", children: /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setShowPreOrderModal(true),
                  className: "text-xs text-gray-500 hover:text-[#EF4A23] underline flex items-center gap-1 ml-auto",
                  children: [
                    /* @__PURE__ */ jsx(Clock, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsx("span", { children: "Need bulk quantity or upcoming batch? Request Pre-Order" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-2 mt-5 sm:mt-6 pt-4 border-t border-gray-100 text-[10px] sm:text-[11px] text-gray-500 text-center", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-1", children: [
                  /* @__PURE__ */ jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { children: "Official Warranty" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-1", children: [
                  /* @__PURE__ */ jsx(Truck, { className: "w-4 h-4 text-blue-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { children: "Express Delivery" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-1", children: [
                  /* @__PURE__ */ jsx(RotateCcw, { className: "w-4 h-4 text-orange-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { children: "7 Days Return" })
                ] })
              ] })
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6 md:p-8 mb-10 sm:mb-12", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 sm:gap-6 border-b border-gray-200 pb-2 mb-6 text-xs sm:text-sm font-bold overflow-x-auto whitespace-nowrap", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab("specs"),
                className: `pb-2 border-b-2 transition shrink-0 ${activeTab === "specs" ? "border-[#EF4A23] text-[#EF4A23]" : "border-transparent text-gray-500 hover:text-gray-900"}`,
                children: "Specification"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab("description"),
                className: `pb-2 border-b-2 transition shrink-0 ${activeTab === "description" ? "border-[#EF4A23] text-[#EF4A23]" : "border-transparent text-gray-500 hover:text-gray-900"}`,
                children: "Description"
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab("reviews"),
                className: `pb-2 border-b-2 transition flex items-center gap-1.5 shrink-0 ${activeTab === "reviews" ? "border-[#EF4A23] text-[#EF4A23]" : "border-transparent text-gray-500 hover:text-gray-900"}`,
                children: [
                  /* @__PURE__ */ jsx("span", { children: "Questions & Reviews" }),
                  /* @__PURE__ */ jsx("span", { className: "bg-gray-100 text-gray-600 text-[10px] sm:text-xs px-2 py-0.5 rounded-full", children: product.reviews?.length || 0 })
                ]
              }
            )
          ] }),
          activeTab === "specs" && /* @__PURE__ */ jsx("div", { children: product.specifications && Object.keys(product.specifications).length > 0 ? /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100 text-xs border border-gray-200 rounded-xl overflow-hidden", children: Object.entries(product.specifications).map(([key, val], idx) => /* @__PURE__ */ jsxs(
            "div",
            {
              className: `grid grid-cols-1 sm:grid-cols-3 p-3 sm:p-3.5 ${idx % 2 === 0 ? "bg-gray-50/50" : "bg-white"}`,
              children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-700", children: key }),
                /* @__PURE__ */ jsx("span", { className: "sm:col-span-2 text-gray-600 mt-1 sm:mt-0 leading-relaxed", children: val })
              ]
            },
            idx
          )) }) : /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Full specification details will be updated shortly." }) }),
          activeTab === "description" && /* @__PURE__ */ jsx("div", { className: "prose prose-sm max-w-none text-xs text-gray-700 leading-relaxed space-y-4", children: /* @__PURE__ */ jsx("p", { children: product.description || "No detailed description available for this item." }) }),
          activeTab === "reviews" && /* @__PURE__ */ jsxs("div", { className: "space-y-6 sm:space-y-8", children: [
            /* @__PURE__ */ jsxs("form", { onSubmit: handleReviewSubmit, className: "bg-gray-50 p-4 sm:p-5 rounded-xl border border-gray-200 space-y-4", children: [
              /* @__PURE__ */ jsxs("h4", { className: "text-sm font-bold text-gray-900", children: [
                "Write a Review for ",
                product.name
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Your Name" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "text",
                      required: true,
                      value: reviewForm.name,
                      onChange: (e) => setReviewForm({ ...reviewForm, name: e.target.value }),
                      className: "w-full text-xs p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                      placeholder: "Rahim Ahmed"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Rating" }),
                  /* @__PURE__ */ jsxs(
                    "select",
                    {
                      value: reviewForm.rating,
                      onChange: (e) => setReviewForm({ ...reviewForm, rating: Number(e.target.value) }),
                      className: "w-full text-xs p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "5", children: "⭐⭐⭐⭐⭐ (5/5 Excellent)" }),
                        /* @__PURE__ */ jsx("option", { value: "4", children: "⭐⭐⭐⭐ (4/5 Very Good)" }),
                        /* @__PURE__ */ jsx("option", { value: "3", children: "⭐⭐⭐ (3/5 Average)" }),
                        /* @__PURE__ */ jsx("option", { value: "2", children: "⭐⭐ (2/5 Below Average)" }),
                        /* @__PURE__ */ jsx("option", { value: "1", children: "⭐ (1/5 Poor)" })
                      ]
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Your Feedback / Review" }),
                /* @__PURE__ */ jsx(
                  "textarea",
                  {
                    required: true,
                    rows: "3",
                    value: reviewForm.comment,
                    onChange: (e) => setReviewForm({ ...reviewForm, comment: e.target.value }),
                    className: "w-full text-xs p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                    placeholder: "Write your honest experience with this product..."
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "submit",
                  className: "w-full sm:w-auto bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2.5 px-6 rounded-lg transition",
                  children: "Submit Review"
                }
              )
            ] }),
            product.reviews && product.reviews.length > 0 ? /* @__PURE__ */ jsx("div", { className: "space-y-3 sm:space-y-4", children: product.reviews.map((rev) => /* @__PURE__ */ jsxs("div", { className: "p-3.5 sm:p-4 rounded-xl border border-gray-200", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1", children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-xs text-gray-900", children: rev.name }),
                /* @__PURE__ */ jsx("div", { className: "flex items-center text-amber-500", children: Array.from({ length: rev.rating }).map((_, i) => /* @__PURE__ */ jsx(Star, { className: "w-3.5 h-3.5 fill-current" }, i)) })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-600 mt-2", children: rev.comment })
            ] }, rev.id)) }) : /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 text-center py-4", children: "No reviews yet. Be the first to review this product!" })
          ] })
        ] }),
        relatedProducts.length > 0 && /* @__PURE__ */ jsxs("div", { className: "mb-14", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-lg md:text-xl font-black text-gray-900 mb-4 sm:mb-6 pb-2 border-b", children: "Related Products" }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5", children: relatedProducts.map((rel) => /* @__PURE__ */ jsx(ProductCard, { product: rel }, rel.id)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:hidden fixed bottom-[50px] left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-gray-200 px-3 py-2 flex items-center justify-between shadow-2xl", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-500 block uppercase font-medium", children: "Price" }),
            /* @__PURE__ */ jsxs("span", { className: "text-base font-black text-[#EF4A23]", children: [
              "৳",
              Number(price).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: handleAddToCart,
                className: "p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 transition",
                title: "Add to Cart",
                children: /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: handleBuyNow,
                className: "px-4 py-2 rounded-xl bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs flex items-center gap-1.5 shadow-md",
                children: [
                  /* @__PURE__ */ jsx(Zap, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsx("span", { children: "Buy Now" })
                ]
              }
            )
          ] })
        ] }),
        showPreOrderModal && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-gray-100", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] px-6 py-4 flex items-center justify-between text-white", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5", children: [
              /* @__PURE__ */ jsx(Clock, { className: "w-5 h-5 text-amber-400" }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h3", { className: "text-base font-bold", children: "Pre-Order Product" }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-300", children: "Reserve upcoming or priority stock" })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => setShowPreOrderModal(false),
                className: "text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition",
                children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("form", { onSubmit: handlePreOrderSubmit, className: "p-6 space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-200", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: product.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100&h=100&fit=crop",
                  alt: product.name,
                  className: "w-12 h-12 object-contain bg-white rounded-lg p-1 border"
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsx("h4", { className: "text-xs font-bold text-gray-900 truncate", children: product.name }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-0.5", children: [
                  /* @__PURE__ */ jsxs("span", { className: "text-xs font-black text-[#EF4A23]", children: [
                    "৳",
                    Number(price).toLocaleString()
                  ] }),
                  /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-semibold", children: "Pre-Order" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Your Full Name *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    required: true,
                    value: preOrderForm.customer_name,
                    onChange: (e) => setPreOrderForm({ ...preOrderForm, customer_name: e.target.value }),
                    placeholder: "e.g. Tanvir Ahmed",
                    className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Phone Number *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "tel",
                    required: true,
                    value: preOrderForm.customer_phone,
                    onChange: (e) => setPreOrderForm({ ...preOrderForm, customer_phone: e.target.value }),
                    placeholder: "01XXXXXXXXX",
                    className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Email Address (Optional)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "email",
                    value: preOrderForm.customer_email,
                    onChange: (e) => setPreOrderForm({ ...preOrderForm, customer_email: e.target.value }),
                    placeholder: "yourname@domain.com",
                    className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Pre-Order Quantity *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    min: "1",
                    required: true,
                    value: preOrderForm.quantity,
                    onChange: (e) => setPreOrderForm({ ...preOrderForm, quantity: Math.max(1, parseInt(e.target.value) || 1) }),
                    className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Delivery Address *" }),
              /* @__PURE__ */ jsx(
                "textarea",
                {
                  required: true,
                  rows: "2",
                  value: preOrderForm.delivery_address,
                  onChange: (e) => setPreOrderForm({ ...preOrderForm, delivery_address: e.target.value }),
                  placeholder: "House, Road, Area, City",
                  className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Notes / Specific Requirements (Optional)" }),
              /* @__PURE__ */ jsx(
                "textarea",
                {
                  rows: "2",
                  value: preOrderForm.notes,
                  onChange: (e) => setPreOrderForm({ ...preOrderForm, notes: e.target.value }),
                  placeholder: "e.g. Preferred brand color, delivery timing preference...",
                  className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                }
              )
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 bg-amber-50 p-2.5 rounded-lg border border-amber-200", children: "💡 Our customer care representative will call you within 24 hours to confirm estimated delivery time and booking." }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setShowPreOrderModal(false),
                  className: "px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800",
                  children: "Cancel"
                }
              ),
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "submit",
                  disabled: preOrderSubmitting,
                  className: "px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md disabled:opacity-50 transition",
                  children: [
                    /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsx("span", { children: preOrderSubmitting ? "Submitting..." : "Confirm Pre-Order" })
                  ]
                }
              )
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx(
          EmiModal,
          {
            isOpen: showEmiModal,
            onClose: () => setShowEmiModal(false),
            product
          }
        )
      ]
    }
  );
}
export {
  ProductDetail as default
};
