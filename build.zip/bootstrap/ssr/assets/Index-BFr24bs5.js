import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { usePage, Link, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { Search, Truck, Package, Eye, ShieldX, ShieldAlert, ShieldCheck } from "lucide-react";
function Index({ orders, filters = {} }) {
  const { settings } = usePage().props;
  const siteName = settings?.site_name || "Tech Shoppers";
  const [search, setSearch] = useState(filters.search || "");
  const [status, setStatus] = useState(filters.status || "");
  const [fraudStatus, setFraudStatus] = useState(filters.fraud_status || "");
  const [courierName, setCourierName] = useState(filters.courier_name || "");
  const handleFilter = (e) => {
    e.preventDefault();
    router.get(
      route("admin.orders.index"),
      {
        search: search || void 0,
        status: status || void 0,
        fraud_status: fraudStatus || void 0,
        courier_name: courierName || void 0
      },
      { preserveState: true }
    );
  };
  const getFraudBadge = (status2, score) => {
    switch (status2) {
      case "safe":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200", children: [
          /* @__PURE__ */ jsx(ShieldCheck, { className: "w-3 h-3" }),
          "Safe ",
          score !== null && score !== void 0 && `(${score})`
        ] });
      case "review":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200", children: [
          /* @__PURE__ */ jsx(ShieldAlert, { className: "w-3 h-3" }),
          "Review ",
          score !== null && score !== void 0 && `(${score})`
        ] });
      case "high_risk":
      case "flagged":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200", children: [
          /* @__PURE__ */ jsx(ShieldX, { className: "w-3 h-3" }),
          "High Risk ",
          score !== null && score !== void 0 && `(${score})`
        ] });
      default:
        return /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-50 text-gray-500 border border-gray-200", children: "Pending" });
    }
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "Manage Customer Orders", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-xl font-black text-gray-900", children: "Orders Management" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Track orders, automated fraud assessment, and courier parcel dispatch" })
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleFilter, className: "flex flex-wrap items-center gap-2.5 w-full lg:w-auto", children: [
        /* @__PURE__ */ jsxs(
          "select",
          {
            value: status,
            onChange: (e) => setStatus(e.target.value),
            className: "text-xs p-2 rounded-xl border border-gray-300 focus:border-[#EF4A23]",
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "All Statuses" }),
              /* @__PURE__ */ jsx("option", { value: "pending", children: "Pending" }),
              /* @__PURE__ */ jsx("option", { value: "processing", children: "Processing" }),
              /* @__PURE__ */ jsx("option", { value: "confirmed", children: "Confirmed" }),
              /* @__PURE__ */ jsx("option", { value: "shipped", children: "Shipped" }),
              /* @__PURE__ */ jsx("option", { value: "delivered", children: "Delivered" }),
              /* @__PURE__ */ jsx("option", { value: "cancelled", children: "Cancelled" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "select",
          {
            value: fraudStatus,
            onChange: (e) => setFraudStatus(e.target.value),
            className: "text-xs p-2 rounded-xl border border-gray-300 focus:border-[#EF4A23]",
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "All Risk Levels" }),
              /* @__PURE__ */ jsx("option", { value: "safe", children: "🛡️ Safe" }),
              /* @__PURE__ */ jsx("option", { value: "review", children: "⚠️ Needs Review" }),
              /* @__PURE__ */ jsx("option", { value: "high_risk", children: "🚨 High Risk / Fraud" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "select",
          {
            value: courierName,
            onChange: (e) => setCourierName(e.target.value),
            className: "text-xs p-2 rounded-xl border border-gray-300 focus:border-[#EF4A23]",
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "All Couriers" }),
              /* @__PURE__ */ jsx("option", { value: "steadfast", children: "Steadfast Courier" }),
              /* @__PURE__ */ jsx("option", { value: "pathao", children: "Pathao Courier" }),
              /* @__PURE__ */ jsx("option", { value: "redx", children: "RedX Logistics" }),
              /* @__PURE__ */ jsx("option", { value: "paperfly", children: "Paperfly" }),
              /* @__PURE__ */ jsx("option", { value: "sundarban", children: "Sundarban Courier" }),
              /* @__PURE__ */ jsxs("option", { value: "startech_rider", children: [
                siteName,
                " Rider"
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "relative flex-1 sm:flex-initial", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              placeholder: "Order #, Phone, Tracking",
              value: search,
              onChange: (e) => setSearch(e.target.value),
              className: "text-xs pl-3 pr-8 py-2 rounded-xl border border-gray-300 focus:border-[#EF4A23] w-full sm:w-48"
            }
          ),
          /* @__PURE__ */ jsx("button", { type: "submit", className: "absolute right-2.5 top-2.5 text-gray-400", children: /* @__PURE__ */ jsx(Search, { className: "w-3.5 h-3.5" }) })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            className: "text-xs bg-[#081621] hover:bg-[#122738] text-white font-bold px-3 py-2 rounded-xl transition",
            children: "Filter"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200/80 shadow-sm overflow-hidden", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
      /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 border-b text-gray-500 uppercase font-semibold", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Order Number" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Customer" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Fraud Risk" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Courier & Dispatch" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-right", children: "Total Amount" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Status" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: orders.data.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "7", className: "text-center py-10 text-gray-500", children: "No orders found matching the criteria." }) }) : orders.data.map((order) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/50", children: [
        /* @__PURE__ */ jsxs("td", { className: "p-3.5 font-bold text-[#EF4A23]", children: [
          /* @__PURE__ */ jsx(Link, { href: route("admin.orders.show", order.id), className: "hover:underline", children: order.order_number }),
          /* @__PURE__ */ jsx("span", { className: "block text-[10px] text-gray-400 font-normal", children: new Date(order.created_at).toLocaleDateString() })
        ] }),
        /* @__PURE__ */ jsxs("td", { className: "p-3.5", children: [
          /* @__PURE__ */ jsx("p", { className: "font-semibold text-gray-900", children: order.customer_name }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 font-mono", children: order.customer_phone }),
          /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400 truncate max-w-[150px]", children: order.city })
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: getFraudBadge(order.fraud_status, order.fraud_score) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5", children: order.courier_name ? /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 font-bold text-gray-800 uppercase text-[11px]", children: [
            /* @__PURE__ */ jsx(Truck, { className: "w-3 h-3 text-[#EF4A23]" }),
            order.courier_name
          ] }),
          /* @__PURE__ */ jsx("span", { className: "block text-[10px] font-mono text-gray-500", children: order.courier_tracking_id })
        ] }) : /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-400 italic flex items-center gap-1", children: [
          /* @__PURE__ */ jsx(Package, { className: "w-3 h-3 text-gray-300" }),
          "Unassigned"
        ] }) }),
        /* @__PURE__ */ jsxs("td", { className: "p-3.5 text-right font-black text-gray-900", children: [
          "৳",
          Number(order.total).toLocaleString(),
          /* @__PURE__ */ jsx("span", { className: "block text-[10px] uppercase font-semibold text-gray-400", children: order.payment_method })
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsx("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${order.order_status === "delivered" ? "bg-emerald-50 text-emerald-700" : order.order_status === "shipped" ? "bg-blue-50 text-blue-700" : order.order_status === "pending" ? "bg-amber-50 text-amber-700" : order.order_status === "processing" ? "bg-indigo-50 text-indigo-700" : order.order_status === "cancelled" ? "bg-rose-50 text-rose-700" : "bg-gray-100 text-gray-700"}`, children: order.order_status }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsx(
          Link,
          {
            href: route("admin.orders.show", order.id),
            className: "p-1.5 rounded-lg bg-gray-100 hover:bg-[#EF4A23] hover:text-white text-gray-600 transition inline-block",
            title: "View Order, Fraud Analysis & Courier Dispatch",
            children: /* @__PURE__ */ jsx(Eye, { className: "w-3.5 h-3.5" })
          }
        ) })
      ] }, order.id)) })
    ] }) }),
    orders.links && orders.links.length > 3 && /* @__PURE__ */ jsx("div", { className: "mt-6 flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm", children: orders.links.map((link, idx) => /* @__PURE__ */ jsx(
      Link,
      {
        href: link.url || "#",
        dangerouslySetInnerHTML: { __html: link.label },
        className: `px-3 py-1.5 text-xs rounded-lg transition font-medium ${link.active ? "bg-[#EF4A23] text-white font-bold" : "text-gray-700 hover:bg-gray-100"}`
      },
      idx
    )) }) })
  ] });
}
export {
  Index as default
};
