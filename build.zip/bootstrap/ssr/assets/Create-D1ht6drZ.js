import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { useForm, Link } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { ArrowLeft, FileText, Calculator, Truck, PhoneCall, Wrench, Search, Save } from "lucide-react";
function Create() {
  const { data, setData, post, processing, errors } = useForm({
    title: "",
    slug: "",
    subtitle: "",
    page_type: "standard",
    content: "",
    meta_title: "",
    meta_description: "",
    is_active: true,
    sort_order: 0
  });
  const handleTitleChange = (e) => {
    const title = e.target.value;
    const slug = title.toLowerCase().replace(/[^\w ]+/g, "").replace(/ +/g, "-");
    setData((prev) => ({
      ...prev,
      title,
      slug: prev.slug === "" || prev.slug === prev.title.toLowerCase().replace(/[^\w ]+/g, "").replace(/ +/g, "-") ? slug : prev.slug
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("admin.pages.store"));
  };
  return /* @__PURE__ */ jsx(AdminLayout, { title: "Create Dynamic Page", children: /* @__PURE__ */ jsxs("div", { className: "max-w-4xl mx-auto pb-12", children: [
    /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between gap-4 mb-6", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsx(
        Link,
        {
          href: route("admin.pages.index"),
          className: "p-2 bg-white hover:bg-gray-100 rounded-xl border border-gray-200 transition text-gray-600",
          children: /* @__PURE__ */ jsx(ArrowLeft, { className: "w-4 h-4" })
        }
      ),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-xl font-black text-gray-900", children: "Create Dynamic Page" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Add a custom page, interactive calculator, or customer portal" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 border-b pb-2 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(FileText, { className: "w-4 h-4 text-[#EF4A23]" }),
          /* @__PURE__ */ jsx("span", { children: "Page Identification" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Page Title *" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                required: true,
                value: data.title,
                onChange: handleTitleChange,
                placeholder: "e.g. EMI Facilities & Calculator",
                className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3"
              }
            ),
            errors.title && /* @__PURE__ */ jsx("p", { className: "text-xs text-rose-600 mt-1", children: errors.title })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "URL Slug *" }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "text-xs bg-gray-100 text-gray-500 py-2.5 px-3 rounded-l-xl border border-r-0 border-gray-300", children: "/page/" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  required: true,
                  value: data.slug,
                  onChange: (e) => setData("slug", e.target.value),
                  placeholder: "emi-calculation",
                  className: "w-full text-xs rounded-r-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3"
                }
              )
            ] }),
            errors.slug && /* @__PURE__ */ jsx("p", { className: "text-xs text-rose-600 mt-1", children: errors.slug })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Subtitle / Headline Tag (Optional)" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.subtitle,
              onChange: (e) => setData("subtitle", e.target.value),
              placeholder: "e.g. 0% Interest EMI up to 36 Months with Leading Credit Cards",
              className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-2", children: "Functional Page Engine *" }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3", children: [
            { id: "standard", name: "Standard Article", desc: "Terms, policies, buying guides & info", icon: FileText },
            { id: "emi_calculator", name: "EMI Calculator", desc: "Interactive bank tenure & EMI calculator", icon: Calculator },
            { id: "order_tracking", name: "Order Tracking", desc: "Live order & courier lookup widget", icon: Truck },
            { id: "contact_us", name: "Contact & Outlets", desc: "Headquarters, branches & inquiry form", icon: PhoneCall },
            { id: "service_complain", name: "Service & RMA", desc: "Warranty terms & repair complaints", icon: Wrench }
          ].map((type) => {
            const Icon = type.icon;
            const isSelected = data.page_type === type.id;
            return /* @__PURE__ */ jsxs(
              "div",
              {
                onClick: () => setData("page_type", type.id),
                className: `p-3 rounded-xl border cursor-pointer transition flex items-start gap-3 ${isSelected ? "border-[#EF4A23] bg-orange-50/50 shadow-sm ring-1 ring-[#EF4A23]" : "border-gray-200 hover:border-gray-300 bg-white"}`,
                children: [
                  /* @__PURE__ */ jsx("div", { className: `p-2 rounded-lg shrink-0 ${isSelected ? "bg-[#EF4A23] text-white" : "bg-gray-100 text-gray-600"}`, children: /* @__PURE__ */ jsx(Icon, { className: "w-4 h-4" }) }),
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx("div", { className: "font-bold text-xs text-gray-900", children: type.name }),
                    /* @__PURE__ */ jsx("div", { className: "text-[10px] text-gray-500 mt-0.5 leading-snug", children: type.desc })
                  ] })
                ]
              },
              type.id
            );
          }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 border-b pb-2 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(FileText, { className: "w-4 h-4 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Main Page Content & Details" })
          ] }),
          /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 font-normal", children: "Supports HTML markup & text" })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            "textarea",
            {
              rows: "12",
              value: data.content,
              onChange: (e) => setData("content", e.target.value),
              placeholder: "Enter page descriptive content, guidelines, FAQs, or instructions...",
              className: "w-full text-xs font-mono rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] p-3 leading-relaxed"
            }
          ),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-400 mt-1", children: "For specialized types like EMI Calculator or Order Tracking, the interactive tool is automatically rendered alongside this content." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 border-b pb-2 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Search, { className: "w-4 h-4 text-[#EF4A23]" }),
          /* @__PURE__ */ jsx("span", { children: "SEO Metadata & Visibility" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "SEO Meta Title (Optional)" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: data.meta_title,
                onChange: (e) => setData("meta_title", e.target.value),
                placeholder: "Leave blank to use Page Title",
                className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Sort Order" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: data.sort_order,
                onChange: (e) => setData("sort_order", parseInt(e.target.value) || 0),
                className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "SEO Meta Description (Optional)" }),
          /* @__PURE__ */ jsx(
            "textarea",
            {
              rows: "2",
              value: data.meta_description,
              onChange: (e) => setData("meta_description", e.target.value),
              placeholder: "Summary for Google and search engines...",
              className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer select-none", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              checked: data.is_active,
              onChange: (e) => setData("is_active", e.target.checked),
              className: "w-4 h-4 text-[#EF4A23] border-gray-300 rounded focus:ring-[#EF4A23]"
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-800", children: "Publish Page immediately (Visible to customers)" })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
        /* @__PURE__ */ jsx(
          Link,
          {
            href: route("admin.pages.index"),
            className: "px-4 py-2.5 text-xs font-semibold text-gray-600 hover:text-gray-800",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "px-6 py-2.5 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center gap-2 disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsx(Save, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: processing ? "Creating..." : "Save & Publish Page" })
            ]
          }
        )
      ] })
    ] })
  ] }) });
}
export {
  Create as default
};
