import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { usePage, Link } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { Plus, ShoppingBag, MessageSquare, DollarSign, Truck, ShieldAlert, CheckCircle2, TrendingUp, Clock, ArrowRight, AlertTriangle, Eye } from "lucide-react";
function Dashboard({
  stats,
  salesTrends = [],
  recentOrders = [],
  lowStockProducts = [],
  recentMessages = [],
  recentPreOrders = []
}) {
  const { settings } = usePage().props;
  const siteName = settings?.site_name || "Tech Shoppers";
  const maxSales = Math.max(...salesTrends.map((t) => t.sales || 0), 1e4);
  const [hoveredTrend, setHoveredTrend] = useState(null);
  return /* @__PURE__ */ jsxs(AdminLayout, { title: `${siteName} Control Dashboard`, children: [
    /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] text-white rounded-2xl p-6 mb-8 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-gray-800", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
        /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-bold mb-2", children: [
          /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }),
          /* @__PURE__ */ jsxs("span", { children: [
            siteName,
            " System Live & Operational"
          ] })
        ] }),
        /* @__PURE__ */ jsx("h1", { className: "text-xl sm:text-2xl font-black tracking-tight", children: "Store Overview & Live Analytics" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mt-1", children: "Monitor revenue, automated courier fulfillment, fraud alerts, and customer reservations in real-time." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2.5 relative z-10", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("admin.products.create"),
            className: "px-3.5 py-2 rounded-xl bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold flex items-center gap-1.5 transition shadow-lg shadow-orange-950/40",
            children: [
              /* @__PURE__ */ jsx(Plus, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsx("span", { children: "Add Product" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("admin.orders.index"),
            className: "px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition border border-white/10 flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsx(ShoppingBag, { className: "w-3.5 h-3.5 text-gray-300" }),
              /* @__PURE__ */ jsx("span", { children: "All Orders" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("admin.messages.index"),
            className: "px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition border border-white/10 flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsx(MessageSquare, { className: "w-3.5 h-3.5 text-blue-400" }),
              /* @__PURE__ */ jsx("span", { children: "Inquiries" }),
              stats.openMessages > 0 && /* @__PURE__ */ jsx("span", { className: "ml-1 px-1.5 py-0.2 text-[10px] bg-red-500 text-white rounded-full font-bold", children: stats.openMessages })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-orange-600/10 to-transparent pointer-events-none" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 mb-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/90 shadow-sm relative overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-gray-400", children: "Total Revenue" }),
          /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center", children: /* @__PURE__ */ jsx(DollarSign, { className: "w-5 h-5" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-2xl font-black text-gray-900 tracking-tight", children: [
          "৳",
          Number(stats.totalSales || 0).toLocaleString()
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mt-3 pt-3 border-t border-gray-100 text-[11px] text-gray-500", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "Today: ",
            /* @__PURE__ */ jsxs("strong", { className: "text-gray-800", children: [
              "৳",
              Number(stats.todaySales || 0).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            "This Month: ",
            /* @__PURE__ */ jsxs("strong", { className: "text-gray-800", children: [
              "৳",
              Number(stats.thisMonthSales || 0).toLocaleString()
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/90 shadow-sm relative overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-gray-400", children: "Orders Status" }),
          /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center", children: /* @__PURE__ */ jsx(ShoppingBag, { className: "w-5 h-5" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-2xl font-black text-gray-900 tracking-tight flex items-baseline gap-2", children: [
          /* @__PURE__ */ jsx("span", { children: stats.totalOrders || 0 }),
          /* @__PURE__ */ jsx("span", { className: "text-xs font-normal text-gray-400", children: "total" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mt-3 pt-3 border-t border-gray-100 text-[11px] text-gray-500", children: [
          /* @__PURE__ */ jsxs("span", { className: "text-amber-600 font-semibold", children: [
            stats.pendingOrders || 0,
            " Pending"
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "text-blue-600 font-semibold", children: [
            stats.processingOrders || 0,
            " Processing"
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "text-emerald-600 font-semibold", children: [
            stats.deliveredOrders || 0,
            " Delivered"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/90 shadow-sm relative overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-gray-400", children: "Courier Dispatch" }),
          /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center", children: /* @__PURE__ */ jsx(Truck, { className: "w-5 h-5" }) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "text-2xl font-black text-gray-900 tracking-tight", children: stats.courierDispatched || 0 }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mt-3 pt-3 border-t border-gray-100 text-[11px] text-gray-500", children: [
          /* @__PURE__ */ jsx("span", { children: "Steadfast & RedX API" }),
          /* @__PURE__ */ jsx(Link, { href: route("admin.orders.index"), className: "text-purple-600 font-bold hover:underline", children: "View Dispatches →" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/90 shadow-sm relative overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-gray-400", children: "Risk Assessment" }),
          /* @__PURE__ */ jsx("div", { className: `w-9 h-9 rounded-xl flex items-center justify-center ${stats.fraudAlerts > 0 ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-600"}`, children: stats.fraudAlerts > 0 ? /* @__PURE__ */ jsx(ShieldAlert, { className: "w-5 h-5" }) : /* @__PURE__ */ jsx(CheckCircle2, { className: "w-5 h-5" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-2xl font-black text-gray-900 tracking-tight flex items-baseline gap-2", children: [
          /* @__PURE__ */ jsx("span", { className: stats.fraudAlerts > 0 ? "text-rose-600" : "text-gray-900", children: stats.fraudAlerts || 0 }),
          /* @__PURE__ */ jsx("span", { className: "text-xs font-normal text-gray-400", children: "flagged orders" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mt-3 pt-3 border-t border-gray-100 text-[11px] text-gray-500", children: [
          /* @__PURE__ */ jsx("span", { children: "Automated fraud engine" }),
          stats.fraudAlerts > 0 ? /* @__PURE__ */ jsx(Link, { href: `${route("admin.orders.index")}?fraud_status=review`, className: "text-rose-600 font-bold hover:underline", children: "Review Flags →" }) : /* @__PURE__ */ jsx("span", { className: "text-emerald-600 font-semibold", children: "Zero Threats" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 mb-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-8 bg-white p-5 sm:p-6 rounded-2xl border border-gray-200/90 shadow-sm flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(TrendingUp, { className: "w-4 h-4 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: "Recent 7-Day Revenue & Volume" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Daily store performance snapshot" })
          ] }),
          hoveredTrend && /* @__PURE__ */ jsxs("div", { className: "text-right animate-fade-in text-xs bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200", children: [
            /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-900", children: [
              "৳",
              Number(hoveredTrend.sales).toLocaleString()
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "text-gray-400 ml-1.5", children: [
              "(",
              hoveredTrend.orders,
              " orders) on ",
              hoveredTrend.date
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "h-48 sm:h-56 flex items-end justify-between gap-2 sm:gap-4 pt-6 pb-2 border-b border-gray-100", children: salesTrends.map((t, i) => {
          const barHeightPercent = Math.max(8, Math.round(t.sales / maxSales * 100));
          return /* @__PURE__ */ jsxs(
            "div",
            {
              className: "flex-1 flex flex-col items-center h-full justify-end group cursor-pointer",
              onMouseEnter: () => setHoveredTrend(t),
              onMouseLeave: () => setHoveredTrend(null),
              children: [
                /* @__PURE__ */ jsxs("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-bold text-gray-700 bg-gray-100 px-1.5 py-0.5 rounded mb-1 whitespace-nowrap", children: [
                  "৳",
                  Number(t.sales).toLocaleString()
                ] }),
                /* @__PURE__ */ jsx(
                  "div",
                  {
                    className: "w-full max-w-[42px] bg-gradient-to-t from-[#EF4A23] to-orange-400 group-hover:from-orange-600 group-hover:to-orange-500 rounded-t-lg transition-all duration-300 shadow-sm group-hover:shadow-md",
                    style: { height: `${barHeightPercent}%` }
                  }
                ),
                /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 font-medium mt-2 block truncate", children: t.shortDate })
              ]
            },
            i
          );
        }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-[11px] text-gray-400 pt-3", children: [
          /* @__PURE__ */ jsx("span", { children: "Past 7 days performance" }),
          /* @__PURE__ */ jsxs("span", { className: "font-semibold text-gray-700", children: [
            siteName,
            " E-Commerce Engine"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-4 bg-white p-5 sm:p-6 rounded-2xl border border-gray-200/90 shadow-sm flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900 mb-1", children: "Operational Action Hub" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mb-4", children: "Urgent tasks requiring administrator attention" }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("admin.preorders.index"),
                className: "p-3 rounded-xl border border-gray-200 hover:border-amber-300 hover:bg-amber-50/50 transition flex items-center justify-between group",
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs", children: /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4" }) }),
                    /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("div", { className: "text-xs font-bold text-gray-900 group-hover:text-amber-800", children: "Pre-Order Reservations" }),
                      /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400", children: [
                        stats.pendingPreOrders || 0,
                        " waiting for delivery date"
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 text-gray-400 group-hover:text-amber-600 group-hover:translate-x-1 transition-transform" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("admin.messages.index"),
                className: "p-3 rounded-xl border border-gray-200 hover:border-blue-300 hover:bg-blue-50/50 transition flex items-center justify-between group",
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs", children: /* @__PURE__ */ jsx(MessageSquare, { className: "w-4 h-4" }) }),
                    /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("div", { className: "text-xs font-bold text-gray-900 group-hover:text-blue-800", children: "Support Messages" }),
                      /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400", children: [
                        stats.openMessages || 0,
                        " customers waiting for reply"
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 text-gray-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-transform" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "p-3 rounded-xl border border-gray-200 bg-gray-50/50 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-xs", children: /* @__PURE__ */ jsx(AlertTriangle, { className: "w-4 h-4" }) }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("div", { className: "text-xs font-bold text-gray-900", children: "Inventory Depletion" }),
                  /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400", children: [
                    stats.lowStockCount || 0,
                    " low stock / ",
                    stats.outOfStockCount || 0,
                    " out of stock"
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("admin.products.index"),
                  className: "text-xs font-bold text-[#EF4A23] hover:underline",
                  children: "Restock"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-4 border-t border-gray-100 text-[11px] text-gray-400 flex items-center justify-between", children: [
          /* @__PURE__ */ jsx("span", { children: "Total Registered Users" }),
          /* @__PURE__ */ jsxs("strong", { className: "text-gray-800", children: [
            stats.totalUsers || 0,
            " Customers"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-8 bg-white rounded-2xl border border-gray-200/90 shadow-sm overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-5 border-b border-gray-100 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: "Recent Customer Transactions" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Real-time orders, payment mode, and fulfillment status" })
          ] }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("admin.orders.index"),
              className: "text-xs text-[#EF4A23] hover:underline font-bold flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsx("span", { children: "View All Orders" }),
                /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsx("thead", { className: "bg-gray-50/75 text-gray-500 font-semibold border-b text-[11px]", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Order" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Customer & Items" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-right", children: "Amount" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Status" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Courier / Fraud" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Action" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: recentOrders.length > 0 ? recentOrders.map((order) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/50 transition", children: [
            /* @__PURE__ */ jsxs("td", { className: "p-3.5", children: [
              /* @__PURE__ */ jsx("span", { className: "font-bold text-[#EF4A23] block", children: order.order_number }),
              /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400", children: new Date(order.created_at).toLocaleDateString() })
            ] }),
            /* @__PURE__ */ jsxs("td", { className: "p-3.5 max-w-xs", children: [
              /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 truncate", children: order.customer_name }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-400 truncate", children: order.customer_phone }),
              order.items && order.items.length > 0 && /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-gray-500 truncate mt-0.5", children: [
                order.items[0]?.product_name,
                " ",
                order.items.length > 1 ? `+${order.items.length - 1} more` : ""
              ] })
            ] }),
            /* @__PURE__ */ jsxs("td", { className: "p-3.5 text-right font-black text-gray-900", children: [
              "৳",
              Number(order.total).toLocaleString()
            ] }),
            /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsx("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${order.order_status === "delivered" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : order.order_status === "pending" ? "bg-amber-50 text-amber-700 border border-amber-200" : order.order_status === "processing" ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-gray-100 text-gray-700"}`, children: order.order_status }) }),
            /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-1", children: [
              order.courier_tracking_id || order.courier_consignment_id ? /* @__PURE__ */ jsxs("span", { className: "text-[10px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200", children: [
                order.courier_name || "Courier",
                " Dispatched"
              ] }) : /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 italic", children: "No Dispatch" }),
              order.fraud_status === "safe" ? /* @__PURE__ */ jsx("span", { className: "text-[9px] font-semibold text-emerald-600", children: "Fraud Safe" }) : order.fraud_status === "review" || order.fraud_status === "high_risk" ? /* @__PURE__ */ jsx("span", { className: "text-[9px] font-bold text-rose-600 bg-rose-50 px-1 rounded border border-rose-200", children: "Risk Flagged" }) : null
            ] }) }),
            /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsx(
              Link,
              {
                href: route("admin.orders.show", order.id),
                className: "p-1.5 text-gray-500 hover:text-white hover:bg-[#081621] rounded-lg transition inline-block",
                title: "View Full Order Details",
                children: /* @__PURE__ */ jsx(Eye, { className: "w-4 h-4" })
              }
            ) })
          ] }, order.id)) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "6", className: "p-8 text-center text-gray-400", children: "No orders placed yet." }) }) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-4 bg-white rounded-2xl border border-gray-200/90 shadow-sm overflow-hidden flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "p-5 border-b border-gray-100 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(AlertTriangle, { className: "w-4 h-4 text-amber-500" }),
              /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: "Critical Stock Alert" })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full", children: "≤ 5 In Stock" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "p-4 divide-y divide-gray-100", children: lowStockProducts.length > 0 ? lowStockProducts.map((p) => /* @__PURE__ */ jsxs("div", { className: "py-3 flex items-center justify-between gap-3 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: p.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=50",
                  alt: p.name,
                  className: "w-9 h-9 rounded-lg object-contain border p-0.5 bg-gray-50 shrink-0"
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-800 truncate", children: p.name }),
                /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400", children: p.model || "Model N/A" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-right shrink-0", children: [
              /* @__PURE__ */ jsx("span", { className: `font-bold px-2 py-0.5 rounded text-[11px] border block ${p.quantity <= 0 ? "bg-rose-50 text-rose-600 border-rose-200" : "bg-amber-50 text-amber-700 border-amber-200"}`, children: p.quantity <= 0 ? "Out of Stock" : `${p.quantity} Left` }),
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("admin.products.edit", p.id),
                  className: "text-[10px] text-[#EF4A23] font-bold hover:underline mt-0.5 block",
                  children: "Update Stock"
                }
              )
            ] })
          ] }, p.id)) : /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 p-6 text-center", children: "All inventory thresholds are healthy." }) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "p-4 bg-gray-50/80 border-t border-gray-100 text-center", children: /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("admin.products.index"),
            className: "text-xs font-bold text-[#081621] hover:text-[#EF4A23] transition flex items-center justify-center gap-1",
            children: [
              /* @__PURE__ */ jsx("span", { children: "Manage Full Catalog & Inventory" }),
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        ) })
      ] })
    ] })
  ] });
}
export {
  Dashboard as default
};
