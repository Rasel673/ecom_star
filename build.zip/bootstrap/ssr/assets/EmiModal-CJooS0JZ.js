import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link } from "@inertiajs/react";
import { Calculator, X, CreditCard, Building2, BadgePercent, CheckCircle2, ShieldCheck, ChevronRight } from "lucide-react";
const EMI_BANKS = [
  { name: "City Bank AMEX", maxMonths: 36, cards: "American Express, Visa, Mastercard", promo: "0% Interest" },
  { name: "Eastern Bank (EBL)", maxMonths: 36, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "BRAC Bank", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Standard Chartered (SCB)", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Mutual Trust Bank (MTB)", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Prime Bank", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Dhaka Bank", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Southeast Bank", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "United Commercial Bank (UCB)", maxMonths: 18, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "LankaBangla Finance", maxMonths: 24, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Dutch Bangla Bank (DBBL)", maxMonths: 12, cards: "Nexus, Visa, Mastercard", promo: "0% Interest" },
  { name: "Bank Asia", maxMonths: 12, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "NCC Bank", maxMonths: 12, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Jamuna Bank", maxMonths: 12, cards: "Visa, Mastercard", promo: "0% Interest" },
  { name: "Trust Bank", maxMonths: 12, cards: "Visa, Mastercard", promo: "0% Interest" }
];
const TENURE_MONTHS = [3, 6, 9, 12, 18, 24, 36];
function EmiModal({ isOpen, onClose, product }) {
  if (!isOpen || !product) return null;
  const basePrice = Number(product.special_price || product.price || product.regular_price || 0);
  const [downPayment, setDownPayment] = useState(0);
  const [selectedTenure, setSelectedTenure] = useState(12);
  const [selectedBank, setSelectedBank] = useState(EMI_BANKS[0].name);
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "auto";
    };
  }, [onClose]);
  const currentBankObj = EMI_BANKS.find((b) => b.name === selectedBank) || EMI_BANKS[0];
  const financedAmount = Math.max(0, basePrice - Number(downPayment));
  const calcMonthly = (months) => {
    if (!months || months <= 0) return 0;
    return Math.round(financedAmount / months);
  };
  const monthlyInstallment = calcMonthly(selectedTenure);
  const handleSetDownPaymentPercent = (pct) => {
    const calculated = Math.round(basePrice * pct / 100);
    setDownPayment(calculated);
  };
  return /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4", children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: "relative bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col border border-gray-100 overflow-hidden animate-scale-up",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 sm:px-6 sm:py-5 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-900 via-[#112538] to-gray-900 text-white shrink-0", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: "w-10 h-10 rounded-xl bg-orange-500/20 border border-orange-500/30 text-[#EF4A23] flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(Calculator, { className: "w-5 h-5 text-orange-400" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("h3", { className: "text-base sm:text-lg font-black tracking-tight text-white", children: "0% EMI Installment Calculator" }),
                /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-2 py-0.5 rounded-full uppercase", children: "Up to 36 Months" })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-300", children: "Available on credit cards from 28+ leading banks across Bangladesh" })
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "text-gray-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition",
              children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "overflow-y-auto p-5 sm:p-6 space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center gap-4 bg-gray-50/80 p-4 rounded-2xl border border-gray-100", children: [
            product.thumbnail && /* @__PURE__ */ jsx(
              "img",
              {
                src: product.thumbnail,
                alt: product.name,
                className: "w-16 h-16 object-contain rounded-xl bg-white p-1 border border-gray-200 shrink-0"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex-1 text-center sm:text-left min-w-0", children: [
              /* @__PURE__ */ jsx("h4", { className: "font-bold text-gray-900 text-xs sm:text-sm line-clamp-1", children: product.name }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-1", children: [
                /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500", children: "Product Price:" }),
                /* @__PURE__ */ jsxs("span", { className: "text-base font-black text-[#EF4A23]", children: [
                  "৳",
                  basePrice.toLocaleString()
                ] }),
                product.model && /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-400 bg-white px-2 py-0.5 rounded border border-gray-200", children: [
                  "Model: ",
                  product.model
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-center sm:text-right shrink-0 bg-white p-3 rounded-xl border border-gray-100 shadow-sm w-full sm:w-auto", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 uppercase font-semibold block", children: "Estimated Monthly" }),
              /* @__PURE__ */ jsxs("span", { className: "text-xl sm:text-2xl font-black text-[#EF4A23]", children: [
                "৳",
                monthlyInstallment.toLocaleString(),
                /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500 font-normal", children: " /mo" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-3 bg-white p-4 sm:p-5 rounded-2xl border border-gray-200/90 shadow-sm", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-800 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsx(CreditCard, { className: "w-4 h-4 text-[#EF4A23]" }),
                  /* @__PURE__ */ jsx("span", { children: "Down Payment (Optional ৳)" })
                ] }),
                /* @__PURE__ */ jsxs("span", { className: "text-xs font-black text-gray-900 font-mono", children: [
                  "৳",
                  Number(downPayment).toLocaleString()
                ] })
              ] }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "number",
                  min: "0",
                  max: Math.max(0, basePrice - 1e3),
                  step: "500",
                  value: downPayment,
                  onChange: (e) => setDownPayment(Math.min(Math.max(0, Number(e.target.value)), basePrice - 1e3)),
                  className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3",
                  placeholder: "0"
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400", children: "Quick:" }),
                [0, 10, 20, 30, 50].map((pct) => /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleSetDownPaymentPercent(pct),
                    className: `px-2 py-1 text-[11px] rounded-lg font-semibold transition border ${downPayment === Math.round(basePrice * pct / 100) ? "bg-[#EF4A23] text-white border-[#EF4A23]" : "bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100"}`,
                    children: [
                      pct,
                      "%"
                    ]
                  },
                  pct
                ))
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "pt-2 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500", children: [
                /* @__PURE__ */ jsx("span", { children: "Financed (EMI) Amount:" }),
                /* @__PURE__ */ jsxs("span", { className: "font-black text-gray-900 font-mono", children: [
                  "৳",
                  financedAmount.toLocaleString()
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3 bg-white p-4 sm:p-5 rounded-2xl border border-gray-200/90 shadow-sm", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-xs font-bold text-gray-800 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Building2, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Select Credit Card Bank" })
              ] }),
              /* @__PURE__ */ jsx(
                "select",
                {
                  value: selectedBank,
                  onChange: (e) => {
                    setSelectedBank(e.target.value);
                    const b = EMI_BANKS.find((x) => x.name === e.target.value);
                    if (b && selectedTenure > b.maxMonths) {
                      setSelectedTenure(b.maxMonths);
                    }
                  },
                  className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3 font-semibold text-gray-800",
                  children: EMI_BANKS.map((b, idx) => /* @__PURE__ */ jsxs("option", { value: b.name, children: [
                    b.name,
                    " (Up to ",
                    b.maxMonths,
                    "M)"
                  ] }, idx))
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "bg-orange-50/70 border border-orange-200/70 p-3 rounded-xl text-xs space-y-1", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between font-bold text-gray-900", children: [
                  /* @__PURE__ */ jsx("span", { children: currentBankObj.name }),
                  /* @__PURE__ */ jsx("span", { className: "text-[#EF4A23]", children: currentBankObj.promo })
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-500", children: [
                  "Supported Cards: ",
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-700", children: currentBankObj.cards })
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-500", children: [
                  "Maximum Tenure: ",
                  /* @__PURE__ */ jsxs("strong", { className: "text-gray-700", children: [
                    currentBankObj.maxMonths,
                    " Months"
                  ] })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-gray-800 uppercase tracking-wider", children: "Select Duration (Months)" }),
              /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400", children: "Click any duration to recalculate" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5", children: TENURE_MONTHS.map((months) => {
              const isSupported = months <= currentBankObj.maxMonths;
              const isSelected = selectedTenure === months;
              const installment = calcMonthly(months);
              return /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  disabled: !isSupported,
                  onClick: () => setSelectedTenure(months),
                  className: `p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center relative ${!isSupported ? "opacity-40 bg-gray-50 border-gray-200 cursor-not-allowed" : isSelected ? "bg-[#081621] text-white border-[#081621] shadow-md ring-2 ring-[#EF4A23]/30 scale-[1.02]" : "bg-white hover:bg-orange-50/40 border-gray-200 text-gray-700 hover:border-orange-300"}`,
                  children: [
                    /* @__PURE__ */ jsxs("span", { className: `text-xs font-extrabold ${isSelected ? "text-orange-400" : "text-gray-900"}`, children: [
                      months,
                      " Months"
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: `text-xs font-black mt-1 ${isSelected ? "text-white" : "text-[#EF4A23]"}`, children: [
                      "৳",
                      installment.toLocaleString()
                    ] }),
                    /* @__PURE__ */ jsx("span", { className: `text-[10px] mt-0.5 ${isSelected ? "text-gray-300" : "text-gray-400"}`, children: "per month" }),
                    isSelected && /* @__PURE__ */ jsx("span", { className: "absolute -top-1.5 -right-1.5 w-4 h-4 bg-[#EF4A23] rounded-full text-white text-[9px] flex items-center justify-center", children: "✓" })
                  ]
                },
                months
              );
            }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "border border-gray-200 rounded-2xl overflow-hidden bg-white shadow-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxs("span", { className: "text-xs font-bold text-gray-900 uppercase tracking-wider flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(BadgePercent, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Installment Breakdown Matrix for ",
                  currentBankObj.name
                ] })
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-500 font-medium", children: "0% Interest Scheme" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
              /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-100/70 text-gray-500 font-bold uppercase text-[10px] border-b border-gray-200", children: [
                /* @__PURE__ */ jsx("th", { className: "py-2.5 px-4", children: "Duration" }),
                /* @__PURE__ */ jsx("th", { className: "py-2.5 px-4", children: "Monthly Payment" }),
                /* @__PURE__ */ jsx("th", { className: "py-2.5 px-4", children: "Financed Amount" }),
                /* @__PURE__ */ jsx("th", { className: "py-2.5 px-4", children: "Interest Rate" }),
                /* @__PURE__ */ jsx("th", { className: "py-2.5 px-4", children: "Total Payable" }),
                /* @__PURE__ */ jsx("th", { className: "py-2.5 px-4 text-center", children: "Status" })
              ] }) }),
              /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100 font-medium", children: TENURE_MONTHS.map((m) => {
                const isSupported = m <= currentBankObj.maxMonths;
                const isSelected = selectedTenure === m;
                const monthly = calcMonthly(m);
                const total = monthly * m + Number(downPayment);
                return /* @__PURE__ */ jsxs(
                  "tr",
                  {
                    onClick: () => isSupported && setSelectedTenure(m),
                    className: `transition cursor-pointer ${isSelected ? "bg-orange-50 font-bold text-gray-900" : isSupported ? "hover:bg-gray-50/70 text-gray-700" : "opacity-40 bg-gray-50/40 text-gray-400 cursor-not-allowed"}`,
                    children: [
                      /* @__PURE__ */ jsx("td", { className: "py-2.5 px-4", children: /* @__PURE__ */ jsxs("span", { className: `inline-flex items-center gap-1.5 ${isSelected ? "text-[#EF4A23]" : ""}`, children: [
                        isSelected && /* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-[#EF4A23]" }),
                        m,
                        " Months"
                      ] }) }),
                      /* @__PURE__ */ jsxs("td", { className: "py-2.5 px-4 font-black text-gray-900", children: [
                        "৳",
                        monthly.toLocaleString()
                      ] }),
                      /* @__PURE__ */ jsxs("td", { className: "py-2.5 px-4 text-gray-600", children: [
                        "৳",
                        financedAmount.toLocaleString()
                      ] }),
                      /* @__PURE__ */ jsx("td", { className: "py-2.5 px-4 text-emerald-600 font-bold", children: "0% Promo" }),
                      /* @__PURE__ */ jsxs("td", { className: "py-2.5 px-4 font-semibold text-gray-800", children: [
                        "৳",
                        total.toLocaleString()
                      ] }),
                      /* @__PURE__ */ jsx("td", { className: "py-2.5 px-4 text-center", children: isSupported ? /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800", children: [
                        /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3 h-3" }),
                        "Available"
                      ] }) : /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-400", children: "Bank Excluded" }) })
                    ]
                  },
                  m
                );
              }) })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-amber-50/60 border border-amber-200/80 rounded-2xl p-4 text-xs text-amber-900 space-y-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold", children: [
              /* @__PURE__ */ jsx(ShieldCheck, { className: "w-4 h-4 text-amber-600 shrink-0" }),
              /* @__PURE__ */ jsx("span", { children: "Important Guidelines for EMI Facility" })
            ] }),
            /* @__PURE__ */ jsxs("ul", { className: "grid grid-cols-1 md:grid-cols-2 gap-1.5 text-[11px] text-amber-800 list-disc list-inside", children: [
              /* @__PURE__ */ jsx("li", { children: "Available for eligible Credit Cards from listed banks with sufficient card limit." }),
              /* @__PURE__ */ jsx("li", { children: "Minimum order value for EMI is ৳5,000." }),
              /* @__PURE__ */ jsx("li", { children: "Debit Cards are not eligible for bank EMI as per Bangladesh Bank policy." }),
              /* @__PURE__ */ jsx("li", { children: "Available for both online checkout and nationwide branch POS machines." })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 sm:px-6 sm:py-4 bg-gray-50 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0", children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/page/emi-calculation",
              className: "text-xs text-gray-600 hover:text-[#EF4A23] font-semibold flex items-center gap-1 transition",
              children: [
                /* @__PURE__ */ jsx("span", { children: "View All 28+ Partner Banks & Official Policy" }),
                /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "w-full sm:w-auto px-6 py-2.5 bg-[#081621] hover:bg-[#112538] text-white text-xs font-bold rounded-xl transition shadow-sm",
              children: "Close Calculator"
            }
          )
        ] })
      ]
    }
  ) });
}
export {
  EMI_BANKS as E,
  TENURE_MONTHS as T,
  EmiModal as a
};
