import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { Link, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-DI7Lhw0O.js";
import { MessageSquare, User, Send, Clock, CheckCircle2 } from "lucide-react";
function Messages({ messages }) {
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [replyText, setReplyText] = useState("");
  const [replyStatus, setReplyStatus] = useState("replied");
  const [submitting, setSubmitting] = useState(false);
  const handleOpenReply = (msg) => {
    setSelectedMessage(msg);
    setReplyText(msg.admin_reply || "");
    setReplyStatus(msg.status === "open" ? "replied" : msg.status);
  };
  const handleSendReply = (e) => {
    e.preventDefault();
    if (!selectedMessage || !replyText.trim()) return;
    setSubmitting(true);
    router.post(route("admin.messages.reply", selectedMessage.id), {
      admin_reply: replyText,
      status: replyStatus
    }, {
      preserveScroll: true,
      onSuccess: () => {
        setSelectedMessage(null);
        setReplyText("");
      },
      onFinish: () => setSubmitting(false)
    });
  };
  const getStatusBadge = (status) => {
    switch (status) {
      case "replied":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200", children: [
          /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3 h-3" }),
          " Replied"
        ] });
      case "closed":
        return /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-gray-100 text-gray-700 border border-gray-300", children: "Closed" });
      default:
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200", children: [
          /* @__PURE__ */ jsx(Clock, { className: "w-3 h-3" }),
          " Pending Reply"
        ] });
    }
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "Customer Messages & Inquiries", children: [
    /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6", children: /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-xl font-black text-gray-900 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(MessageSquare, { className: "w-6 h-6 text-[#EF4A23]" }),
        /* @__PURE__ */ jsx("span", { children: "Customer Inquiries & Messages" })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Respond directly to customer support questions, order queries, and assistance requests." })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs text-gray-600", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 text-gray-700 uppercase font-semibold border-b text-[11px] tracking-wider", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Customer" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Subject & Details" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Order Ref" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Date" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "p-4 text-right", children: "Action" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: messages.data && messages.data.length > 0 ? messages.data.map((msg) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/70 transition", children: [
          /* @__PURE__ */ jsxs("td", { className: "p-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "font-bold text-gray-900 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(User, { className: "w-3.5 h-3.5 text-gray-400" }),
              /* @__PURE__ */ jsx("span", { children: msg.user?.name || "Customer" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-400 mt-0.5", children: msg.user?.email }),
            msg.user?.phone && /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-400", children: msg.user?.phone })
          ] }),
          /* @__PURE__ */ jsxs("td", { className: "p-4 max-w-md", children: [
            /* @__PURE__ */ jsx("div", { className: "font-bold text-gray-900 mb-1", children: msg.subject }),
            /* @__PURE__ */ jsx("p", { className: "text-gray-500 line-clamp-2 leading-relaxed", children: msg.message }),
            msg.admin_reply && /* @__PURE__ */ jsxs("div", { className: "mt-2 text-[11px] bg-blue-50/80 border border-blue-100 rounded-lg p-2 text-blue-900", children: [
              /* @__PURE__ */ jsx("span", { className: "font-bold block text-blue-700", children: "Official Reply:" }),
              /* @__PURE__ */ jsx("span", { className: "line-clamp-2", children: msg.admin_reply })
            ] })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-4 whitespace-nowrap", children: msg.order_number ? /* @__PURE__ */ jsxs("span", { className: "font-mono font-bold text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded", children: [
            "#",
            msg.order_number
          ] }) : /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "—" }) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 whitespace-nowrap text-gray-500 text-[11px]", children: new Date(msg.created_at).toLocaleString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          }) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 whitespace-nowrap", children: getStatusBadge(msg.status) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 text-right whitespace-nowrap", children: /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => handleOpenReply(msg),
              className: "px-3 py-1.5 bg-[#081621] hover:bg-[#EF4A23] text-white text-xs font-semibold rounded-lg transition shadow-sm inline-flex items-center gap-1.5",
              children: [
                /* @__PURE__ */ jsx(Send, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: msg.admin_reply ? "Edit Reply" : "Reply" })
              ]
            }
          ) })
        ] }, msg.id)) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "6", className: "p-8 text-center text-gray-400", children: "No customer messages found yet." }) }) })
      ] }) }),
      messages.links && messages.links.length > 3 && /* @__PURE__ */ jsxs("div", { className: "p-4 border-t border-gray-100 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-gray-500", children: [
          "Showing ",
          messages.from || 0,
          " to ",
          messages.to || 0,
          " of ",
          messages.total,
          " messages"
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1", children: messages.links.map((link, idx) => /* @__PURE__ */ jsx(
          Link,
          {
            href: link.url || "#",
            dangerouslySetInnerHTML: { __html: link.label },
            className: `px-3 py-1 text-xs rounded-lg border transition ${link.active ? "bg-[#EF4A23] text-white border-[#EF4A23]" : !link.url ? "text-gray-300 border-gray-200 cursor-not-allowed" : "text-gray-600 border-gray-200 hover:bg-gray-50"}`
          },
          idx
        )) })
      ] })
    ] }),
    selectedMessage && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-gray-100", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] px-6 py-4 flex items-center justify-between text-white", children: [
        /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(MessageSquare, { className: "w-4 h-4 text-[#EF4A23]" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "Reply to ",
            selectedMessage.user?.name || "Customer"
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setSelectedMessage(null),
            className: "text-gray-400 hover:text-white text-lg leading-none",
            children: "×"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleSendReply, className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 p-4 rounded-xl border border-gray-200", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-xs text-gray-500 mb-1", children: [
            "Subject: ",
            /* @__PURE__ */ jsx("strong", { className: "text-gray-900", children: selectedMessage.subject }),
            selectedMessage.order_number && /* @__PURE__ */ jsxs("span", { className: "ml-2 font-mono text-xs bg-gray-200 px-1.5 py-0.5 rounded text-gray-700", children: [
              "Order #",
              selectedMessage.order_number
            ] })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-700 whitespace-pre-wrap leading-relaxed mt-2 bg-white p-3 rounded-lg border border-gray-100", children: selectedMessage.message })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Official Admin Response *" }),
          /* @__PURE__ */ jsx(
            "textarea",
            {
              required: true,
              rows: "5",
              value: replyText,
              onChange: (e) => setReplyText(e.target.value),
              placeholder: "Type your official answer, delivery update, or support solution here...",
              className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] p-3 leading-relaxed"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-700 mb-1", children: "Update Ticket Status" }),
          /* @__PURE__ */ jsxs(
            "select",
            {
              value: replyStatus,
              onChange: (e) => setReplyStatus(e.target.value),
              className: "w-full text-xs rounded-lg border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3",
              children: [
                /* @__PURE__ */ jsx("option", { value: "replied", children: "Replied (Customer will see answer)" }),
                /* @__PURE__ */ jsx("option", { value: "closed", children: "Closed (Issue resolved)" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setSelectedMessage(null),
              className: "px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "submit",
              disabled: submitting,
              className: "px-5 py-2.5 rounded-xl bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs flex items-center gap-1.5 shadow-md disabled:opacity-50 transition",
              children: [
                /* @__PURE__ */ jsx(Send, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: submitting ? "Sending..." : "Send Response" })
              ]
            }
          )
        ] })
      ] })
    ] }) })
  ] });
}
export {
  Messages as default
};
