import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { usePage, useForm, Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-D2UfBtpP.js";
import { ChevronRight, Search, CheckCircle2, Clock, Truck, ShieldCheck, ExternalLink, AlertCircle, Calculator, CreditCard, Check, Share2, ShoppingBag, BadgePercent, CheckCircle, Sparkles, Building2, HelpCircle, ChevronDown, Wrench, Send, PhoneCall, Mail, MapPin } from "lucide-react";
import { E as EMI_BANKS, T as TENURE_MONTHS } from "./EmiModal-CJooS0JZ.js";
const EMI_FAQS = [
  {
    q: "What is the minimum purchase amount to avail 0% EMI?",
    a: "The minimum purchase value to avail EMI facilities is ৳5,000. You can also bundle multiple products together into a single cart/order to meet the minimum threshold."
  },
  {
    q: "Can I avail EMI with a Debit Card or bKash / Nagad?",
    a: "No. Under Bangladesh Bank regulations, EMI facilities are strictly available for eligible Credit Cards issued by scheduled commercial banks. Regular Debit Cards or mobile banking accounts cannot be converted to bank EMI."
  },
  {
    q: "Is there any hidden interest or extra processing fee?",
    a: "Tech Shoppers offers 0% promotional interest EMI with our partner banks for 3, 6, 9, and 12-month tenures. Depending on your issuing bank, a nominal bank processing charge (usually 1.5% to 2.5%) may be billed directly by the card issuing bank on extended tenures (18 to 36 months)."
  },
  {
    q: "Can I avail EMI online as well as at physical retail shops?",
    a: "Yes! You can choose the Online Credit Card EMI option during web checkout, or visit any of our official branches nationwide to swipe your card on our dedicated multi-bank POS terminals."
  },
  {
    q: "How does the monthly installment deduction work?",
    a: "When you place the order, the total product value is temporarily blocked against your card credit limit. Within 5-7 working days, your bank automatically converts this blocked amount into monthly equal installments on your regular monthly credit card statement."
  }
];
function Page({ page, trackingResult = null, searchQuery = {}, seo = {} }) {
  const { settings } = usePage().props;
  const siteName = settings?.site_name || "Tech Shoppers";
  const [emiPrice, setEmiPrice] = useState(65e3);
  const [emiDownPayment, setEmiDownPayment] = useState(0);
  const [emiMonths, setEmiMonths] = useState(12);
  const [emiBank, setEmiBank] = useState("City Bank AMEX");
  const [emiRate, setEmiRate] = useState(0);
  const [openEmiFaq, setOpenEmiFaq] = useState(null);
  const [copiedPlan, setCopiedPlan] = useState(false);
  const currentBankObj = EMI_BANKS.find((b) => b.name === emiBank) || EMI_BANKS[0];
  const financedAmount = Math.max(0, emiPrice - emiDownPayment);
  const monthlyInstallment = emiMonths > 0 ? Math.round(financedAmount * (1 + emiRate / 100) / emiMonths) : 0;
  const totalPayable = monthlyInstallment * emiMonths + Number(emiDownPayment);
  const calcMonthly = (months) => {
    if (!months || months <= 0) return 0;
    return Math.round(financedAmount * (1 + emiRate / 100) / months);
  };
  const handleCopyEmiSummary = () => {
    const text = `EMI Calculation for ৳${emiPrice.toLocaleString()} at ${siteName}:
• Partner Bank: ${emiBank}
• Tenure: ${emiMonths} Months
• Down Payment: ৳${Number(emiDownPayment).toLocaleString()}
• Monthly Installment: ৳${monthlyInstallment.toLocaleString()}/mo
• Total Cost: ৳${totalPayable.toLocaleString()} (0% Interest)`;
    navigator.clipboard?.writeText(text);
    setCopiedPlan(true);
    setTimeout(() => setCopiedPlan(false), 2500);
  };
  const [trackingOrderNo, setTrackingOrderNo] = useState(searchQuery.order_number || "");
  const [trackingPhone, setTrackingPhone] = useState(searchQuery.phone || "");
  const handleSearchOrder = (e) => {
    e.preventDefault();
    router.get(
      route("page.show", page.slug),
      {
        order_number: trackingOrderNo || void 0,
        phone: trackingPhone || void 0
      },
      { preserveState: true }
    );
  };
  const { data: inquiryData, setData: setInquiryData, post: postInquiry, processing: inquiryProcessing, reset: resetInquiry } = useForm({
    name: "",
    phone: "",
    email: "",
    subject: "",
    message: "",
    order_number: ""
  });
  const handleInquirySubmit = (e) => {
    e.preventDefault();
    postInquiry(route("page.inquiry"), {
      preserveScroll: true,
      onSuccess: () => resetInquiry()
    });
  };
  return /* @__PURE__ */ jsx(
    FrontendLayout,
    {
      title: seo.title || page.title,
      description: seo.description || page.subtitle,
      children: /* @__PURE__ */ jsxs("div", { className: "max-w-6xl mx-auto py-4 sm:py-6 space-y-8", children: [
        /* @__PURE__ */ jsxs("nav", { className: "flex items-center gap-1.5 text-xs text-gray-500", children: [
          /* @__PURE__ */ jsx(Link, { href: "/", className: "hover:text-[#EF4A23]", children: "Home" }),
          /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-gray-400" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold", children: page.title })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-r from-[#081621] via-[#112538] to-[#081621] text-white rounded-3xl p-6 sm:p-10 shadow-xl border border-gray-800 relative overflow-hidden", children: [
          /* @__PURE__ */ jsxs("div", { className: "relative z-10 max-w-2xl", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-[11px] font-bold text-orange-400 bg-orange-400/10 border border-orange-400/20 px-3 py-1 rounded-full uppercase tracking-wider inline-block mb-3", children: [
              siteName,
              " Official Portal"
            ] }),
            /* @__PURE__ */ jsx("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white", children: page.title }),
            page.subtitle && /* @__PURE__ */ jsx("p", { className: "text-sm sm:text-base text-gray-300 mt-2 font-medium", children: page.subtitle })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "absolute right-0 top-0 bottom-0 w-80 bg-gradient-to-l from-orange-600/15 to-transparent pointer-events-none" })
        ] }),
        page.page_type === "order_tracking" && /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm", children: [
            /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 mb-2 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Search, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: "Look Up Your Order Status" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mb-6", children: "Enter your Tech Shoppers Order Number (e.g. ST-261008-1234) and/or your checkout phone number." }),
            /* @__PURE__ */ jsxs("form", { onSubmit: handleSearchOrder, className: "grid grid-cols-1 sm:grid-cols-12 gap-3 sm:gap-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "sm:col-span-5", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Order Number (Optional)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: trackingOrderNo,
                    onChange: (e) => setTrackingOrderNo(e.target.value),
                    placeholder: "e.g. ST-261008-8472",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3 font-mono"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "sm:col-span-5", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Phone Number (Optional)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "tel",
                    value: trackingPhone,
                    onChange: (e) => setTrackingPhone(e.target.value),
                    placeholder: "01XXXXXXXXX",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3 font-mono"
                  }
                )
              ] }),
              /* @__PURE__ */ jsx("div", { className: "sm:col-span-2 flex items-end", children: /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "submit",
                  className: "w-full py-2.5 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center justify-center gap-1.5",
                  children: [
                    /* @__PURE__ */ jsx(Search, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsx("span", { children: "Track Order" })
                  ]
                }
              ) })
            ] })
          ] }),
          trackingResult ? /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-lg space-y-6 animate-fade-in", children: [
            /* @__PURE__ */ jsxs("div", { className: "border-b pb-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 uppercase font-semibold", children: "Order Details" }),
                  /* @__PURE__ */ jsxs("h3", { className: "text-lg font-black text-gray-900 font-mono", children: [
                    "Order #",
                    trackingResult.order_number
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "text-left sm:text-right", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 block", children: "Total Amount" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-xl font-black text-[#EF4A23]", children: [
                    "৳",
                    Number(trackingResult.total).toLocaleString()
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 gap-2 text-center text-xs", children: [
                { key: "placed", label: "Order Placed", active: true, icon: CheckCircle2 },
                {
                  key: "processing",
                  label: "Processing",
                  active: ["processing", "dispatched", "delivered"].includes(trackingResult.order_status),
                  icon: Clock
                },
                {
                  key: "dispatched",
                  label: "Dispatched",
                  active: ["dispatched", "delivered"].includes(trackingResult.order_status) || Boolean(trackingResult.courier_tracking_id),
                  icon: Truck
                },
                {
                  key: "delivered",
                  label: "Delivered",
                  active: trackingResult.order_status === "delivered",
                  icon: ShieldCheck
                }
              ].map((step, idx) => {
                const Icon = step.icon;
                return /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
                  /* @__PURE__ */ jsx("div", { className: `w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center mb-1.5 transition ${step.active ? "bg-emerald-600 text-white shadow-md" : "bg-gray-100 text-gray-400"}`, children: /* @__PURE__ */ jsx(Icon, { className: "w-4 h-4 sm:w-5 sm:h-5" }) }),
                  /* @__PURE__ */ jsx("span", { className: `text-[11px] sm:text-xs font-bold ${step.active ? "text-gray-900" : "text-gray-400"}`, children: step.label })
                ] }, idx);
              }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs", children: [
              /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-1.5", children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-800 block text-xs", children: "Customer Information" }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Name:" }),
                  " ",
                  trackingResult.customer_name
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Phone:" }),
                  " ",
                  trackingResult.customer_phone
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Address:" }),
                  " ",
                  trackingResult.delivery_address
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Payment:" }),
                  " ",
                  trackingResult.payment_method?.toUpperCase(),
                  " (",
                  trackingResult.payment_status,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-4 bg-purple-50/60 rounded-2xl border border-purple-100 space-y-1.5", children: [
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-purple-900 block text-xs flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsx(Truck, { className: "w-4 h-4 text-purple-600" }),
                  /* @__PURE__ */ jsx("span", { children: "Courier Logistics Information" })
                ] }),
                trackingResult.courier_tracking_id ? /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsxs("p", { children: [
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Courier Service:" }),
                    " ",
                    trackingResult.courier_name || "Express Courier"
                  ] }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Consignment Code:" }),
                    " ",
                    /* @__PURE__ */ jsx("span", { className: "font-mono font-bold text-purple-900", children: trackingResult.courier_tracking_id })
                  ] }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Delivery Status:" }),
                    " ",
                    trackingResult.courier_status || "In Transit"
                  ] }),
                  trackingResult.courier_tracking_url && /* @__PURE__ */ jsxs(
                    "a",
                    {
                      href: trackingResult.courier_tracking_url,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-[11px] shadow-sm transition",
                      children: [
                        /* @__PURE__ */ jsx("span", { children: "Live Courier Tracking" }),
                        /* @__PURE__ */ jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsx("p", { className: "text-gray-500 italic pt-2", children: "Your parcel is being packaged in our central warehouse and scheduled for courier pickup." })
              ] })
            ] }),
            trackingResult.items && trackingResult.items.length > 0 && /* @__PURE__ */ jsxs("div", { className: "pt-2", children: [
              /* @__PURE__ */ jsxs("h4", { className: "text-xs font-bold text-gray-800 uppercase tracking-wider mb-2", children: [
                "Package Items (",
                trackingResult.items.length,
                ")"
              ] }),
              /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100 border rounded-xl overflow-hidden", children: trackingResult.items.map((item, idx) => /* @__PURE__ */ jsxs("div", { className: "p-3 flex items-center justify-between text-xs", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-900", children: item.product_name }),
                  /* @__PURE__ */ jsxs("span", { className: "text-gray-400 ml-2", children: [
                    "Qty: ",
                    item.quantity
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-800", children: [
                  "৳",
                  Number(item.subtotal).toLocaleString()
                ] })
              ] }, idx)) })
            ] })
          ] }) : searchQuery.order_number || searchQuery.phone ? /* @__PURE__ */ jsxs("div", { className: "p-6 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs flex items-start gap-3", children: [
            /* @__PURE__ */ jsx(AlertCircle, { className: "w-5 h-5 text-rose-600 shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("strong", { className: "block font-bold", children: "No Order Found Matching Details" }),
              /* @__PURE__ */ jsxs("p", { className: "text-rose-600 mt-0.5", children: [
                "Please double-check your Order Number or Phone Number. If you recently placed the order, give our system a few minutes or call our hotline at ",
                /* @__PURE__ */ jsx("strong", { children: "16793" }),
                "."
              ] })
            ] })
          ] }) : null
        ] }),
        page.page_type === "emi_calculator" && /* @__PURE__ */ jsxs("div", { className: "space-y-10", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start", children: [
            /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-100 pb-4", children: [
                /* @__PURE__ */ jsxs("h2", { className: "text-base sm:text-lg font-black text-gray-900 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(Calculator, { className: "w-5 h-5 text-[#EF4A23]" }),
                  /* @__PURE__ */ jsx("span", { children: "Interactive EMI Installment Planner" })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Customize your purchase price, down payment, bank, and duration to see instant monthly payments." })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Total Purchase Amount (৳)" }),
                  /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                    /* @__PURE__ */ jsx("span", { className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold text-xs", children: "৳" }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "number",
                        min: "5000",
                        max: "1000000",
                        step: "1000",
                        value: emiPrice,
                        onChange: (e) => setEmiPrice(Math.max(5e3, Number(e.target.value))),
                        className: "w-36 text-right pl-7 pr-3 py-1.5 text-xs font-mono font-black text-[#EF4A23] rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23]"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "range",
                    min: "5000",
                    max: "500000",
                    step: "5000",
                    value: Math.min(5e5, emiPrice),
                    onChange: (e) => setEmiPrice(Number(e.target.value)),
                    className: "w-full accent-[#EF4A23] cursor-pointer"
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-1.5 pt-1", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 mr-1", children: "Popular:" }),
                  [25e3, 5e4, 8e4, 12e4, 2e5, 35e4].map((preset) => /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setEmiPrice(preset),
                      className: `px-2.5 py-1 text-[11px] font-semibold rounded-lg transition border ${emiPrice === preset ? "bg-[#EF4A23] text-white border-[#EF4A23]" : "bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100"}`,
                      children: [
                        "৳",
                        (preset / 1e3).toFixed(0),
                        "k"
                      ]
                    },
                    preset
                  ))
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-3 pt-3 border-t border-gray-100", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Down Payment (Optional ৳)" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-xs font-bold text-gray-900 font-mono", children: [
                    "৳",
                    Number(emiDownPayment).toLocaleString()
                  ] })
                ] }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    min: "0",
                    max: Math.max(0, emiPrice - 5e3),
                    step: "1000",
                    value: emiDownPayment,
                    onChange: (e) => setEmiDownPayment(Math.min(Math.max(0, emiPrice - 5e3), Math.max(0, Number(e.target.value)))),
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3 font-mono",
                    placeholder: "0"
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 mr-1", children: "Percentage:" }),
                  [0, 10, 20, 30, 50].map((pct) => {
                    const calculated = Math.round(emiPrice * pct / 100);
                    return /* @__PURE__ */ jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => setEmiDownPayment(calculated),
                        className: `px-2 py-1 text-[11px] font-semibold rounded-lg transition border ${emiDownPayment === calculated ? "bg-[#EF4A23] text-white border-[#EF4A23]" : "bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100"}`,
                        children: [
                          pct,
                          "%"
                        ]
                      },
                      pct
                    );
                  })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-3 pt-3 border-t border-gray-100", children: [
                /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700 block", children: "Select Your Credit Card Bank" }),
                /* @__PURE__ */ jsx(
                  "select",
                  {
                    value: emiBank,
                    onChange: (e) => {
                      setEmiBank(e.target.value);
                      const b = EMI_BANKS.find((x) => x.name === e.target.value);
                      if (b && emiMonths > b.maxMonths) {
                        setEmiMonths(b.maxMonths);
                      }
                    },
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3 font-semibold text-gray-800",
                    children: EMI_BANKS.map((b, idx) => /* @__PURE__ */ jsxs("option", { value: b.name, children: [
                      b.name,
                      " — Up to ",
                      b.maxMonths,
                      " Months (",
                      b.cards,
                      ")"
                    ] }, idx))
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "bg-orange-50/70 border border-orange-200/70 p-3 rounded-xl text-xs space-y-1", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between font-bold text-gray-900", children: [
                    /* @__PURE__ */ jsx("span", { children: currentBankObj.name }),
                    /* @__PURE__ */ jsx("span", { className: "text-[#EF4A23] font-bold", children: currentBankObj.promo })
                  ] }),
                  /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-600", children: [
                    "Eligible Cards: ",
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-800", children: currentBankObj.cards })
                  ] }),
                  /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-gray-600", children: [
                    "Maximum Duration: ",
                    /* @__PURE__ */ jsxs("strong", { className: "text-gray-800", children: [
                      currentBankObj.maxMonths,
                      " Months"
                    ] })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-3 pt-3 border-t border-gray-100", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Select EMI Tenure (Duration)" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-400", children: [
                    "Selected: ",
                    emiMonths,
                    " Months"
                  ] })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 sm:grid-cols-7 gap-2", children: TENURE_MONTHS.map((m) => {
                  const isSupported = m <= currentBankObj.maxMonths;
                  const isSelected = emiMonths === m;
                  return /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      disabled: !isSupported,
                      onClick: () => setEmiMonths(m),
                      className: `py-2.5 px-2 text-xs font-bold rounded-xl border text-center transition flex flex-col items-center justify-center ${!isSupported ? "opacity-40 bg-gray-50 border-gray-200 cursor-not-allowed" : isSelected ? "bg-[#081621] text-white border-[#081621] shadow-md ring-2 ring-[#EF4A23]/30 scale-[1.02]" : "bg-white text-gray-700 border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`,
                      children: [
                        /* @__PURE__ */ jsxs("span", { className: isSelected ? "text-orange-400" : "", children: [
                          m,
                          "M"
                        ] }),
                        /* @__PURE__ */ jsxs("span", { className: `text-[10px] mt-0.5 ${isSelected ? "text-gray-200" : "text-gray-400"}`, children: [
                          "৳",
                          (calcMonthly(m) / 1e3).toFixed(1),
                          "k"
                        ] })
                      ]
                    },
                    m
                  );
                }) })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "lg:col-span-5 bg-gradient-to-br from-[#081621] via-[#112538] to-[#081621] text-white p-6 sm:p-8 rounded-3xl shadow-2xl flex flex-col justify-between border border-gray-800 sticky top-24", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b border-gray-800 pb-5 mb-6", children: [
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 uppercase tracking-wider block font-medium", children: "Monthly Installment (EMI)" }),
                    /* @__PURE__ */ jsxs("span", { className: "text-3xl sm:text-4xl font-black text-[#EF4A23] mt-1 block", children: [
                      "৳",
                      monthlyInstallment.toLocaleString(),
                      /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 font-normal ml-1.5", children: "/ month" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-500/20 text-[#EF4A23] flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(CreditCard, { className: "w-6 h-6" }) })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-3 text-xs", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Total Purchase Value:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      "৳",
                      emiPrice.toLocaleString()
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Down Payment:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      "৳",
                      Number(emiDownPayment).toLocaleString()
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Net Financed Amount:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-orange-400", children: [
                      "৳",
                      financedAmount.toLocaleString()
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Installment Duration:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      emiMonths,
                      " Months"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Card Issuing Bank:" }),
                    /* @__PURE__ */ jsx("span", { className: "font-bold text-white", children: emiBank })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Annual Interest Scheme:" }),
                    /* @__PURE__ */ jsx("span", { className: "font-bold text-emerald-400", children: "0% Promotional EMI" })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-2", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Total Payable:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-black text-white text-sm", children: [
                      "৳",
                      totalPayable.toLocaleString()
                    ] })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-8 pt-4 border-t border-gray-800 space-y-4", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: handleCopyEmiSummary,
                      className: "flex-1 py-2.5 px-3 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition border border-white/10",
                      children: [
                        copiedPlan ? /* @__PURE__ */ jsx(Check, { className: "w-4 h-4 text-emerald-400" }) : /* @__PURE__ */ jsx(Share2, { className: "w-4 h-4 text-orange-400" }),
                        /* @__PURE__ */ jsx("span", { children: copiedPlan ? "Plan Copied!" : "Copy EMI Plan" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: "/search",
                      className: "flex-1 py-2.5 px-3 bg-[#EF4A23] hover:bg-[#d63c17] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-md",
                      children: [
                        /* @__PURE__ */ jsx(ShoppingBag, { className: "w-4 h-4" }),
                        /* @__PURE__ */ jsx("span", { children: "Shop Products" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-gray-400 space-y-1", children: [
                  /* @__PURE__ */ jsxs("p", { className: "flex items-center gap-1.5 text-emerald-400 font-semibold", children: [
                    /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4 shrink-0" }),
                    /* @__PURE__ */ jsxs("span", { children: [
                      "Available online & at all ",
                      siteName,
                      " retail branches nationwide."
                    ] })
                  ] }),
                  /* @__PURE__ */ jsx("p", { children: "* Credit card with available limit equivalent to full order amount is required." })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200/90 shadow-sm overflow-hidden", children: [
            /* @__PURE__ */ jsxs("div", { className: "p-6 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gray-50/70", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("h3", { className: "text-sm sm:text-base font-black text-gray-900 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(BadgePercent, { className: "w-5 h-5 text-[#EF4A23]" }),
                  /* @__PURE__ */ jsx("span", { children: "Complete Tenure Comparison Matrix" })
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 mt-0.5", children: [
                  "Overview of monthly installments for ৳",
                  emiPrice.toLocaleString(),
                  " across all duration terms with ",
                  currentBankObj.name,
                  "."
                ] })
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 self-start sm:self-auto", children: "0% Promo Interest" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
              /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-100/80 text-gray-500 font-bold uppercase text-[10px] border-b border-gray-200", children: [
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6", children: "Tenure (Duration)" }),
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6", children: "Monthly Installment" }),
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6", children: "Financed Amount" }),
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6", children: "Interest Rate" }),
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6", children: "Total Amount" }),
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6 text-center", children: "Bank Support" }),
                /* @__PURE__ */ jsx("th", { className: "py-3 px-6 text-center", children: "Action" })
              ] }) }),
              /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100 font-medium", children: TENURE_MONTHS.map((m) => {
                const isSupported = m <= currentBankObj.maxMonths;
                const isSelected = emiMonths === m;
                const monthly = calcMonthly(m);
                const total = monthly * m + Number(emiDownPayment);
                return /* @__PURE__ */ jsxs(
                  "tr",
                  {
                    onClick: () => isSupported && setEmiMonths(m),
                    className: `transition cursor-pointer ${isSelected ? "bg-orange-50/80 font-bold text-gray-900" : isSupported ? "hover:bg-gray-50 text-gray-700" : "opacity-40 bg-gray-50/30 text-gray-400 cursor-not-allowed"}`,
                    children: [
                      /* @__PURE__ */ jsx("td", { className: "py-3.5 px-6", children: /* @__PURE__ */ jsxs("span", { className: `inline-flex items-center gap-2 ${isSelected ? "text-[#EF4A23]" : ""}`, children: [
                        isSelected && /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-[#EF4A23]" }),
                        /* @__PURE__ */ jsxs("strong", { className: "text-gray-900 font-black", children: [
                          m,
                          " Months"
                        ] })
                      ] }) }),
                      /* @__PURE__ */ jsxs("td", { className: "py-3.5 px-6 font-black text-gray-900 text-sm", children: [
                        "৳",
                        monthly.toLocaleString(),
                        /* @__PURE__ */ jsx("span", { className: "text-[11px] font-normal text-gray-400", children: "/mo" })
                      ] }),
                      /* @__PURE__ */ jsxs("td", { className: "py-3.5 px-6 text-gray-600 font-mono", children: [
                        "৳",
                        financedAmount.toLocaleString()
                      ] }),
                      /* @__PURE__ */ jsx("td", { className: "py-3.5 px-6 text-emerald-600 font-bold", children: "0% Promo" }),
                      /* @__PURE__ */ jsxs("td", { className: "py-3.5 px-6 text-gray-800 font-mono font-bold", children: [
                        "৳",
                        total.toLocaleString()
                      ] }),
                      /* @__PURE__ */ jsx("td", { className: "py-3.5 px-6 text-center", children: isSupported ? /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800", children: [
                        /* @__PURE__ */ jsx(CheckCircle, { className: "w-3 h-3" }),
                        "Available"
                      ] }) : /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-400", children: [
                        "Max ",
                        currentBankObj.maxMonths,
                        "M"
                      ] }) }),
                      /* @__PURE__ */ jsx("td", { className: "py-3.5 px-6 text-center", children: /* @__PURE__ */ jsx(
                        "button",
                        {
                          type: "button",
                          disabled: !isSupported,
                          onClick: (e) => {
                            e.stopPropagation();
                            if (isSupported) setEmiMonths(m);
                          },
                          className: `px-3 py-1 text-[11px] rounded-lg font-bold transition ${isSelected ? "bg-[#EF4A23] text-white shadow-xs" : isSupported ? "bg-gray-100 hover:bg-gray-200 text-gray-700" : "bg-gray-100 text-gray-300 cursor-not-allowed"}`,
                          children: isSelected ? "Active Plan" : "Select"
                        }
                      ) })
                    ]
                  },
                  m
                );
              }) })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-6", children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-base font-black text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Sparkles, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsxs("span", { children: [
                "How EMI Facility Works at ",
                siteName
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: [
              {
                step: "01",
                title: "Choose Eligible Product",
                desc: "Pick any laptop, PC component, or gadget valued ৳5,000 or higher (or multiple items combined in cart)."
              },
              {
                step: "02",
                title: "Select Partner Bank",
                desc: "Hold an eligible Credit Card issued by any of our 28+ partnered commercial banks in Bangladesh."
              },
              {
                step: "03",
                title: "Pick 3 to 36 Months Tenure",
                desc: "Select your preferred duration during online checkout or on branch POS swipe machines."
              },
              {
                step: "04",
                title: "Auto-Converted by Bank",
                desc: "Your card bank blocks the amount and automatically converts it into easy equal monthly credit card bills."
              }
            ].map((step, idx) => /* @__PURE__ */ jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-gray-50 border border-gray-100 space-y-2 relative overflow-hidden group hover:border-orange-200 transition", children: [
              /* @__PURE__ */ jsx("span", { className: "text-2xl font-black text-orange-200 group-hover:text-orange-300 transition", children: step.step }),
              /* @__PURE__ */ jsx("h4", { className: "text-xs font-bold text-gray-900", children: step.title }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-500 leading-relaxed", children: step.desc })
            ] }, idx)) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-6", children: [
            /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2", children: /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("h3", { className: "text-base font-black text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(Building2, { className: "w-5 h-5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "28+ Partner Banks Categorized by Tenure" })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "0% Interest EMI facilities available both online and across all branch showrooms." })
            ] }) }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "p-5 rounded-2xl bg-emerald-50/50 border border-emerald-200/70 space-y-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs font-black text-emerald-900 uppercase tracking-wider", children: "Up to 36 Months (3 Years)" }),
                  /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-emerald-200/70 text-emerald-900 font-bold px-2 py-0.5 rounded-full", children: "Top Tenure" })
                ] }),
                /* @__PURE__ */ jsxs("ul", { className: "text-xs text-gray-700 space-y-2", children: [
                  /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2 font-semibold", children: [
                    /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-600 shrink-0" }),
                    /* @__PURE__ */ jsx("span", { children: "City Bank (American Express, Visa, Master)" })
                  ] }),
                  /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2 font-semibold", children: [
                    /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-600 shrink-0" }),
                    /* @__PURE__ */ jsx("span", { children: "Eastern Bank Limited (EBL Credit Cards)" })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-5 rounded-2xl bg-blue-50/50 border border-blue-200/70 space-y-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs font-black text-blue-900 uppercase tracking-wider", children: "Up to 24 Months (2 Years)" }),
                  /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-blue-200/70 text-blue-900 font-bold px-2 py-0.5 rounded-full", children: "Most Popular" })
                ] }),
                /* @__PURE__ */ jsx("ul", { className: "text-xs text-gray-700 space-y-1.5", children: ["BRAC Bank", "Standard Chartered (SCB)", "Mutual Trust Bank (MTB)", "Prime Bank", "Dhaka Bank", "Southeast Bank", "LankaBangla Finance"].map((b, i) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5 text-blue-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { children: b })
                ] }, i)) })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-5 rounded-2xl bg-purple-50/50 border border-purple-200/70 space-y-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs font-black text-purple-900 uppercase tracking-wider", children: "Up to 12 - 18 Months" }),
                  /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-purple-200/70 text-purple-900 font-bold px-2 py-0.5 rounded-full", children: "Standard" })
                ] }),
                /* @__PURE__ */ jsx("ul", { className: "text-xs text-gray-700 space-y-1.5", children: ["Dutch-Bangla Bank (DBBL Nexus/Visa)", "UCB (Up to 18M)", "Bank Asia", "NCC Bank", "Jamuna Bank", "Premier Bank", "Trust Bank", "Midland Bank"].map((b, i) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3.5 h-3.5 text-purple-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { children: b })
                ] }, i)) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-4", children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-base font-black text-gray-900 flex items-center gap-2 mb-2", children: [
              /* @__PURE__ */ jsx(HelpCircle, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: "Frequently Asked Questions About EMI" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100", children: EMI_FAQS.map((faq, idx) => {
              const isOpen = openEmiFaq === idx;
              return /* @__PURE__ */ jsxs("div", { className: "py-3.5", children: [
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setOpenEmiFaq(isOpen ? null : idx),
                    className: "w-full text-left flex items-center justify-between gap-3 text-xs sm:text-sm font-bold text-gray-800 hover:text-[#EF4A23] transition",
                    children: [
                      /* @__PURE__ */ jsx("span", { children: faq.q }),
                      /* @__PURE__ */ jsx(ChevronDown, { className: `w-4 h-4 text-gray-400 shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180 text-[#EF4A23]" : ""}` })
                    ]
                  }
                ),
                isOpen && /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-600 mt-2 leading-relaxed pl-1 animate-fade-in", children: faq.a })
              ] }, idx);
            }) })
          ] })
        ] }),
        (page.page_type === "contact_us" || page.page_type === "service_complain") && /* @__PURE__ */ jsx("div", { className: "space-y-8", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-5", children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
              page.page_type === "service_complain" ? /* @__PURE__ */ jsx(Wrench, { className: "w-5 h-5 text-[#EF4A23]" }) : /* @__PURE__ */ jsx(Send, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: page.page_type === "service_complain" ? "Submit RMA Service & Repair Complaint" : "Send an Inquiry / Feedback" })
            ] }),
            /* @__PURE__ */ jsxs("form", { onSubmit: handleInquirySubmit, className: "space-y-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Your Name *" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "text",
                      required: true,
                      value: inquiryData.name,
                      onChange: (e) => setInquiryData("name", e.target.value),
                      placeholder: "e.g. Asif Mahmud",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Phone Number *" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "tel",
                      required: true,
                      value: inquiryData.phone,
                      onChange: (e) => setInquiryData("phone", e.target.value),
                      placeholder: "01XXXXXXXXX",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Email Address" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "email",
                      value: inquiryData.email,
                      onChange: (e) => setInquiryData("email", e.target.value),
                      placeholder: "your@email.com",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Order / Invoice No (Optional)" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "text",
                      value: inquiryData.order_number,
                      onChange: (e) => setInquiryData("order_number", e.target.value),
                      placeholder: "e.g. ST-261008-8472",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3 font-mono"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Subject *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    required: true,
                    value: inquiryData.subject,
                    onChange: (e) => setInquiryData("subject", e.target.value),
                    placeholder: "e.g. Warranty claim for GPU / Query regarding bulk purchase",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Message / Complaint Details *" }),
                /* @__PURE__ */ jsx(
                  "textarea",
                  {
                    rows: "5",
                    required: true,
                    value: inquiryData.message,
                    onChange: (e) => setInquiryData("message", e.target.value),
                    placeholder: "Please describe your technical issue, hardware serial number, or feedback...",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] p-3 leading-relaxed"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "submit",
                  disabled: inquiryProcessing,
                  className: "w-full py-3 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center justify-center gap-2 disabled:opacity-50",
                  children: [
                    /* @__PURE__ */ jsx(Send, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsx("span", { children: inquiryProcessing ? "Submitting..." : "Send Message to Tech Shoppers" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "lg:col-span-5 space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] text-white p-6 rounded-3xl border border-gray-800 shadow-xl space-y-4", children: [
              /* @__PURE__ */ jsxs("h4", { className: "text-sm font-bold text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Direct Customer Hotline" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-4 bg-white/5 rounded-2xl border border-white/10", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: "General Hotline (10am - 7pm)" }),
                /* @__PURE__ */ jsx("span", { className: "text-2xl font-black text-[#EF4A23] block mt-0.5", children: "16793" }),
                /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-300 mt-1 block", children: "Alternate: 09678002003" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "text-xs text-gray-300 space-y-2", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4 text-[#EF4A23] shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("span", { children: "info@techshoppers.com • support@techshoppers.com" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-[#EF4A23] shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("span", { children: "28 Kazi Nazrul Islam Avenue, Banglamotor, Dhaka 1000" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-3xl border border-gray-200/90 shadow-sm space-y-3 text-xs", children: [
              /* @__PURE__ */ jsxs("h4", { className: "font-bold text-gray-900 flex items-center gap-2 text-xs", children: [
                /* @__PURE__ */ jsx(Building2, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Major Superstore Outlets" })
              ] }),
              /* @__PURE__ */ jsxs("ul", { className: "space-y-2 text-gray-600 divide-y divide-gray-100", children: [
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "IDB Bhaban:" }),
                  " BCS Computer City, Agargaon, Dhaka"
                ] }),
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "Multiplan Center:" }),
                  " New Elephant Road, Dhaka"
                ] }),
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "Uttara Branch:" }),
                  " Sector 3, RAK Tower, Jashimuddin Road"
                ] }),
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "Agrabad Chattogram:" }),
                  " Yunusco City Center, CDA Avenue"
                ] })
              ] })
            ] })
          ] })
        ] }) }),
        page.content && /* @__PURE__ */ jsx("div", { className: "bg-white p-6 sm:p-10 rounded-3xl border border-gray-200/90 shadow-sm", children: /* @__PURE__ */ jsx(
          "div",
          {
            className: "prose prose-sm sm:prose max-w-none text-gray-700 leading-relaxed space-y-4",
            dangerouslySetInnerHTML: { __html: page.content }
          }
        ) })
      ] })
    }
  );
}
export {
  Page as default
};
