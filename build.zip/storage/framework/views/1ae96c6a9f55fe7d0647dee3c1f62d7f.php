<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php
            $siteName = \App\Models\Setting::get('site_name', config('app.name', 'Tech Shoppers'));
            $siteFavicon = \App\Models\Setting::get('site_favicon');
            $googleVerification = \App\Models\Setting::get('seo_google_verification');
            $bingVerification = \App\Models\Setting::get('seo_bing_verification');
            $pinterestVerification = \App\Models\Setting::get('seo_pinterest_verification');
            $yandexVerification = \App\Models\Setting::get('seo_yandex_verification');
            $ga4Id = \App\Models\Setting::get('seo_ga4_id');
            $gtmId = \App\Models\Setting::get('seo_gtm_id');
            $fbPixelId = \App\Models\Setting::get('seo_fb_pixel_id');
            $customHeadScripts = \App\Models\Setting::get('seo_custom_head_scripts');
            $customBodyScripts = \App\Models\Setting::get('seo_custom_body_scripts');
        ?>

        <title inertia><?php echo e($siteName); ?></title>

        <?php if($siteFavicon): ?>
        <link rel="icon" href="<?php echo e($siteFavicon); ?>">
        <?php endif; ?>

        
        <?php if($googleVerification): ?>
        <meta name="google-site-verification" content="<?php echo e($googleVerification); ?>">
        <?php endif; ?>
        <?php if($bingVerification): ?>
        <meta name="msvalidate.01" content="<?php echo e($bingVerification); ?>">
        <?php endif; ?>
        <?php if($pinterestVerification): ?>
        <meta name="p:domain_verify" content="<?php echo e($pinterestVerification); ?>">
        <?php endif; ?>
        <?php if($yandexVerification): ?>
        <meta name="yandex-verification" content="<?php echo e($yandexVerification); ?>">
        <?php endif; ?>

        
        <?php if($gtmId): ?>
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','<?php echo e($gtmId); ?>');</script>
        <?php endif; ?>

        
        <?php if($ga4Id): ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($ga4Id); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '<?php echo e($ga4Id); ?>');
        </script>
        <?php endif; ?>

        
        <?php if($fbPixelId): ?>
        <script>
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '<?php echo e($fbPixelId); ?>');
            fbq('track', 'PageView');
        </script>
        <noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=<?php echo e($fbPixelId); ?>&ev=PageView&noscript=1"
        /></noscript>
        <?php endif; ?>

        
        <?php if($customHeadScripts): ?>
        <?php echo $customHeadScripts; ?>

        <?php endif; ?>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.jsx', "resources/js/Pages/{$page['component']}.jsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        
        <?php if($gtmId): ?>
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e($gtmId); ?>"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <?php endif; ?>

        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page, JSON_HEX_TAG); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>

        
        <?php if($customBodyScripts): ?>
        <?php echo $customBodyScripts; ?>

        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\star\resources\views/app.blade.php ENDPATH**/ ?>