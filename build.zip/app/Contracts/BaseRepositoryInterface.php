<?php

namespace App\Contracts;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\LengthAwarePaginator;

interface BaseRepositoryInterface
{
    public function all(array $columns = ['*'], array $relations = []): Collection;
    public function paginate(int $perPage = 15, array $columns = ['*'], array $relations = []): LengthAwarePaginator;
    public function find(int $id, array $columns = ['*'], array $relations = []): ?Model;
    public function findBySlug(string $slug, array $columns = ['*'], array $relations = []): ?Model;
    public function create(array $attributes): Model;
    public function update(int $id, array $attributes): bool;
    public function delete(int $id): bool;
}
