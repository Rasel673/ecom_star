import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { Link, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { FileText, Plus, Search, ExternalLink, Edit, Trash2, Wrench, PhoneCall, Truck, Calculator } from "lucide-react";
function Index({ pages, filters = {} }) {
  const [search, setSearch] = useState(filters.search || "");
  const [pageType, setPageType] = useState(filters.page_type || "");
  const handleFilter = (e) => {
    e.preventDefault();
    router.get(
      route("admin.pages.index"),
      {
        search: search || void 0,
        page_type: pageType || void 0
      },
      { preserveState: true }
    );
  };
  const handleDelete = (id, title) => {
    if (confirm(`Are you sure you want to delete '${title}'?`)) {
      router.delete(route("admin.pages.destroy", id), { preserveScroll: true });
    }
  };
  const handleToggleStatus = (id) => {
    router.patch(route("admin.pages.toggle-status", id), {}, { preserveScroll: true });
  };
  const getPageTypeBadge = (type) => {
    switch (type) {
      case "emi_calculator":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200", children: [
          /* @__PURE__ */ jsx(Calculator, { className: "w-3 h-3 text-amber-500" }),
          "EMI Calculator"
        ] });
      case "order_tracking":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200", children: [
          /* @__PURE__ */ jsx(Truck, { className: "w-3 h-3 text-blue-500" }),
          "Order Tracker"
        ] });
      case "contact_us":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200", children: [
          /* @__PURE__ */ jsx(PhoneCall, { className: "w-3 h-3 text-emerald-500" }),
          "Contact Us"
        ] });
      case "service_complain":
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200", children: [
          /* @__PURE__ */ jsx(Wrench, { className: "w-3 h-3 text-purple-500" }),
          "Service & RMA"
        ] });
      default:
        return /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-gray-100 text-gray-700 border border-gray-200", children: [
          /* @__PURE__ */ jsx(FileText, { className: "w-3 h-3 text-gray-400" }),
          "Standard Article"
        ] });
    }
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "CMS & Dynamic Pages", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-xl font-black text-gray-900 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(FileText, { className: "w-6 h-6 text-[#EF4A23]" }),
          /* @__PURE__ */ jsx("span", { children: "Dynamic Pages & CMS" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Create and manage dynamic store content, interactive calculators, tracking pages, and customer policies." })
      ] }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("admin.pages.create"),
          className: "px-4 py-2 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold rounded-xl transition shadow-md flex items-center gap-2",
          children: [
            /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Create New Page" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white p-4 rounded-2xl border border-gray-200 shadow-sm mb-6", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleFilter, className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative flex-1 min-w-[200px]", children: [
        /* @__PURE__ */ jsx(Search, { className: "w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            value: search,
            onChange: (e) => setSearch(e.target.value),
            placeholder: "Search by title, slug, or subtitle...",
            className: "w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-gray-200 focus:border-[#EF4A23] focus:ring-[#EF4A23]"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs(
        "select",
        {
          value: pageType,
          onChange: (e) => setPageType(e.target.value),
          className: "text-xs rounded-xl border border-gray-200 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3",
          children: [
            /* @__PURE__ */ jsx("option", { value: "", children: "All Page Types" }),
            /* @__PURE__ */ jsx("option", { value: "standard", children: "Standard Article / Policy" }),
            /* @__PURE__ */ jsx("option", { value: "emi_calculator", children: "Interactive EMI Calculator" }),
            /* @__PURE__ */ jsx("option", { value: "order_tracking", children: "Live Order Tracking" }),
            /* @__PURE__ */ jsx("option", { value: "contact_us", children: "Contact Us & Outlets" }),
            /* @__PURE__ */ jsx("option", { value: "service_complain", children: "Online Service & Complain" })
          ]
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          type: "submit",
          className: "px-4 py-2 bg-[#081621] text-white text-xs font-bold rounded-xl hover:bg-gray-800 transition",
          children: "Filter"
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs text-gray-600", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 text-gray-700 uppercase font-semibold border-b text-[11px] tracking-wider", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Title & Subtitle" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Public URL / Slug" }),
          /* @__PURE__ */ jsx("th", { className: "p-4", children: "Type / Functionality" }),
          /* @__PURE__ */ jsx("th", { className: "p-4 text-center", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "p-4 text-right", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: pages.data && pages.data.length > 0 ? pages.data.map((page) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/70 transition", children: [
          /* @__PURE__ */ jsxs("td", { className: "p-4", children: [
            /* @__PURE__ */ jsx("div", { className: "font-bold text-gray-900 text-sm", children: page.title }),
            page.subtitle && /* @__PURE__ */ jsx("div", { className: "text-[11px] text-gray-400 mt-0.5 line-clamp-1", children: page.subtitle })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-4", children: /* @__PURE__ */ jsxs("div", { className: "font-mono text-xs text-gray-700 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "/page/" }),
            /* @__PURE__ */ jsx("span", { className: "font-bold text-[#081621]", children: page.slug })
          ] }) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 whitespace-nowrap", children: getPageTypeBadge(page.page_type) }),
          /* @__PURE__ */ jsx("td", { className: "p-4 text-center whitespace-nowrap", children: /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => handleToggleStatus(page.id),
              className: `px-2.5 py-0.5 rounded-full text-[11px] font-bold border transition ${page.is_active ? "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100" : "bg-gray-100 text-gray-500 border-gray-200 hover:bg-gray-200"}`,
              children: page.is_active ? "Published" : "Draft"
            }
          ) }),
          /* @__PURE__ */ jsxs("td", { className: "p-4 text-right whitespace-nowrap space-x-2", children: [
            page.is_active && /* @__PURE__ */ jsx(
              "a",
              {
                href: route("page.show", page.slug),
                target: "_blank",
                rel: "noreferrer",
                className: "p-1.5 text-gray-400 hover:text-blue-600 rounded-lg transition inline-block",
                title: "View Public Page",
                children: /* @__PURE__ */ jsx(ExternalLink, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsx(
              Link,
              {
                href: route("admin.pages.edit", page.id),
                className: "p-1.5 text-gray-400 hover:text-amber-600 rounded-lg transition inline-block",
                title: "Edit Page",
                children: /* @__PURE__ */ jsx(Edit, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => handleDelete(page.id, page.title),
                className: "p-1.5 text-gray-400 hover:text-rose-600 rounded-lg transition inline-block",
                title: "Delete Page",
                children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }, page.id)) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "5", className: "p-8 text-center text-gray-400", children: "No dynamic pages found. Click 'Create New Page' above to add one." }) }) })
      ] }) }),
      pages.links && pages.links.length > 3 && /* @__PURE__ */ jsxs("div", { className: "p-4 border-t border-gray-100 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-gray-500", children: [
          "Showing ",
          pages.from || 0,
          " to ",
          pages.to || 0,
          " of ",
          pages.total,
          " pages"
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1", children: pages.links.map((link, idx) => /* @__PURE__ */ jsx(
          Link,
          {
            href: link.url || "#",
            dangerouslySetInnerHTML: { __html: link.label },
            className: `px-3 py-1 text-xs rounded-lg border transition ${link.active ? "bg-[#EF4A23] text-white border-[#EF4A23]" : !link.url ? "text-gray-300 border-gray-200 cursor-not-allowed" : "text-gray-600 border-gray-200 hover:bg-gray-50"}`
          },
          idx
        )) })
      ] })
    ] })
  ] });
}
export {
  Index as default
};
