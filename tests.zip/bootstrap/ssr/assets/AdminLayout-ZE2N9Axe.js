import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { usePage, Link } from "@inertiajs/react";
import { LayoutDashboard, FolderTree, Package, Tag, ShoppingCart, Clock, MessageSquare, Image, FileText, CheckCircle2, AlertCircle, X, ExternalLink, LogOut, Menu } from "lucide-react";
function AdminLayout({ children, title }) {
  const { auth, flash } = usePage().props;
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [alertMessage, setAlertMessage] = useState(null);
  const [alertType, setAlertType] = useState(null);
  useEffect(() => {
    if (flash?.success) {
      setAlertMessage(flash.success);
      setAlertType("success");
      const timer = setTimeout(() => setAlertMessage(null), 5e3);
      return () => clearTimeout(timer);
    }
    if (flash?.error) {
      setAlertMessage(flash.error);
      setAlertType("error");
      const timer = setTimeout(() => setAlertMessage(null), 5e3);
      return () => clearTimeout(timer);
    }
  }, [flash]);
  const navItems = [
    { label: "Dashboard", href: route("admin.dashboard"), icon: LayoutDashboard, routeName: "admin.dashboard" },
    { label: "Categories", href: route("admin.categories.index"), icon: FolderTree, routeName: "admin.categories.*" },
    { label: "Products", href: route("admin.products.index"), icon: Package, routeName: "admin.products.*" },
    { label: "Brands", href: route("admin.brands.index"), icon: Tag, routeName: "admin.brands.*" },
    { label: "Orders", href: route("admin.orders.index"), icon: ShoppingCart, routeName: "admin.orders.*" },
    { label: "Pre-Orders", href: route("admin.preorders.index"), icon: Clock, routeName: "admin.preorders.*" },
    { label: "Customer Messages", href: route("admin.messages.index"), icon: MessageSquare, routeName: "admin.messages.*" },
    { label: "Banners & Sliders", href: route("admin.banners.index"), icon: Image, routeName: "admin.banners.*" },
    { label: "Pages & CMS", href: route("admin.pages.index"), icon: FileText, routeName: "admin.pages.*" }
  ];
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-[#F8FAFC] flex text-[#1E293B]", children: [
    alertMessage && /* @__PURE__ */ jsx("div", { className: "fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5", children: /* @__PURE__ */ jsxs("div", { className: `flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl text-xs font-semibold text-white ${alertType === "success" ? "bg-emerald-600" : "bg-rose-600"}`, children: [
      alertType === "success" ? /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4 shrink-0" }) : /* @__PURE__ */ jsx(AlertCircle, { className: "w-4 h-4 shrink-0" }),
      /* @__PURE__ */ jsx("span", { children: alertMessage }),
      /* @__PURE__ */ jsx("button", { onClick: () => setAlertMessage(null), className: "ml-2 hover:opacity-75", children: /* @__PURE__ */ jsx(X, { className: "w-3.5 h-3.5" }) })
    ] }) }),
    /* @__PURE__ */ jsxs("aside", { className: `fixed inset-y-0 left-0 z-50 w-64 bg-[#081621] text-white flex flex-col justify-between transition-transform duration-300 lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("div", { className: "h-16 flex items-center justify-between px-6 border-b border-gray-800", children: [
          /* @__PURE__ */ jsxs(Link, { href: route("admin.dashboard"), className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "text-xl font-black tracking-tight text-white", children: "STAR" }),
            /* @__PURE__ */ jsx("span", { className: "text-xl font-black tracking-tight text-[#EF4A23]", children: "TECH" }),
            /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-orange-950 text-orange-400 font-bold px-1.5 py-0.5 rounded border border-orange-800", children: "ADMIN" })
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setSidebarOpen(false),
              className: "lg:hidden text-gray-400 hover:text-white",
              children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("nav", { className: "p-4 space-y-1.5 text-xs font-semibold", children: navItems.map((item, idx) => {
          const Icon = item.icon;
          const isActive = route().current(item.routeName);
          return /* @__PURE__ */ jsxs(
            Link,
            {
              href: item.href,
              className: `flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition ${isActive ? "bg-[#EF4A23] text-white shadow-md" : "text-gray-300 hover:bg-gray-800/60 hover:text-white"}`,
              children: [
                /* @__PURE__ */ jsx(Icon, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: item.label })
              ]
            },
            idx
          );
        }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "p-4 border-t border-gray-800 space-y-2 text-xs", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: "/",
            target: "_blank",
            className: "flex items-center justify-between px-3 py-2 text-gray-400 hover:text-white hover:bg-gray-800/60 rounded-xl transition",
            children: [
              /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(ExternalLink, { className: "w-4 h-4 text-orange-400" }),
                /* @__PURE__ */ jsx("span", { children: "View Storefront" })
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-[10px] bg-gray-800 px-1.5 py-0.5 rounded text-gray-400", children: "Live" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("logout"),
            method: "post",
            as: "button",
            className: "w-full flex items-center gap-2 px-3 py-2 text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 rounded-xl transition font-semibold",
            children: [
              /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: "Sign Out" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex-1 lg:pl-64 flex flex-col min-h-screen", children: [
      /* @__PURE__ */ jsxs("header", { className: "h-16 bg-white border-b border-gray-200 px-6 flex items-center justify-between sticky top-0 z-30", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setSidebarOpen(true),
              className: "lg:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-lg",
              children: /* @__PURE__ */ jsx(Menu, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900", children: title || "Admin Control Panel" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
          /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-orange-100 text-[#EF4A23] font-black flex items-center justify-center", children: auth.user?.name?.charAt(0) || "A" }),
          /* @__PURE__ */ jsxs("div", { className: "hidden sm:block text-left", children: [
            /* @__PURE__ */ jsx("span", { className: "block font-bold text-gray-900 leading-none", children: auth.user?.name }),
            /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-500", children: "Administrator" })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsx("main", { className: "flex-1 p-6 md:p-8", children })
    ] })
  ] });
}
export {
  AdminLayout as A
};
