import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { Link, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { Search, Plus, ExternalLink, Edit, Trash2 } from "lucide-react";
function Index({ products, filters = {} }) {
  const [searchTerm, setSearchTerm] = useState(filters.search || "");
  const handleSearch = (e) => {
    e.preventDefault();
    router.get(route("admin.products.index"), { search: searchTerm }, { preserveState: true });
  };
  const handleDelete = (id, name) => {
    if (confirm(`Delete product "${name}"?`)) {
      router.delete(route("admin.products.destroy", id));
    }
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "Manage Products", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-xl font-black text-gray-900", children: "Products Inventory" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Catalog of tech products, pricing, and stock" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 w-full sm:w-auto", children: [
        /* @__PURE__ */ jsxs("form", { onSubmit: handleSearch, className: "relative flex-1 sm:w-64", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              placeholder: "Search products...",
              value: searchTerm,
              onChange: (e) => setSearchTerm(e.target.value),
              className: "w-full text-xs pl-3 pr-8 py-2 rounded-xl border border-gray-300 focus:border-[#EF4A23]"
            }
          ),
          /* @__PURE__ */ jsx("button", { type: "submit", className: "absolute right-2.5 top-2.5 text-gray-400", children: /* @__PURE__ */ jsx(Search, { className: "w-3.5 h-3.5" }) })
        ] }),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("admin.products.create"),
            className: "inline-flex items-center gap-1.5 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2.5 px-4 rounded-xl transition shadow-sm shrink-0",
            children: [
              /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: "Add Product" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200/80 shadow-sm overflow-hidden", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
      /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 border-b border-gray-200 text-gray-500 font-semibold uppercase", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Product" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Category" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Brand" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-right", children: "Price (৳)" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Stock" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Featured" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: products.data.map((product) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/50", children: [
        /* @__PURE__ */ jsx("td", { className: "p-3.5", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              src: product.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
              alt: product.name,
              className: "w-10 h-10 object-contain rounded-lg border p-0.5 bg-white shrink-0"
            }
          ),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 line-clamp-1", children: product.name }),
            /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-400", children: product.model || product.sku })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-gray-600 font-medium", children: product.category?.name || "—" }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-gray-600 font-medium", children: product.brand?.name || "—" }),
        /* @__PURE__ */ jsxs("td", { className: "p-3.5 text-right", children: [
          /* @__PURE__ */ jsxs("span", { className: "font-black text-[#EF4A23] block", children: [
            "৳",
            Number(product.special_price || product.regular_price).toLocaleString()
          ] }),
          product.special_price && /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-gray-400 line-through", children: [
            "৳",
            Number(product.regular_price).toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsxs("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold ${product.stock_status === "in_stock" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`, children: [
          product.quantity,
          " In Stock"
        ] }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: product.is_featured ? /* @__PURE__ */ jsx("span", { className: "text-orange-600 font-bold", children: "Yes" }) : /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "No" }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("product.show", product.slug),
              target: "_blank",
              className: "p-1 text-gray-400 hover:text-gray-700",
              title: "View in store",
              children: /* @__PURE__ */ jsx(ExternalLink, { className: "w-3.5 h-3.5" })
            }
          ),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("admin.products.edit", product.id),
              className: "p-1 text-gray-500 hover:text-blue-600",
              title: "Edit",
              children: /* @__PURE__ */ jsx(Edit, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => handleDelete(product.id, product.name),
              className: "p-1 text-gray-500 hover:text-rose-600",
              title: "Delete",
              children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
            }
          )
        ] }) })
      ] }, product.id)) })
    ] }) }),
    products.links && products.links.length > 3 && /* @__PURE__ */ jsx("div", { className: "mt-6 flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm", children: products.links.map((link, idx) => /* @__PURE__ */ jsx(
      Link,
      {
        href: link.url || "#",
        dangerouslySetInnerHTML: { __html: link.label },
        className: `px-3 py-1.5 text-xs rounded-lg transition font-medium ${link.active ? "bg-[#EF4A23] text-white font-bold" : "text-gray-700 hover:bg-gray-100"}`
      },
      idx
    )) }) })
  ] });
}
export {
  Index as default
};
