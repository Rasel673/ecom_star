import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-VbDbxh3C.js";
import { ShoppingBag, Minus, Plus, Trash2, Tag, ArrowRight } from "lucide-react";
function Cart({ cartItems, cart = [], subtotal = 0, discount = 0, total = 0, coupon = null }) {
  const [couponCode, setCouponCode] = useState("");
  const items = cartItems || (Array.isArray(cart) ? cart : cart?.items || []);
  const handleUpdateQuantity = (productId, newQty) => {
    if (newQty < 1) return;
    router.post(route("cart.update"), {
      product_id: productId,
      quantity: newQty
    }, { preserveScroll: true });
  };
  const handleRemoveItem = (productId) => {
    router.delete(route("cart.remove", productId), { preserveScroll: true });
  };
  const handleApplyCoupon = (e) => {
    e.preventDefault();
    if (couponCode.trim()) {
      router.post(route("cart.coupon"), { code: couponCode }, {
        preserveScroll: true,
        onSuccess: () => setCouponCode("")
      });
    }
  };
  const handleRemoveCoupon = () => {
    router.delete(route("cart.coupon.remove"), { preserveScroll: true });
  };
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: "Shopping Cart", children: [
    /* @__PURE__ */ jsxs("h1", { className: "text-xl sm:text-2xl font-black text-gray-900 mb-4 sm:mb-6 flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(ShoppingBag, { className: "w-5 h-5 sm:w-6 sm:h-6 text-[#EF4A23]" }),
      /* @__PURE__ */ jsxs("span", { children: [
        "Shopping Cart (",
        items.length,
        ")"
      ] })
    ] }),
    items.length > 0 ? /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-2 space-y-4", children: [
        /* @__PURE__ */ jsx("div", { className: "hidden md:block bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 border-b border-gray-200 text-gray-500 uppercase font-semibold", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "p-4", children: "Product" }),
            /* @__PURE__ */ jsx("th", { className: "p-4 text-center", children: "Unit Price" }),
            /* @__PURE__ */ jsx("th", { className: "p-4 text-center", children: "Quantity" }),
            /* @__PURE__ */ jsx("th", { className: "p-4 text-right", children: "Total" }),
            /* @__PURE__ */ jsx("th", { className: "p-4 text-center", children: "Action" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: items.map((item) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/50", children: [
            /* @__PURE__ */ jsx("td", { className: "p-4", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                  alt: item.name,
                  className: "w-14 h-14 object-contain rounded-lg border border-gray-100 p-1 bg-white shrink-0"
                }
              ),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("product.show", item.slug),
                    className: "font-bold text-gray-900 hover:text-[#EF4A23] transition line-clamp-1",
                    children: item.name
                  }
                ),
                item.model && /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: item.model })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxs("td", { className: "p-4 text-center font-bold text-gray-800", children: [
              "৳",
              Number(item.price).toLocaleString()
            ] }),
            /* @__PURE__ */ jsx("td", { className: "p-4 text-center", children: /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center border border-gray-300 rounded-lg overflow-hidden bg-gray-50", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleUpdateQuantity(item.id, item.quantity - 1),
                  className: "p-1.5 hover:bg-gray-200 text-gray-600",
                  children: /* @__PURE__ */ jsx(Minus, { className: "w-3 h-3" })
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "px-3 font-bold", children: item.quantity }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleUpdateQuantity(item.id, item.quantity + 1),
                  className: "p-1.5 hover:bg-gray-200 text-gray-600",
                  children: /* @__PURE__ */ jsx(Plus, { className: "w-3 h-3" })
                }
              )
            ] }) }),
            /* @__PURE__ */ jsxs("td", { className: "p-4 text-right font-bold text-[#EF4A23]", children: [
              "৳",
              Number(item.price * item.quantity).toLocaleString()
            ] }),
            /* @__PURE__ */ jsx("td", { className: "p-4 text-center", children: /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveItem(item.id),
                className: "text-gray-400 hover:text-rose-600 p-1 rounded-md transition",
                title: "Remove from Cart",
                children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
              }
            ) })
          ] }, item.id)) })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "md:hidden space-y-3", children: items.map((item) => /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-xl border border-gray-200 p-3.5 shadow-sm space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsx(
              "img",
              {
                src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                alt: item.name,
                className: "w-16 h-16 object-contain rounded-lg border border-gray-100 p-1 bg-white shrink-0"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("product.show", item.slug),
                  className: "text-xs font-bold text-gray-900 hover:text-[#EF4A23] line-clamp-2 leading-snug",
                  children: item.name
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block mt-0.5", children: item.model || "" }),
              /* @__PURE__ */ jsxs("span", { className: "text-xs font-bold text-[#EF4A23] mt-1 block", children: [
                "৳",
                Number(item.price).toLocaleString()
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveItem(item.id),
                className: "p-1.5 text-gray-400 hover:text-rose-600 transition shrink-0",
                title: "Remove",
                children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-gray-100 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center border border-gray-300 rounded-lg overflow-hidden bg-gray-50", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleUpdateQuantity(item.id, item.quantity - 1),
                  className: "p-2 hover:bg-gray-200 text-gray-600",
                  children: /* @__PURE__ */ jsx(Minus, { className: "w-3.5 h-3.5" })
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "px-3 font-bold text-xs", children: item.quantity }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleUpdateQuantity(item.id, item.quantity + 1),
                  className: "p-2 hover:bg-gray-200 text-gray-600",
                  children: /* @__PURE__ */ jsx(Plus, { className: "w-3.5 h-3.5" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[10px] text-gray-400 block", children: "Subtotal" }),
              /* @__PURE__ */ jsxs("span", { className: "font-black text-[#EF4A23] text-sm", children: [
                "৳",
                Number(item.price * item.quantity).toLocaleString()
              ] })
            ] })
          ] })
        ] }, item.id)) }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 p-4 sm:p-5 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs font-bold text-gray-800", children: [
            /* @__PURE__ */ jsx(Tag, { className: "w-4 h-4 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("span", { children: "Have a Voucher or Promo Code?" })
          ] }),
          coupon ? /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between sm:justify-start gap-3", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-xs bg-emerald-50 text-emerald-700 px-3 py-1 rounded-lg border border-emerald-200 font-bold", children: [
              "Applied: ",
              coupon.code,
              " (-৳",
              discount.toLocaleString(),
              ")"
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: handleRemoveCoupon,
                className: "text-xs text-rose-600 hover:underline font-semibold",
                children: "Remove"
              }
            )
          ] }) : /* @__PURE__ */ jsxs("form", { onSubmit: handleApplyCoupon, className: "flex items-center gap-2 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                placeholder: "STARTECH1000",
                value: couponCode,
                onChange: (e) => setCouponCode(e.target.value),
                className: "text-xs uppercase p-2 border border-gray-300 rounded-lg focus:border-[#EF4A23] flex-1 sm:w-36"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "submit",
                className: "bg-[#081621] hover:bg-[#EF4A23] text-white text-xs font-bold px-4 py-2 rounded-lg transition",
                children: "Apply"
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-1", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-5 sm:p-6 space-y-4 sticky top-20", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-gray-900 border-b pb-3", children: "Order Summary" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-xs text-gray-600", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Subtotal" }),
            /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-900", children: [
              "৳",
              subtotal.toLocaleString()
            ] })
          ] }),
          discount > 0 && /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-emerald-600 font-bold", children: [
            /* @__PURE__ */ jsx("span", { children: "Discount" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "-৳",
              discount.toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("span", { children: "Estimated Shipping" }),
            /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "Calculated at checkout" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-3 border-t flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-gray-900", children: "Total" }),
          /* @__PURE__ */ jsxs("span", { className: "text-xl font-black text-[#EF4A23]", children: [
            "৳",
            total.toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("checkout.index"),
            className: "w-full flex items-center justify-center gap-2 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-sm py-3 px-4 rounded-xl shadow-md hover:shadow-orange-500/20 transition",
            children: [
              /* @__PURE__ */ jsx("span", { children: "Proceed to Checkout" }),
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(
          Link,
          {
            href: "/",
            className: "w-full block text-center text-xs text-gray-500 hover:text-gray-900 font-semibold transition mt-2",
            children: "Continue Shopping"
          }
        )
      ] }) })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 p-8 sm:p-16 text-center shadow-sm", children: [
      /* @__PURE__ */ jsx("div", { className: "w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-orange-50 text-[#EF4A23] flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsx(ShoppingBag, { className: "w-8 h-8 sm:w-10 sm:h-10" }) }),
      /* @__PURE__ */ jsx("h3", { className: "text-lg sm:text-xl font-bold text-gray-900 mb-2", children: "Your Shopping Cart is Empty!" }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 max-w-md mx-auto mb-6", children: "Looks like you haven't added anything to your cart yet. Explore our laptops, desktop components, and gadgets!" }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/",
          className: "inline-flex items-center gap-2 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs py-3 px-6 rounded-xl shadow-md transition",
          children: [
            /* @__PURE__ */ jsx("span", { children: "Start Shopping" }),
            /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4" })
          ]
        }
      )
    ] })
  ] });
}
export {
  Cart as default
};
