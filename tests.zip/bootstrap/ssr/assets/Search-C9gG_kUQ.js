import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import "react";
import { Link } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-VbDbxh3C.js";
import { P as ProductCard } from "./ProductCard-Ck3qGjy2.js";
import { Search as Search$1 } from "lucide-react";
function Search({ query, products, seo = {} }) {
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: seo.title, description: seo.description, children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-gray-500 text-xs mb-1", children: [
        /* @__PURE__ */ jsx(Search$1, { className: "w-4 h-4 text-[#EF4A23]" }),
        /* @__PURE__ */ jsx("span", { children: "Search Results" })
      ] }),
      /* @__PURE__ */ jsx("h1", { className: "text-xl md:text-2xl font-black text-gray-900", children: query ? `Search results for "${query}"` : "All Products" }),
      /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 mt-1", children: [
        "Found ",
        products.total,
        " matching items"
      ] })
    ] }),
    products.data.length > 0 ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5", children: products.data.map((product) => /* @__PURE__ */ jsx(ProductCard, { product }, product.id)) }),
      products.links && products.links.length > 3 && /* @__PURE__ */ jsx("div", { className: "mt-8 flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 bg-white p-2 rounded-xl border border-gray-200 shadow-sm", children: products.links.map((link, idx) => /* @__PURE__ */ jsx(
        Link,
        {
          href: link.url || "#",
          dangerouslySetInnerHTML: { __html: link.label },
          className: `px-3 py-1.5 text-xs rounded-lg transition font-medium ${link.active ? "bg-[#EF4A23] text-white font-bold" : link.url ? "text-gray-700 hover:bg-gray-100" : "text-gray-300 cursor-not-allowed"}`
        },
        idx
      )) }) })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 p-16 text-center shadow-sm", children: [
      /* @__PURE__ */ jsx(Search$1, { className: "w-12 h-12 text-gray-300 mx-auto mb-3" }),
      /* @__PURE__ */ jsxs("h3", { className: "text-lg font-bold text-gray-800", children: [
        'No products found matching "',
        query,
        '"'
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Please try searching with different keywords or check spelling." })
    ] })
  ] });
}
export {
  Search as default
};
