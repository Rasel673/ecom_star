import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { useForm, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { Plus, Tag, Trash2 } from "lucide-react";
function Index({ brands }) {
  const { data, setData, post, reset, processing, errors } = useForm({
    name: "",
    slug: "",
    logo: "",
    is_featured: false,
    status: true
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("admin.brands.store"), {
      onSuccess: () => reset()
    });
  };
  const handleDelete = (id, name) => {
    if (confirm(`Delete brand "${name}"?`)) {
      router.delete(route("admin.brands.destroy", id));
    }
  };
  return /* @__PURE__ */ jsx(AdminLayout, { title: "Manage Brands", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8", children: [
    /* @__PURE__ */ jsxs("div", { className: "lg:col-span-4 bg-white rounded-2xl border border-gray-200/80 shadow-sm p-6", children: [
      /* @__PURE__ */ jsxs("h3", { className: "text-sm font-bold text-gray-900 border-b pb-3 mb-4 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4 text-[#EF4A23]" }),
        /* @__PURE__ */ jsx("span", { children: "Add New Brand" })
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Brand Name *" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              required: true,
              value: data.name,
              onChange: (e) => setData("name", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              placeholder: "e.g. Corsair"
            }
          ),
          errors.name && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Logo URL" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.logo,
              onChange: (e) => setData("logo", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              placeholder: "https://..."
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 pt-2", children: [
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.is_featured,
                onChange: (e) => setData("is_featured", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Featured" })
          ] }),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.status,
                onChange: (e) => setData("status", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Active" })
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "w-full bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold py-2.5 rounded-lg transition",
            children: processing ? "Saving..." : "Add Brand"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "lg:col-span-8 bg-white rounded-2xl border border-gray-200/80 shadow-sm overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "p-4 border-b", children: /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900", children: "Registered Brands" }) }),
      /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 border-b text-gray-500 uppercase font-semibold", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Brand" }),
          /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Slug" }),
          /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Products" }),
          /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Featured" }),
          /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Action" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: brands.data.map((brand) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/50", children: [
          /* @__PURE__ */ jsxs("td", { className: "p-3.5 font-bold text-gray-900 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Tag, { className: "w-3.5 h-3.5 text-gray-400" }),
            /* @__PURE__ */ jsx("span", { children: brand.name })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "p-3.5 text-gray-500", children: brand.slug }),
          /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center font-bold text-gray-700", children: brand.products_count }),
          /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: brand.is_featured ? /* @__PURE__ */ jsx("span", { className: "text-orange-600 font-bold", children: "Yes" }) : /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "No" }) }),
          /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => handleDelete(brand.id, brand.name),
              className: "p-1 text-gray-400 hover:text-rose-600",
              children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
            }
          ) })
        ] }, brand.id)) })
      ] })
    ] })
  ] }) });
}
export {
  Index as default
};
