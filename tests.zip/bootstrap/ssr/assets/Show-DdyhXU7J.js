import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { useForm, Link } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { ArrowLeft, Printer, PackageCheck, AlertTriangle, CheckCircle2, ShieldCheck, ShieldAlert, ShieldX, Truck, Check, Copy, Send, User, CreditCard } from "lucide-react";
function Show({ order, fraudAnalysis }) {
  const [copiedTracking, setCopiedTracking] = useState(false);
  const [printMode, setPrintMode] = useState("invoice");
  const { data: statusData, setData: setStatusData, patch: patchStatus, processing: statusProcessing } = useForm({
    order_status: order.order_status,
    payment_status: order.payment_status
  });
  const { data: fraudData, setData: setFraudData, patch: patchFraud, processing: fraudProcessing } = useForm({
    fraud_status: order.fraud_status || fraudAnalysis?.status || "safe"
  });
  const { data: courierData, setData: setCourierData, post: postCourier, processing: courierProcessing } = useForm({
    courier_name: order.courier_name || "steadfast",
    courier_tracking_id: order.courier_tracking_id || "",
    courier_collected_amount: order.courier_collected_amount !== null && order.courier_collected_amount !== void 0 ? order.courier_collected_amount : order.payment_method === "cod" ? order.total : 0
  });
  const handleUpdateStatus = (e) => {
    e.preventDefault();
    patchStatus(route("admin.orders.status", order.id));
  };
  const handleUpdateFraud = (newStatus) => {
    patchFraud(route("admin.orders.fraud", order.id), {
      data: { fraud_status: newStatus },
      preserveScroll: true
    });
  };
  const handleDispatchCourier = (e) => {
    e.preventDefault();
    postCourier(route("admin.orders.courier", order.id), {
      preserveScroll: true
    });
  };
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopiedTracking(true);
    setTimeout(() => setCopiedTracking(false), 2e3);
  };
  const handlePrintInvoice = () => {
    setPrintMode("invoice");
    setTimeout(() => window.print(), 100);
  };
  const handlePrintLabel = () => {
    setPrintMode("courier_label");
    setTimeout(() => window.print(), 100);
  };
  const getFraudBadge = (status) => {
    switch (status) {
      case "safe":
        return {
          label: "Safe Order",
          bg: "bg-emerald-50 text-emerald-700 border-emerald-200",
          icon: ShieldCheck,
          color: "#10B981"
        };
      case "review":
        return {
          label: "Review Required",
          bg: "bg-amber-50 text-amber-700 border-amber-200",
          icon: ShieldAlert,
          color: "#F59E0B"
        };
      case "high_risk":
      case "flagged":
        return {
          label: "High Risk / Suspicious",
          bg: "bg-rose-50 text-rose-700 border-rose-200",
          icon: ShieldX,
          color: "#EF4444"
        };
      default:
        return {
          label: "Unchecked",
          bg: "bg-gray-50 text-gray-700 border-gray-200",
          icon: ShieldCheck,
          color: "#6B7280"
        };
    }
  };
  const currentFraudInfo = getFraudBadge(order.fraud_status || fraudAnalysis?.status);
  const FraudBadgeIcon = currentFraudInfo.icon;
  const score = fraudAnalysis?.score ?? order.fraud_score ?? 10;
  const courierProviders = [
    { id: "steadfast", name: "Steadfast Courier", desc: "Fastest door-to-door COD network in BD" },
    { id: "pathao", name: "Pathao Courier", desc: "Same-day Dhaka & nationwide COD delivery" },
    { id: "redx", name: "RedX Logistics", desc: "Nationwide coverage with reverse logistics" },
    { id: "paperfly", name: "Paperfly Courier", desc: "Union-level doorstep delivery across BD" },
    { id: "sundarban", name: "Sundarban Courier", desc: "Traditional transport & branch collection" },
    { id: "startech_rider", name: "Star Tech Express Rider", desc: "In-house dedicated express Dhaka delivery" }
  ];
  return /* @__PURE__ */ jsxs(AdminLayout, { title: `Order: ${order.order_number}`, children: [
    /* @__PURE__ */ jsxs("div", { className: "print:hidden max-w-5xl mx-auto space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("admin.orders.index"),
            className: "inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#EF4A23] font-semibold",
            children: [
              /* @__PURE__ */ jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsx("span", { children: "Back to All Orders" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: handlePrintInvoice,
              className: "text-xs bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm",
              children: [
                /* @__PURE__ */ jsx(Printer, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: "Print Invoice" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              onClick: handlePrintLabel,
              className: "text-xs bg-[#081621] hover:bg-[#122738] text-white font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm",
              children: [
                /* @__PURE__ */ jsx(PackageCheck, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Print Courier Waybill" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 sm:p-5 border-b border-gray-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gradient-to-r from-gray-50 to-white", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: `p-2.5 rounded-xl border ${currentFraudInfo.bg}`, children: /* @__PURE__ */ jsx(FraudBadgeIcon, { className: "w-5 h-5" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("h2", { className: "text-sm font-black text-gray-900 uppercase tracking-wide", children: "Automated Fraud Detection & Customer Risk Assessment" }),
                /* @__PURE__ */ jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[11px] font-black border uppercase tracking-wider ${currentFraudInfo.bg}`, children: currentFraudInfo.label })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Analyzed by BD Mobile format validator, past order velocity, cancellation rate & COD risk thresholds" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 bg-gray-50 px-4 py-2 rounded-xl border border-gray-200", children: [
            /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
              /* @__PURE__ */ jsx("span", { className: "block text-[10px] uppercase font-bold text-gray-400", children: "Risk Score" }),
              /* @__PURE__ */ jsxs("span", { className: `text-base font-black ${score >= 60 ? "text-red-600" : score >= 35 ? "text-amber-600" : "text-emerald-600"}`, children: [
                score,
                " / 100"
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "w-16 bg-gray-200 rounded-full h-2.5 overflow-hidden", children: /* @__PURE__ */ jsx(
              "div",
              {
                className: `h-2.5 rounded-full ${score >= 60 ? "bg-red-500" : score >= 35 ? "bg-amber-500" : "bg-emerald-500"}`,
                style: { width: `${Math.min(100, Math.max(5, score))}%` }
              }
            ) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "p-5 space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: `p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${score >= 60 ? "bg-red-50 border-red-200 text-red-800" : score >= 35 ? "bg-amber-50 border-amber-200 text-amber-800" : "bg-emerald-50 border-emerald-200 text-emerald-800"}`, children: [
            /* @__PURE__ */ jsx(AlertTriangle, { className: "w-4 h-4 shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("p", { className: "font-bold", children: "Recommendation:" }),
              /* @__PURE__ */ jsx("p", { children: fraudAnalysis?.recommendation || "Review customer information carefully." })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 p-4 rounded-xl border border-gray-200/80 space-y-2", children: [
              /* @__PURE__ */ jsx("h3", { className: "font-bold text-gray-800 uppercase tracking-wide text-[11px] mb-2", children: "Customer Trust Profile" }),
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1 border-b border-gray-200", children: [
                /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "BD Phone Verification:" }),
                /* @__PURE__ */ jsx("span", { className: `font-bold ${fraudAnalysis?.is_valid_phone ? "text-emerald-600" : "text-red-600"}`, children: fraudAnalysis?.is_valid_phone ? "✓ Valid Bangladeshi Mobile" : "✗ Invalid Mobile Format" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1 border-b border-gray-200", children: [
                /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "Total Past Orders (Same Phone/Email):" }),
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-800", children: [
                  fraudAnalysis?.customer_history?.total_orders ?? 0,
                  " orders"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1 border-b border-gray-200", children: [
                /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "Delivered Orders:" }),
                /* @__PURE__ */ jsx("span", { className: "font-bold text-emerald-600", children: fraudAnalysis?.customer_history?.delivered_orders ?? 0 })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1 border-b border-gray-200", children: [
                /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "Past Cancellation Rate:" }),
                /* @__PURE__ */ jsxs("span", { className: `font-bold ${(fraudAnalysis?.customer_history?.cancellation_rate || 0) > 40 ? "text-red-600" : "text-gray-800"}`, children: [
                  fraudAnalysis?.customer_history?.cancellation_rate ?? 0,
                  "% (",
                  fraudAnalysis?.customer_history?.cancelled_orders ?? 0,
                  " cancelled)"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1", children: [
                /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "Payment Risk Level:" }),
                /* @__PURE__ */ jsx("span", { className: "font-bold uppercase text-gray-800", children: order.payment_method === "cod" ? `COD (৳${Number(order.total).toLocaleString()})` : "Online Prepaid" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 p-4 rounded-xl border border-gray-200/80 space-y-2", children: [
              /* @__PURE__ */ jsxs("h3", { className: "font-bold text-gray-800 uppercase tracking-wide text-[11px] mb-2", children: [
                "Risk Factors & Flags (",
                fraudAnalysis?.flags?.length || 0,
                ")"
              ] }),
              fraudAnalysis?.flags && fraudAnalysis.flags.length > 0 ? /* @__PURE__ */ jsx("div", { className: "space-y-1.5 max-h-48 overflow-y-auto pr-1", children: fraudAnalysis.flags.map((flag, idx) => /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2 text-rose-700 bg-rose-50/80 border border-rose-200/60 p-2 rounded-lg", children: [
                /* @__PURE__ */ jsx(AlertTriangle, { className: "w-3.5 h-3.5 shrink-0 mt-0.5 text-rose-500" }),
                /* @__PURE__ */ jsx("span", { className: "text-[11px] leading-snug", children: flag })
              ] }, idx)) }) : /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-emerald-700 bg-emerald-50 border border-emerald-200 p-3 rounded-lg", children: [
                /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4 shrink-0 text-emerald-600" }),
                /* @__PURE__ */ jsx("span", { className: "text-[11px] font-medium", children: "No suspicious fraud signals detected. Clean customer profile." })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "pt-2 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold text-gray-600", children: "Manual Fraud Status Override:" }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  disabled: fraudProcessing || order.fraud_status === "safe",
                  onClick: () => handleUpdateFraud("safe"),
                  className: `px-3 py-1.5 rounded-lg text-xs font-bold border transition flex items-center gap-1.5 ${order.fraud_status === "safe" ? "bg-emerald-600 text-white border-emerald-600" : "bg-white hover:bg-emerald-50 text-emerald-700 border-emerald-300"}`,
                  children: [
                    /* @__PURE__ */ jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsx("span", { children: "Verify as Safe" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  disabled: fraudProcessing || order.fraud_status === "review",
                  onClick: () => handleUpdateFraud("review"),
                  className: `px-3 py-1.5 rounded-lg text-xs font-bold border transition flex items-center gap-1.5 ${order.fraud_status === "review" ? "bg-amber-500 text-white border-amber-500" : "bg-white hover:bg-amber-50 text-amber-700 border-amber-300"}`,
                  children: [
                    /* @__PURE__ */ jsx(ShieldAlert, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsx("span", { children: "Mark for Review" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  disabled: fraudProcessing || order.fraud_status === "high_risk",
                  onClick: () => handleUpdateFraud("high_risk"),
                  className: `px-3 py-1.5 rounded-lg text-xs font-bold border transition flex items-center gap-1.5 ${order.fraud_status === "high_risk" ? "bg-red-600 text-white border-red-600" : "bg-white hover:bg-red-50 text-red-700 border-red-300"}`,
                  children: [
                    /* @__PURE__ */ jsx(ShieldX, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsx("span", { children: "Flag High Risk" })
                  ]
                }
              )
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200/90 shadow-sm overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 sm:p-5 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-50 to-white", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: "p-2.5 rounded-xl bg-orange-50 border border-orange-200 text-[#EF4A23]", children: /* @__PURE__ */ jsx(Truck, { className: "w-5 h-5" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h2", { className: "text-sm font-black text-gray-900 uppercase tracking-wide", children: "Courier Booking & Parcel Dispatch" }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Dispatch parcels to Bangladeshi couriers (Steadfast, Pathao, RedX, Paperfly, Sundarban)" })
            ] })
          ] }),
          order.courier_name && /* @__PURE__ */ jsxs("span", { className: "px-3 py-1 rounded-full text-xs font-black bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsx(PackageCheck, { className: "w-3.5 h-3.5 text-blue-600" }),
            order.courier_status || "Dispatched"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "p-5", children: [
          order.courier_name ? (
            /* Already Dispatched Details */
            /* @__PURE__ */ jsxs("div", { className: "bg-gray-50 rounded-xl p-4 border border-gray-200 space-y-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "text-gray-400 font-semibold block text-[10px] uppercase", children: "Courier Provider" }),
                  /* @__PURE__ */ jsx("span", { className: "text-sm font-black text-gray-900 capitalize", children: order.courier_name })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "text-gray-400 font-semibold block text-[10px] uppercase", children: "Consignment / Tracking ID" }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-0.5", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-xs font-mono font-bold bg-white px-2 py-1 rounded border border-gray-300 text-[#EF4A23]", children: order.courier_tracking_id }),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => copyToClipboard(order.courier_tracking_id),
                        className: "p-1 text-gray-500 hover:text-gray-700 transition",
                        title: "Copy Tracking ID",
                        children: copiedTracking ? /* @__PURE__ */ jsx(Check, { className: "w-3.5 h-3.5 text-emerald-600" }) : /* @__PURE__ */ jsx(Copy, { className: "w-3.5 h-3.5" })
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "text-gray-400 font-semibold block text-[10px] uppercase", children: "COD Collection Amount" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-sm font-black text-emerald-700", children: [
                    "৳",
                    Number(order.courier_collected_amount || 0).toLocaleString()
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "pt-3 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3 text-xs", children: [
                /* @__PURE__ */ jsxs("span", { className: "text-gray-500", children: [
                  "Dispatched on:",
                  " ",
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-700", children: order.dispatched_at ? new Date(order.dispatched_at).toLocaleString() : "Recently" })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: handlePrintLabel,
                    className: "px-3 py-1.5 rounded-lg bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs flex items-center gap-1.5 transition shadow-sm",
                    children: [
                      /* @__PURE__ */ jsx(Printer, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsx("span", { children: "Print Shipping Waybill Label" })
                    ]
                  }
                ) })
              ] })
            ] })
          ) : null,
          /* @__PURE__ */ jsxs("form", { onSubmit: handleDispatchCourier, className: "mt-4 space-y-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold text-gray-800 uppercase tracking-wide", children: order.courier_name ? "Re-assign or Update Courier Consignment" : "Send Parcel to Courier Partner" }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                  "Courier Partner ",
                  /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
                ] }),
                /* @__PURE__ */ jsx(
                  "select",
                  {
                    value: courierData.courier_name,
                    onChange: (e) => setCourierData("courier_name", e.target.value),
                    className: "w-full p-2.5 rounded-xl border border-gray-300 focus:border-[#EF4A23] font-medium",
                    children: courierProviders.map((c) => /* @__PURE__ */ jsx("option", { value: c.id, children: c.name }, c.id))
                  }
                ),
                /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400 mt-1", children: courierProviders.find((c) => c.id === courierData.courier_name)?.desc })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Tracking / Consignment ID" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    placeholder: "Leave blank for auto-generation",
                    value: courierData.courier_tracking_id,
                    onChange: (e) => setCourierData("courier_tracking_id", e.target.value),
                    className: "w-full p-2.5 rounded-xl border border-gray-300 focus:border-[#EF4A23] font-mono text-xs"
                  }
                ),
                /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400 mt-1", children: "Auto-generates format: ST-[COURIER]-[CODE] if empty" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                  "COD Amount to Collect (৳) ",
                  /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
                ] }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    min: "0",
                    step: "1",
                    value: courierData.courier_collected_amount,
                    onChange: (e) => setCourierData("courier_collected_amount", e.target.value),
                    className: "w-full p-2.5 rounded-xl border border-gray-300 focus:border-[#EF4A23] font-bold"
                  }
                ),
                /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-400 mt-1", children: order.payment_method === "cod" ? "Matches Cash on Delivery total" : "Prepaid order (Typically ৳0)" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-2", children: /* @__PURE__ */ jsxs(
              "button",
              {
                type: "submit",
                disabled: courierProcessing,
                className: "bg-[#081621] hover:bg-[#122738] text-white text-xs font-bold px-5 py-2.5 rounded-xl flex items-center gap-2 transition shadow-sm",
                children: [
                  /* @__PURE__ */ jsx(Send, { className: "w-3.5 h-3.5 text-[#EF4A23]" }),
                  /* @__PURE__ */ jsx("span", { children: courierProcessing ? "Dispatching..." : order.courier_name ? "Update Courier Consignment" : "Confirm & Dispatch to Courier" })
                ]
              }
            ) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm text-xs space-y-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900 border-b pb-2", children: [
            /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-blue-600" }),
            /* @__PURE__ */ jsx("span", { children: "Customer Info" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900 text-sm", children: order.customer_name }),
          /* @__PURE__ */ jsx("p", { className: "font-semibold text-gray-800", children: order.customer_phone }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-500", children: order.customer_email || "No email provided" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm text-xs space-y-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900 border-b pb-2", children: [
            /* @__PURE__ */ jsx(Truck, { className: "w-4 h-4 text-emerald-600" }),
            /* @__PURE__ */ jsx("span", { children: "Shipping Address" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-700 leading-relaxed", children: order.customer_address }),
          /* @__PURE__ */ jsxs("p", { className: "font-bold text-gray-900", children: [
            order.city,
            " ",
            order.zone && `(${order.zone})`
          ] }),
          order.notes && /* @__PURE__ */ jsxs("p", { className: "text-gray-500 italic mt-1 bg-yellow-50 p-1.5 rounded", children: [
            "Note: ",
            order.notes
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-gray-200/80 shadow-sm text-xs space-y-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-bold text-gray-900 border-b pb-2", children: [
            /* @__PURE__ */ jsx(CreditCard, { className: "w-4 h-4 text-orange-600" }),
            /* @__PURE__ */ jsx("span", { children: "Payment & Total" })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "uppercase font-bold text-gray-800", children: [
            "Method: ",
            /* @__PURE__ */ jsx("span", { className: "text-[#EF4A23]", children: order.payment_method })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-gray-600", children: [
            "Payment Status: ",
            /* @__PURE__ */ jsx("span", { className: "font-bold uppercase text-gray-800", children: order.payment_status })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-base font-black text-gray-900 mt-2", children: [
            "Total: ৳",
            Number(order.total).toLocaleString()
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200/80 shadow-sm overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 border-b flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("h3", { className: "text-xs font-bold text-gray-900 uppercase", children: [
            "Ordered Products (",
            order.items?.length || 0,
            ")"
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "text-xs font-semibold text-gray-500", children: [
            "Order #",
            order.order_number
          ] })
        ] }),
        /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 border-b text-gray-500 uppercase font-semibold", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Product Name" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Unit Price" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Quantity" }),
            /* @__PURE__ */ jsx("th", { className: "p-3.5 text-right", children: "Total" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: order.items?.map((item) => /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "p-3.5 font-bold text-gray-900", children: item.product_name }),
            /* @__PURE__ */ jsxs("td", { className: "p-3.5 text-center", children: [
              "৳",
              Number(item.unit_price).toLocaleString()
            ] }),
            /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center font-bold", children: item.quantity }),
            /* @__PURE__ */ jsxs("td", { className: "p-3.5 text-right font-black text-gray-900", children: [
              "৳",
              Number(item.total_price).toLocaleString()
            ] })
          ] }, item.id)) }),
          /* @__PURE__ */ jsxs("tfoot", { className: "bg-gray-50/50 border-t font-bold", children: [
            /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { colSpan: "3", className: "p-3 text-right text-gray-600", children: "Subtotal:" }),
              /* @__PURE__ */ jsxs("td", { className: "p-3 text-right", children: [
                "৳",
                Number(order.subtotal || order.total).toLocaleString()
              ] })
            ] }),
            Number(order.shipping_cost) > 0 && /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { colSpan: "3", className: "p-3 text-right text-gray-600", children: "Shipping:" }),
              /* @__PURE__ */ jsxs("td", { className: "p-3 text-right", children: [
                "৳",
                Number(order.shipping_cost).toLocaleString()
              ] })
            ] }),
            /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
              /* @__PURE__ */ jsx("td", { colSpan: "3", className: "p-3.5 text-right text-gray-900 text-sm", children: "Grand Total:" }),
              /* @__PURE__ */ jsxs("td", { className: "p-3.5 text-right text-[#EF4A23] text-sm font-black", children: [
                "৳",
                Number(order.total).toLocaleString()
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900 border-b pb-3 mb-4", children: "Overall Order Status" }),
        /* @__PURE__ */ jsxs("form", { onSubmit: handleUpdateStatus, className: "grid grid-cols-1 sm:grid-cols-3 gap-4 items-end text-xs", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Order Status" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: statusData.order_status,
                onChange: (e) => setStatusData("order_status", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "pending", children: "Pending" }),
                  /* @__PURE__ */ jsx("option", { value: "processing", children: "Processing" }),
                  /* @__PURE__ */ jsx("option", { value: "confirmed", children: "Confirmed" }),
                  /* @__PURE__ */ jsx("option", { value: "shipped", children: "Shipped" }),
                  /* @__PURE__ */ jsx("option", { value: "delivered", children: "Delivered" }),
                  /* @__PURE__ */ jsx("option", { value: "cancelled", children: "Cancelled" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Payment Status" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: statusData.payment_status,
                onChange: (e) => setStatusData("payment_status", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "pending", children: "Pending" }),
                  /* @__PURE__ */ jsx("option", { value: "paid", children: "Paid" }),
                  /* @__PURE__ */ jsx("option", { value: "failed", children: "Failed" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              disabled: statusProcessing,
              className: "w-full bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold py-2.5 rounded-lg transition",
              children: statusProcessing ? "Saving..." : "Update Status"
            }
          ) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "hidden print:block text-black bg-white", children: printMode === "courier_label" ? (
      /* COURIER SHIPPING LABEL / WAYBILL */
      /* @__PURE__ */ jsxs("div", { className: "max-w-[100mm] mx-auto border-2 border-dashed border-black p-4 font-sans text-xs", children: [
        /* @__PURE__ */ jsxs("div", { className: "border-b-2 border-black pb-2 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h1", { className: "text-base font-black tracking-tighter", children: "STAR TECH & ENGINEERING LTD" }),
            /* @__PURE__ */ jsx("p", { className: "text-[9px] text-gray-600", children: "Hub: Pragati Sharani, Dhaka 1212 | Hotline: 16793" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-right", children: /* @__PURE__ */ jsx("span", { className: "text-[10px] uppercase font-black px-1.5 py-0.5 border border-black rounded", children: order.courier_name || "COURIER" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "py-2.5 text-center border-b-2 border-black", children: [
          /* @__PURE__ */ jsx("div", { className: "inline-block tracking-widest font-mono text-xs font-black", children: "||||||| | ||||| |||| | |||||| |||| | |||||||" }),
          /* @__PURE__ */ jsx("p", { className: "font-mono text-sm font-black mt-1", children: order.courier_tracking_id || `ST-${order.order_number}` })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "py-2 border-b-2 border-black space-y-1", children: [
          /* @__PURE__ */ jsx("span", { className: "text-[9px] uppercase font-bold text-gray-600 block", children: "DELIVER TO (RECIPIENT):" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-black", children: order.customer_name }),
          /* @__PURE__ */ jsx("p", { className: "font-black text-sm", children: order.customer_phone }),
          /* @__PURE__ */ jsx("p", { className: "text-xs leading-snug", children: order.customer_address }),
          /* @__PURE__ */ jsxs("p", { className: "font-bold text-xs", children: [
            order.city,
            " ",
            order.zone && `(${order.zone})`
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "py-2 border-b-2 border-black grid grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "text-[9px] uppercase font-bold text-gray-600 block", children: "ORDER NUMBER:" }),
            /* @__PURE__ */ jsx("span", { className: "font-bold text-xs", children: order.order_number })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
            /* @__PURE__ */ jsx("span", { className: "text-[9px] uppercase font-bold text-gray-600 block", children: "CASH TO COLLECT (COD):" }),
            /* @__PURE__ */ jsxs("span", { className: "text-sm font-black text-black", children: [
              "৳",
              Number(order.courier_collected_amount !== null ? order.courier_collected_amount : order.total).toLocaleString()
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-2 text-[10px]", children: [
          /* @__PURE__ */ jsxs("span", { className: "font-bold block mb-1", children: [
            "Package Contents (",
            order.items?.length || 0,
            " items):"
          ] }),
          /* @__PURE__ */ jsx("ul", { className: "list-disc list-inside space-y-0.5", children: order.items?.map((item) => /* @__PURE__ */ jsxs("li", { className: "truncate", children: [
            item.quantity,
            "x ",
            item.product_name
          ] }, item.id)) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "mt-3 pt-2 border-t border-gray-400 text-center text-[8px] text-gray-500", children: "Printed from Star Tech Admin Portal. Handle with care." })
      ] })
    ) : (
      /* STANDARD INVOICE */
      /* @__PURE__ */ jsxs("div", { className: "max-w-2xl mx-auto p-6 font-sans text-xs", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center border-b pb-4 mb-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h1", { className: "text-lg font-black text-[#EF4A23]", children: "STAR TECH & ENGINEERING LTD" }),
            /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-500", children: "Leading Computer, Laptop & Component Retailer in Bangladesh" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-sm font-black", children: "INVOICE" }),
            /* @__PURE__ */ jsxs("p", { className: "font-mono text-xs", children: [
              "#",
              order.order_number
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[10px] text-gray-500", children: new Date(order.created_at).toLocaleDateString() })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4 mb-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "font-bold text-gray-700 text-[10px] uppercase", children: "Billed / Shipped To:" }),
            /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-900", children: order.customer_name }),
            /* @__PURE__ */ jsx("p", { children: order.customer_phone }),
            /* @__PURE__ */ jsx("p", { children: order.customer_address }),
            /* @__PURE__ */ jsxs("p", { children: [
              order.city,
              " ",
              order.zone && `(${order.zone})`
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
            /* @__PURE__ */ jsx("h3", { className: "font-bold text-gray-700 text-[10px] uppercase", children: "Payment & Delivery:" }),
            /* @__PURE__ */ jsxs("p", { children: [
              "Method: ",
              /* @__PURE__ */ jsx("strong", { className: "uppercase", children: order.payment_method })
            ] }),
            /* @__PURE__ */ jsxs("p", { children: [
              "Payment Status: ",
              /* @__PURE__ */ jsx("strong", { className: "uppercase", children: order.payment_status })
            ] }),
            order.courier_name && /* @__PURE__ */ jsxs("p", { children: [
              "Courier: ",
              /* @__PURE__ */ jsxs("strong", { children: [
                order.courier_name,
                " (",
                order.courier_tracking_id,
                ")"
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs mb-4 border", children: [
          /* @__PURE__ */ jsx("thead", { className: "bg-gray-100 border-b", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "p-2", children: "Item Description" }),
            /* @__PURE__ */ jsx("th", { className: "p-2 text-center", children: "Qty" }),
            /* @__PURE__ */ jsx("th", { className: "p-2 text-right", children: "Unit Price" }),
            /* @__PURE__ */ jsx("th", { className: "p-2 text-right", children: "Total" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y", children: order.items?.map((item) => /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "p-2 font-medium", children: item.product_name }),
            /* @__PURE__ */ jsx("td", { className: "p-2 text-center", children: item.quantity }),
            /* @__PURE__ */ jsxs("td", { className: "p-2 text-right", children: [
              "৳",
              Number(item.unit_price).toLocaleString()
            ] }),
            /* @__PURE__ */ jsxs("td", { className: "p-2 text-right font-bold", children: [
              "৳",
              Number(item.total_price).toLocaleString()
            ] })
          ] }, item.id)) }),
          /* @__PURE__ */ jsx("tfoot", { className: "border-t font-bold", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { colSpan: "3", className: "p-2 text-right", children: "Total:" }),
            /* @__PURE__ */ jsxs("td", { className: "p-2 text-right font-black", children: [
              "৳",
              Number(order.total).toLocaleString()
            ] })
          ] }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-center text-[9px] text-gray-500 mt-6", children: "Thank you for shopping with Star Tech & Engineering Ltd! Hotline: 16793" })
      ] })
    ) })
  ] });
}
export {
  Show as default
};
