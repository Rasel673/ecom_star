import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { Link } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-VbDbxh3C.js";
import { CheckCircle2, ArrowRight, Printer } from "lucide-react";
function OrderSuccess({ order }) {
  return /* @__PURE__ */ jsx(FrontendLayout, { title: `Order Confirmed #${order.order_number}`, children: /* @__PURE__ */ jsxs("div", { className: "max-w-3xl mx-auto py-8", children: [
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-8 text-center mb-8", children: [
      /* @__PURE__ */ jsx("div", { className: "w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsx(CheckCircle2, { className: "w-12 h-12" }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-2xl md:text-3xl font-black text-gray-900 mb-2", children: "Thank You! Your Order Has Been Placed." }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 max-w-md mx-auto mb-4", children: "We have received your order and our team is preparing it. A verification SMS & call will be sent to your phone shortly." }),
      /* @__PURE__ */ jsxs("div", { className: "inline-block bg-gray-50 border border-gray-200 rounded-xl px-5 py-2.5", children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500 block", children: "Order Tracking Number:" }),
        /* @__PURE__ */ jsx("span", { className: "text-lg font-black text-[#EF4A23]", children: order.order_number })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-3xl border border-gray-200 shadow-sm p-6 md:p-8 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-4", children: [
        /* @__PURE__ */ jsx("h3", { className: "font-bold text-sm text-gray-900", children: "Order Invoice Summary" }),
        /* @__PURE__ */ jsx("span", { className: "text-xs bg-orange-50 text-orange-700 px-3 py-1 rounded-full font-bold border border-orange-200 uppercase", children: order.order_status })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-600", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-900 block mb-1", children: "Customer Information:" }),
          /* @__PURE__ */ jsx("p", { children: order.customer_name }),
          /* @__PURE__ */ jsx("p", { children: order.customer_phone }),
          order.customer_email && /* @__PURE__ */ jsx("p", { children: order.customer_email })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-900 block mb-1", children: "Delivery Address:" }),
          /* @__PURE__ */ jsx("p", { children: order.customer_address }),
          /* @__PURE__ */ jsx("p", { children: order.city })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "border border-gray-100 rounded-xl overflow-hidden", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 text-gray-500 font-semibold border-b", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "p-3", children: "Product" }),
          /* @__PURE__ */ jsx("th", { className: "p-3 text-center", children: "Qty" }),
          /* @__PURE__ */ jsx("th", { className: "p-3 text-right", children: "Price" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: order.items?.map((item) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { className: "p-3 font-medium text-gray-800", children: item.product_name }),
          /* @__PURE__ */ jsx("td", { className: "p-3 text-center text-gray-600", children: item.quantity }),
          /* @__PURE__ */ jsxs("td", { className: "p-3 text-right font-bold text-gray-900", children: [
            "৳",
            Number(item.total_price).toLocaleString()
          ] })
        ] }, item.id)) })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "border-t pt-4 space-y-1.5 text-xs text-gray-600", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
          /* @__PURE__ */ jsx("span", { children: "Subtotal:" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "৳",
            Number(order.subtotal).toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
          /* @__PURE__ */ jsx("span", { children: "Shipping Cost:" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "৳",
            Number(order.shipping_cost).toLocaleString()
          ] })
        ] }),
        order.discount > 0 && /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-emerald-600", children: [
          /* @__PURE__ */ jsx("span", { children: "Discount:" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "-৳",
            Number(order.discount).toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-base font-black text-[#EF4A23] pt-2 border-t", children: [
          /* @__PURE__ */ jsx("span", { children: "Total Paid / Payable:" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "৳",
            Number(order.total).toLocaleString()
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "pt-4 flex flex-col sm:flex-row items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: "/",
            className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#081621] hover:bg-[#EF4A23] text-white text-xs font-bold py-3 px-6 rounded-xl transition",
            children: [
              /* @__PURE__ */ jsx("span", { children: "Back to Shopping" }),
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "button",
          {
            onClick: () => window.print(),
            className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 border border-gray-300 hover:bg-gray-50 text-gray-700 text-xs font-bold py-3 px-6 rounded-xl transition",
            children: [
              /* @__PURE__ */ jsx(Printer, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: "Print Receipt" })
            ]
          }
        )
      ] })
    ] })
  ] }) });
}
export {
  OrderSuccess as default
};
