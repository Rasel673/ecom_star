import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-VbDbxh3C.js";
import { ChevronLeft, ChevronRight, ArrowRight, Gamepad2, Watch, Wifi, Keyboard, Tv, Cpu, Laptop, Monitor, Sparkles, Flame } from "lucide-react";
import { P as ProductCard } from "./ProductCard-Ck3qGjy2.js";
function HeroSlider({ banners = [] }) {
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    if (!banners.length) return;
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length);
    }, 5e3);
    return () => clearInterval(interval);
  }, [banners.length]);
  if (!banners.length) return null;
  const nextSlide = () => setCurrent((prev) => (prev + 1) % banners.length);
  const prevSlide = () => setCurrent((prev) => (prev - 1 + banners.length) % banners.length);
  const banner = banners[current];
  return /* @__PURE__ */ jsxs("div", { className: "relative rounded-2xl overflow-hidden bg-gray-900 shadow-md group h-[190px] xs:h-[240px] sm:h-[320px] md:h-[380px] lg:h-[400px]", children: [
    /* @__PURE__ */ jsxs(Link, { href: banner.link || "#", className: "block w-full h-full relative", children: [
      /* @__PURE__ */ jsx(
        "img",
        {
          src: banner.image,
          alt: banner.title || "Star Tech Promo",
          className: "w-full h-full object-cover"
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex flex-col justify-end p-6 md:p-8", children: [
        banner.title && /* @__PURE__ */ jsx("h2", { className: "text-xl md:text-3xl font-extrabold text-white tracking-tight drop-shadow-md", children: banner.title }),
        banner.subtitle && /* @__PURE__ */ jsx("p", { className: "text-sm md:text-base text-gray-200 mt-1 max-w-xl drop-shadow", children: banner.subtitle })
      ] })
    ] }),
    banners.length > 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: prevSlide,
          className: "absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition opacity-0 group-hover:opacity-100",
          title: "Previous",
          children: /* @__PURE__ */ jsx(ChevronLeft, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: nextSlide,
          className: "absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition opacity-0 group-hover:opacity-100",
          title: "Next",
          children: /* @__PURE__ */ jsx(ChevronRight, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10", children: banners.map((_, idx) => /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setCurrent(idx),
          className: `h-2 rounded-full transition-all duration-300 ${current === idx ? "w-6 bg-[#EF4A23]" : "w-2 bg-white/60 hover:bg-white"}`
        },
        idx
      )) })
    ] })
  ] });
}
const iconMap = {
  "Monitor": Monitor,
  "Laptop": Laptop,
  "Cpu": Cpu,
  "Tv": Tv,
  "Keyboard": Keyboard,
  "Wifi": Wifi,
  "Watch": Watch,
  "Gamepad2": Gamepad2
};
function Home({
  heroBanners = [],
  promoBanners = [],
  featuredCategories = [],
  featuredProducts = [],
  popularProducts = [],
  latestProducts = [],
  brands = [],
  seo = {}
}) {
  return /* @__PURE__ */ jsxs(FrontendLayout, { title: seo.title, description: seo.description, children: [
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10", children: [
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsx(HeroSlider, { banners: heroBanners }) }),
      /* @__PURE__ */ jsx("div", { className: "hidden lg:flex flex-col gap-4 justify-between", children: promoBanners.slice(0, 2).map((promo, idx) => /* @__PURE__ */ jsxs(
        Link,
        {
          href: promo.link || "#",
          className: "relative flex-1 rounded-2xl overflow-hidden group shadow-md bg-gray-900 border border-gray-800",
          children: [
            /* @__PURE__ */ jsx(
              "img",
              {
                src: promo.image,
                alt: promo.title || "Promo",
                className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-5", children: [
              /* @__PURE__ */ jsx("h3", { className: "text-base font-bold text-white leading-snug drop-shadow", children: promo.title }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-orange-400 mt-1 font-semibold flex items-center gap-1", children: [
                "View Details ",
                /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
              ] })
            ] })
          ]
        },
        idx
      )) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-12", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-6", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Featured Categories" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Get your desired product from featured category!" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 sm:grid-cols-4 md:grid-cols-8 gap-2 sm:gap-3", children: featuredCategories.map((cat) => {
        const IconComponent = iconMap[cat.icon] || Cpu;
        return /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("category.show", cat.slug),
            className: "bg-white hover:bg-[#081621] border border-gray-200 hover:border-[#081621] rounded-xl p-2.5 sm:p-4 flex flex-col items-center justify-center gap-1.5 sm:gap-2 text-center group transition-all duration-200 shadow-sm hover:shadow-md",
            children: [
              /* @__PURE__ */ jsx("div", { className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-50 group-hover:bg-[#EF4A23] flex items-center justify-center text-[#EF4A23] group-hover:text-white transition", children: /* @__PURE__ */ jsx(IconComponent, { className: "w-5 h-5 sm:w-6 sm:h-6" }) }),
              /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-xs font-bold text-gray-800 group-hover:text-white transition line-clamp-1", children: cat.name })
            ]
          },
          cat.id
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-10 sm:mb-14", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4 sm:mb-6 border-b border-gray-200 pb-2 sm:pb-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2", children: [
            /* @__PURE__ */ jsx(Sparkles, { className: "w-4 h-4 sm:w-5 sm:h-5 text-[#EF4A23]" }),
            /* @__PURE__ */ jsx("h2", { className: "text-lg sm:text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Featured Products" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Check & get your desired product!" })
        ] }),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("category.show", "desktop"),
            className: "text-xs font-bold text-[#EF4A23] hover:text-[#d63c17] flex items-center gap-1 transition",
            children: [
              "View All ",
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5", children: featuredProducts.map((product) => /* @__PURE__ */ jsx(ProductCard, { product }, product.id)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-10 sm:mb-14", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4 sm:mb-6 border-b border-gray-200 pb-2 sm:pb-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2", children: [
            /* @__PURE__ */ jsx(Flame, { className: "w-4 h-4 sm:w-5 sm:h-5 text-amber-500" }),
            /* @__PURE__ */ jsx("h2", { className: "text-lg sm:text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Top Trending & Popular" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] sm:text-xs text-gray-500 mt-0.5", children: "Most in-demand computer hardware and tech accessories" })
        ] }),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("category.show", "component"),
            className: "text-xs font-bold text-[#EF4A23] hover:text-[#d63c17] flex items-center gap-1 transition",
            children: [
              "Explore More ",
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5", children: popularProducts.map((product) => /* @__PURE__ */ jsx(ProductCard, { product }, product.id)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-14 bg-gradient-to-r from-[#081621] via-[#112538] to-[#081621] rounded-2xl p-6 md:p-10 border border-gray-800 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "max-w-xl", children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs font-bold tracking-widest text-[#EF4A23] uppercase bg-orange-500/10 border border-orange-500/20 px-3 py-1 rounded-full", children: "Custom Tool" }),
        /* @__PURE__ */ jsx("h3", { className: "text-2xl md:text-3xl font-black mt-3 leading-tight", children: "Build Your Dream PC With Live Compatibility Check" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-300 mt-2", children: "Select CPU, Motherboard, GPU, RAM, Storage, Power Supply & Casing. Calculate wattage, get instant price breakdown, and order directly." })
      ] }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/pc-builder",
          className: "inline-flex items-center gap-2 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg hover:shadow-orange-500/20 transition",
          children: [
            /* @__PURE__ */ jsx(Cpu, { className: "w-5 h-5" }),
            /* @__PURE__ */ jsx("span", { children: "Start PC Builder" }),
            /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 ml-1" })
          ]
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-14", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-6", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-xl md:text-2xl font-black text-gray-900 tracking-tight", children: "Top Brands" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Authorized distributors of world's best tech giants" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4", children: brands.map((brand) => /* @__PURE__ */ jsx(
        "div",
        {
          className: "bg-white border border-gray-200/90 rounded-xl p-4 flex flex-col items-center justify-center text-center shadow-sm hover:border-[#EF4A23] transition group",
          children: /* @__PURE__ */ jsx("span", { className: "text-sm font-extrabold text-gray-800 group-hover:text-[#EF4A23] transition", children: brand.name })
        },
        brand.id
      )) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 p-6 md:p-8 text-xs text-gray-600 space-y-4", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900 uppercase tracking-wide", children: "Leading Computer, Laptop & Component Shop in Bangladesh - Star Tech & Engineering Ltd" }),
      /* @__PURE__ */ jsx("p", { children: "Star Tech is Bangladesh's largest retail and online shop for computers, laptops, PC gaming components, gadgets, and office electronics. Since 2007, Star Tech has been delivering genuine computer products with official warranty, exceptional customer service, and unmatched competitive prices." }),
      /* @__PURE__ */ jsx("p", { children: "Whether you are a competitive gamer building a high-end RTX desktop rig, a corporate professional seeking an ultra-thin laptop, or a creative designer needing 4K color-calibrated monitors, Star Tech provides the widest inventory across Dhaka, Chittagong, Rajshahi, Khulna, and nationwide doorstep delivery." })
    ] })
  ] });
}
export {
  Home as default
};
