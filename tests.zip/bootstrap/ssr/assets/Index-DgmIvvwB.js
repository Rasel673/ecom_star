import { jsxs, jsx } from "react/jsx-runtime";
import "react";
import { Link, router } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { Plus, FolderTree, Edit, Trash2 } from "lucide-react";
function Index({ categories }) {
  const handleDelete = (id, name) => {
    if (confirm(`Are you sure you want to delete category "${name}"?`)) {
      router.delete(route("admin.categories.destroy", id));
    }
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { title: "Manage Categories", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-xl font-black text-gray-900", children: "Categories" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "Organize and manage store categories & subcategories" })
      ] }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("admin.categories.create"),
          className: "inline-flex items-center gap-1.5 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-xs font-bold py-2.5 px-4 rounded-xl transition shadow-sm",
          children: [
            /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Add New Category" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white rounded-2xl border border-gray-200/80 shadow-sm overflow-hidden", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-xs", children: [
      /* @__PURE__ */ jsx("thead", { className: "bg-gray-50 border-b border-gray-200 text-gray-500 font-semibold uppercase", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Category Name" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Slug" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5", children: "Parent Category" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Status" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Featured" }),
        /* @__PURE__ */ jsx("th", { className: "p-3.5 text-center", children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-100", children: categories.data.map((cat) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-gray-50/50", children: [
        /* @__PURE__ */ jsxs("td", { className: "p-3.5 font-bold text-gray-900 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(FolderTree, { className: "w-4 h-4 text-gray-400" }),
          /* @__PURE__ */ jsx("span", { children: cat.name })
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-gray-500", children: cat.slug }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-gray-600", children: cat.parent ? cat.parent.name : /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "— (Root)" }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsx("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold ${cat.status ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-500"}`, children: cat.status ? "Active" : "Inactive" }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: cat.is_featured ? /* @__PURE__ */ jsx("span", { className: "text-orange-600 font-bold", children: "Yes" }) : /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "No" }) }),
        /* @__PURE__ */ jsx("td", { className: "p-3.5 text-center", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("admin.categories.edit", cat.id),
              className: "p-1 text-gray-500 hover:text-blue-600",
              title: "Edit",
              children: /* @__PURE__ */ jsx(Edit, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => handleDelete(cat.id, cat.name),
              className: "p-1 text-gray-500 hover:text-rose-600",
              title: "Delete",
              children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
            }
          )
        ] }) })
      ] }, cat.id)) })
    ] }) }),
    categories.links && categories.links.length > 3 && /* @__PURE__ */ jsx("div", { className: "mt-6 flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm", children: categories.links.map((link, idx) => /* @__PURE__ */ jsx(
      Link,
      {
        href: link.url || "#",
        dangerouslySetInnerHTML: { __html: link.label },
        className: `px-3 py-1.5 text-xs rounded-lg transition font-medium ${link.active ? "bg-[#EF4A23] text-white font-bold" : "text-gray-700 hover:bg-gray-100"}`
      },
      idx
    )) }) })
  ] });
}
export {
  Index as default
};
