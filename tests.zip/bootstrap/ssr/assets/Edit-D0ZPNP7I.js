import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { useForm, Link } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
function Edit({ product, categories = [], brands = [] }) {
  const { data, setData, put, processing, errors } = useForm({
    name: product.name || "",
    slug: product.slug || "",
    category_id: product.category_id || "",
    brand_id: product.brand_id || "",
    model: product.model || "",
    sku: product.sku || "",
    regular_price: product.regular_price || "",
    special_price: product.special_price || "",
    stock_status: product.stock_status || "in_stock",
    quantity: product.quantity ?? 10,
    thumbnail: product.thumbnail || "",
    key_features: Array.isArray(product.key_features) && product.key_features.length > 0 ? product.key_features : [""],
    specifications: product.specifications || {},
    description: product.description || "",
    is_featured: !!product.is_featured,
    is_popular: !!product.is_popular,
    status: !!product.status,
    meta_title: product.meta_title || "",
    meta_description: product.meta_description || ""
  });
  const addFeature = () => {
    setData("key_features", [...data.key_features, ""]);
  };
  const updateFeature = (index, value) => {
    const copy = [...data.key_features];
    copy[index] = value;
    setData("key_features", copy);
  };
  const removeFeature = (index) => {
    setData("key_features", data.key_features.filter((_, i) => i !== index));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    put(route("admin.products.update", product.id));
  };
  return /* @__PURE__ */ jsx(AdminLayout, { title: `Edit Product: ${product.name}`, children: /* @__PURE__ */ jsxs("div", { className: "max-w-4xl mx-auto", children: [
    /* @__PURE__ */ jsxs(
      Link,
      {
        href: route("admin.products.index"),
        className: "inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#EF4A23] font-semibold mb-4",
        children: [
          /* @__PURE__ */ jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsx("span", { children: "Back to Products" })
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6 md:p-8", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900 border-b pb-3 mb-6", children: "Edit Tech Product" }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-6 text-xs", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "md:col-span-2", children: [
            /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
              "Product Name ",
              /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                required: true,
                value: data.name,
                onChange: (e) => setData("name", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            ),
            errors.name && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.name })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Slug" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                required: true,
                value: data.slug,
                onChange: (e) => setData("slug", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            ),
            errors.slug && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.slug })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
              "Category ",
              /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
            ] }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                required: true,
                value: data.category_id,
                onChange: (e) => setData("category_id", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "", children: "— Select Category —" }),
                  categories.map((c) => /* @__PURE__ */ jsx("option", { value: c.id, children: c.name }, c.id))
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Brand" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: data.brand_id,
                onChange: (e) => setData("brand_id", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "", children: "— Select Brand —" }),
                  brands.map((b) => /* @__PURE__ */ jsx("option", { value: b.id, children: b.name }, b.id))
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Model" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: data.model,
                onChange: (e) => setData("model", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
              "Regular Price (৳) ",
              /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                required: true,
                value: data.regular_price,
                onChange: (e) => setData("regular_price", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Special / Cash Price (৳)" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: data.special_price,
                onChange: (e) => setData("special_price", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Stock Status" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: data.stock_status,
                onChange: (e) => setData("stock_status", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "in_stock", children: "In Stock" }),
                  /* @__PURE__ */ jsx("option", { value: "out_of_stock", children: "Out of Stock" }),
                  /* @__PURE__ */ jsx("option", { value: "upcoming", children: "Upcoming" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Quantity" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: data.quantity,
                onChange: (e) => setData("quantity", Number(e.target.value)),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Thumbnail Image URL" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.thumbnail,
              onChange: (e) => setData("thumbnail", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-2", children: [
            /* @__PURE__ */ jsx("label", { className: "font-semibold text-gray-700", children: "Key Features" }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: addFeature,
                className: "text-xs text-[#EF4A23] font-bold flex items-center gap-1 hover:underline",
                children: [
                  /* @__PURE__ */ jsx(Plus, { className: "w-3.5 h-3.5" }),
                  " Add Bullet Point"
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "space-y-2", children: data.key_features.map((feat, idx) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: feat,
                onChange: (e) => updateFeature(idx, e.target.value),
                className: "w-full p-2 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => removeFeature(idx),
                className: "p-2 text-gray-400 hover:text-rose-600",
                children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
              }
            )
          ] }, idx)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Description" }),
          /* @__PURE__ */ jsx(
            "textarea",
            {
              rows: "3",
              value: data.description,
              onChange: (e) => setData("description", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-6 pt-2", children: [
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.is_featured,
                onChange: (e) => setData("is_featured", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Featured Product" })
          ] }),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.is_popular,
                onChange: (e) => setData("is_popular", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Popular / Trending" })
          ] }),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.status,
                onChange: (e) => setData("status", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Active" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-4 border-t flex justify-end gap-3", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("admin.products.index"),
              className: "px-4 py-2 border rounded-lg hover:bg-gray-50 text-gray-700 font-semibold",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              disabled: processing,
              className: "bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold px-6 py-2.5 rounded-lg transition",
              children: processing ? "Updating..." : "Update Product"
            }
          )
        ] })
      ] })
    ] })
  ] }) });
}
export {
  Edit as default
};
