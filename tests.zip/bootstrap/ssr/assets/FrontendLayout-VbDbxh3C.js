import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useState, useRef, useEffect } from "react";
import { usePage, Link, router, Head } from "@inertiajs/react";
import { PhoneCall, MapPin, Menu, Search, Cpu, ShoppingCart, ChevronDown, User, LogOut, X, Gift, Home, ChevronRight, Truck, ShieldCheck, RefreshCw, CheckCircle2, AlertCircle } from "lucide-react";
function Header() {
  const { auth, cart, settings, categoriesNav = [] } = usePage().props;
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState({});
  const searchRef = useRef(null);
  const mobileSearchRef = useRef(null);
  const userDropdownRef = useRef(null);
  const cartCount = Array.isArray(cart) ? cart.reduce((sum, item) => sum + (Number(item?.quantity) || 1), 0) : Number(cart?.count) || (Array.isArray(cart?.items) ? cart.items.reduce((sum, item) => sum + (Number(item?.quantity) || 1), 0) : 0);
  const cartTotal = Array.isArray(cart) ? cart.reduce((sum, item) => sum + (Number(item?.price) || 0) * (Number(item?.quantity) || 1), 0) : Number(cart?.total) || (Array.isArray(cart?.items) ? cart.items.reduce((sum, item) => sum + (Number(item?.price) || 0) * (Number(item?.quantity) || 1), 0) : 0);
  useEffect(() => {
    if (searchQuery.trim().length >= 2) {
      const timer = setTimeout(() => {
        fetch(`/api/search/autocomplete?q=${encodeURIComponent(searchQuery)}`).then((res) => res.json()).then((data) => {
          setSuggestions(data);
          setShowSuggestions(true);
        }).catch(() => setSuggestions([]));
      }, 250);
      return () => clearTimeout(timer);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchQuery]);
  useEffect(() => {
    function handleClickOutside(e) {
      if (searchRef.current && !searchRef.current.contains(e.target) && mobileSearchRef.current && !mobileSearchRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [mobileMenuOpen]);
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowSuggestions(false);
      setMobileMenuOpen(false);
      router.get(route("search"), { q: searchQuery });
    }
  };
  const toggleCategoryExpand = (catId) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [catId]: !prev[catId]
    }));
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("header", { className: "w-full bg-[#081621] text-white sticky top-0 z-50 shadow-md print:hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "border-b border-gray-800 text-[11px] sm:text-xs py-1.5 px-3 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center space-x-3 sm:space-x-6 text-gray-300", children: [
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: `tel:${settings?.hotline || "16793"}`,
              className: "flex items-center gap-1.5 text-orange-400 font-semibold hover:text-orange-300 transition",
              children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Hotline: ",
                  settings?.hotline || "16793"
                ] }),
                /* @__PURE__ */ jsx("span", { className: "hidden sm:inline font-normal text-gray-400", children: "(10 AM - 7 PM)" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs("span", { className: "hidden md:inline-flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(MapPin, { className: "w-3 h-3 text-gray-400" }),
            " Over 18+ Outlets Nationwide"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center space-x-2 sm:space-x-4 text-gray-300 text-[11px] sm:text-xs", children: [
          /* @__PURE__ */ jsx(Link, { href: "/pc-builder", className: "hover:text-orange-400 transition hidden sm:inline", children: "Online Delivery" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-600 hidden sm:inline", children: "|" }),
          /* @__PURE__ */ jsx(Link, { href: "/", className: "hover:text-orange-400 transition", children: "EMI Policy" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-600", children: "|" }),
          /* @__PURE__ */ jsx(Link, { href: "/", className: "hover:text-orange-400 transition", children: "Warranty" })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5 flex items-center justify-between gap-3 sm:gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 sm:gap-3", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setMobileMenuOpen(true),
              className: "lg:hidden text-gray-300 hover:text-white p-1 rounded-lg hover:bg-gray-800 transition",
              "aria-label": "Open Navigation Menu",
              children: /* @__PURE__ */ jsx(Menu, { className: "w-6 h-6" })
            }
          ),
          /* @__PURE__ */ jsxs(Link, { href: "/", className: "flex items-center gap-1.5 group shrink-0", children: [
            /* @__PURE__ */ jsx("span", { className: "text-xl sm:text-2xl font-black tracking-tight text-white group-hover:text-gray-100", children: "STAR" }),
            /* @__PURE__ */ jsx("span", { className: "text-xl sm:text-2xl font-black tracking-tight text-[#EF4A23]", children: "TECH" }),
            /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-[#EF4A23] animate-pulse" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "hidden lg:flex flex-1 max-w-2xl relative", ref: searchRef, children: [
          /* @__PURE__ */ jsxs("form", { onSubmit: handleSearchSubmit, className: "relative w-full flex items-center", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: searchQuery,
                onChange: (e) => setSearchQuery(e.target.value),
                onFocus: () => suggestions.length > 0 && setShowSuggestions(true),
                placeholder: "Search laptop, desktop, graphics card, processor, monitor...",
                className: "w-full bg-[#112233] text-sm text-gray-100 placeholder-gray-400 pl-4 pr-12 py-2.5 rounded-full border border-gray-700 focus:outline-none focus:border-[#EF4A23] focus:ring-1 focus:ring-[#EF4A23] transition-all"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "submit",
                className: "absolute right-1 top-1 bottom-1 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white rounded-full flex items-center justify-center transition",
                title: "Search",
                children: /* @__PURE__ */ jsx(Search, { className: "w-4 h-4" })
              }
            )
          ] }),
          showSuggestions && suggestions.length > 0 && /* @__PURE__ */ jsxs("div", { className: "absolute top-full left-0 right-0 mt-2 bg-[#0e1d2c] border border-gray-700 rounded-xl shadow-2xl overflow-hidden z-50", children: [
            /* @__PURE__ */ jsx("div", { className: "p-2 border-b border-gray-800 text-xs font-semibold text-gray-400 uppercase tracking-wider", children: "Matching Products" }),
            /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-800/60 max-h-80 overflow-y-auto", children: suggestions.map((item) => /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("product.show", item.slug),
                onClick: () => setShowSuggestions(false),
                className: "flex items-center gap-3 p-3 hover:bg-[#162a3d] transition group",
                children: [
                  /* @__PURE__ */ jsx(
                    "img",
                    {
                      src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=100",
                      alt: item.name,
                      className: "w-10 h-10 object-cover rounded bg-white p-0.5 shrink-0"
                    }
                  ),
                  /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-gray-200 group-hover:text-[#EF4A23] truncate transition", children: item.name }),
                    /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: item.model || "" })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "text-right shrink-0", children: /* @__PURE__ */ jsxs("span", { className: "text-sm font-bold text-[#EF4A23]", children: [
                    "৳",
                    (item.special_price || item.regular_price).toLocaleString()
                  ] }) })
                ]
              },
              item.id
            )) }),
            /* @__PURE__ */ jsx("div", { className: "p-2 bg-[#091520] text-center border-t border-gray-800", children: /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: handleSearchSubmit,
                className: "text-xs text-orange-400 hover:text-orange-300 font-medium",
                children: [
                  'View all results for "',
                  searchQuery,
                  '" →'
                ]
              }
            ) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 sm:gap-3", children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/pc-builder",
              className: "flex items-center gap-1.5 sm:gap-2 text-xs font-semibold bg-[#1a2f42] hover:bg-[#223d56] text-[#EF4A23] px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-lg border border-orange-500/30 transition shadow-sm",
              children: [
                /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsxs("div", { className: "text-left hidden xs:block", children: [
                  /* @__PURE__ */ jsx("span", { className: "block text-gray-400 text-[9px] uppercase font-normal leading-none", children: "Custom" }),
                  /* @__PURE__ */ jsx("span", { className: "text-white font-bold text-[11px] sm:text-xs", children: "PC Builder" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("cart.index"),
              className: "relative flex items-center gap-1.5 sm:gap-2 text-xs font-semibold bg-gray-800/80 hover:bg-gray-800 text-white px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg transition",
              children: [
                /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4 sm:w-5 sm:h-5 text-[#EF4A23]" }),
                  cartCount > 0 && /* @__PURE__ */ jsx("span", { className: "absolute -top-2 -right-2 bg-[#EF4A23] text-white text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center animate-pulse", children: cartCount })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "hidden md:block text-left", children: [
                  /* @__PURE__ */ jsx("span", { className: "block text-gray-400 text-[9px] uppercase font-normal leading-none", children: "Cart" }),
                  /* @__PURE__ */ jsxs("span", { children: [
                    "৳",
                    cartTotal.toLocaleString()
                  ] })
                ] })
              ]
            }
          ),
          auth?.user ? /* @__PURE__ */ jsxs("div", { className: "relative", ref: userDropdownRef, children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => setUserMenuOpen(!userMenuOpen),
                className: "flex items-center gap-1.5 sm:gap-2 text-xs font-semibold bg-gray-800/80 hover:bg-gray-800 text-white px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg transition",
                "aria-expanded": userMenuOpen,
                title: "Account Menu",
                children: [
                  /* @__PURE__ */ jsx("div", { className: "w-5 h-5 rounded-full bg-[#EF4A23] text-white flex items-center justify-center font-bold text-[10px]", children: auth.user.name?.charAt(0).toUpperCase() || "U" }),
                  /* @__PURE__ */ jsx("span", { className: "hidden sm:inline font-medium text-xs truncate max-w-[85px]", children: auth.user.name.split(" ")[0] }),
                  /* @__PURE__ */ jsx(ChevronDown, { className: `w-3 h-3 text-gray-400 transition-transform duration-200 ${userMenuOpen ? "rotate-180 text-orange-400" : ""}` })
                ]
              }
            ),
            userMenuOpen && /* @__PURE__ */ jsxs("div", { className: "absolute right-0 mt-2 w-56 bg-[#0c1a26] border border-gray-700/80 rounded-2xl shadow-2xl py-1.5 z-50 divide-y divide-gray-800/80 text-xs animate-in fade-in zoom-in-95 duration-150", children: [
              /* @__PURE__ */ jsxs("div", { className: "px-3.5 py-2.5 bg-[#081621]/60", children: [
                /* @__PURE__ */ jsx("p", { className: "font-bold text-white text-xs truncate", children: auth.user.name }),
                /* @__PURE__ */ jsx("p", { className: "text-[11px] text-gray-400 truncate mt-0.5", children: auth.user.email }),
                auth.user.role === "admin" ? /* @__PURE__ */ jsx("span", { className: "inline-block mt-1 text-[9px] bg-red-500/20 text-red-300 border border-red-500/30 px-1.5 py-0.2 rounded font-mono font-bold uppercase", children: "Admin" }) : /* @__PURE__ */ jsx("span", { className: "inline-block mt-1 text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono font-bold uppercase", children: "Customer" })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "py-1", children: auth.user.role === "admin" ? /* @__PURE__ */ jsxs(
                Link,
                {
                  href: route("admin.dashboard"),
                  onClick: () => setUserMenuOpen(false),
                  className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                  children: [
                    /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-orange-400" }),
                    /* @__PURE__ */ jsx("span", { children: "Admin Dashboard" })
                  ]
                }
              ) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route("dashboard"),
                    onClick: () => setUserMenuOpen(false),
                    className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                    children: [
                      /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-orange-400" }),
                      /* @__PURE__ */ jsx("span", { children: "Customer Account" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: "/dashboard?tab=orders",
                    onClick: () => setUserMenuOpen(false),
                    className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                    children: [
                      /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4 text-blue-400" }),
                      /* @__PURE__ */ jsx("span", { children: "Order History" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: "/dashboard?tab=pc_builds",
                    onClick: () => setUserMenuOpen(false),
                    className: "flex items-center gap-2.5 px-3.5 py-2 text-gray-200 hover:text-white hover:bg-gray-800 transition",
                    children: [
                      /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4 text-purple-400" }),
                      /* @__PURE__ */ jsx("span", { children: "Saved PC Builds" })
                    ]
                  }
                )
              ] }) }),
              /* @__PURE__ */ jsx("div", { className: "py-1", children: /* @__PURE__ */ jsxs(
                Link,
                {
                  href: route("logout"),
                  method: "post",
                  as: "button",
                  onClick: () => setUserMenuOpen(false),
                  className: "w-full flex items-center gap-2.5 px-3.5 py-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition font-bold",
                  children: [
                    /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4 text-rose-400" }),
                    /* @__PURE__ */ jsx("span", { children: "Log Out" })
                  ]
                }
              ) })
            ] })
          ] }) : /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("login"),
              className: "flex items-center gap-1 sm:gap-1.5 text-xs font-semibold bg-[#EF4A23] hover:bg-[#d63c17] text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition shadow-sm",
              children: [
                /* @__PURE__ */ jsx(User, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsx("span", { children: "Login" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "lg:hidden px-3 sm:px-6 pb-2.5 pt-0.5", ref: mobileSearchRef, children: [
        /* @__PURE__ */ jsxs("form", { onSubmit: handleSearchSubmit, className: "relative flex items-center", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              onFocus: () => suggestions.length > 0 && setShowSuggestions(true),
              placeholder: "Search laptop, desktop, component...",
              className: "w-full bg-[#112233] text-xs text-gray-100 placeholder-gray-400 pl-3.5 pr-10 py-2 rounded-xl border border-gray-700 focus:outline-none focus:border-[#EF4A23]"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              className: "absolute right-1 top-1 bottom-1 px-3 bg-[#EF4A23] text-white rounded-lg flex items-center justify-center",
              children: /* @__PURE__ */ jsx(Search, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        showSuggestions && suggestions.length > 0 && /* @__PURE__ */ jsx("div", { className: "absolute left-3 right-3 mt-1.5 bg-[#0e1d2c] border border-gray-700 rounded-xl shadow-2xl overflow-hidden z-50", children: /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-800 max-h-64 overflow-y-auto", children: suggestions.map((item) => /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("product.show", item.slug),
            onClick: () => setShowSuggestions(false),
            className: "flex items-center gap-2.5 p-2.5 hover:bg-[#162a3d]",
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: item.thumbnail || "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=80",
                  alt: item.name,
                  className: "w-8 h-8 object-cover rounded bg-white p-0.5 shrink-0"
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0 text-left", children: [
                /* @__PURE__ */ jsx("p", { className: "text-xs font-medium text-gray-200 truncate", children: item.name }),
                /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-[#EF4A23] font-bold", children: [
                  "৳",
                  (item.special_price || item.regular_price).toLocaleString()
                ] })
              ] })
            ]
          },
          item.id
        )) }) })
      ] })
    ] }),
    mobileMenuOpen && /* @__PURE__ */ jsxs("div", { className: "fixed inset-0 z-50 lg:hidden flex print:hidden", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity",
          onClick: () => setMobileMenuOpen(false)
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "relative w-4/5 max-w-sm bg-[#081621] text-white h-full flex flex-col shadow-2xl z-10 animate-in slide-in-from-left duration-250", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 border-b border-gray-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-1.5",
              children: [
                /* @__PURE__ */ jsx("span", { className: "text-xl font-black text-white", children: "STAR" }),
                /* @__PURE__ */ jsx("span", { className: "text-xl font-black text-[#EF4A23]", children: "TECH" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setMobileMenuOpen(false),
              className: "p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-gray-800 transition",
              children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "p-3 bg-[#112233] border-b border-gray-800 flex items-center justify-between text-xs", children: auth?.user ? /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-[#EF4A23] flex items-center justify-center font-bold text-white text-xs shrink-0", children: auth.user.name?.charAt(0) || "U" }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "font-bold text-white truncate max-w-[120px]", children: auth.user.name }),
              /* @__PURE__ */ jsx(
                Link,
                {
                  href: auth.user.role === "admin" ? route("admin.dashboard") : route("dashboard"),
                  onClick: () => setMobileMenuOpen(false),
                  className: "text-[10px] text-orange-400 hover:underline block truncate",
                  children: auth.user.role === "admin" ? "Admin Panel" : "My Account"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("logout"),
              method: "post",
              as: "button",
              onClick: () => setMobileMenuOpen(false),
              className: "shrink-0 flex items-center gap-1 text-[11px] font-bold text-rose-300 hover:text-white bg-rose-500/20 hover:bg-rose-500/30 px-2.5 py-1.5 rounded-lg border border-rose-500/30 transition",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-3.5 h-3.5 text-rose-400" }),
                /* @__PURE__ */ jsx("span", { children: "Logout" })
              ]
            }
          )
        ] }) : /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full", children: [
          /* @__PURE__ */ jsx("span", { className: "text-gray-300", children: "Welcome, Guest" }),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("login"),
              onClick: () => setMobileMenuOpen(false),
              className: "bg-[#EF4A23] text-white font-bold px-3 py-1 rounded-lg text-xs",
              children: "Login / Register"
            }
          )
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 overflow-y-auto divide-y divide-gray-800/80 text-xs", children: [
          /* @__PURE__ */ jsx("div", { className: "p-2 font-bold uppercase text-[10px] text-gray-400 tracking-wider", children: "All Categories" }),
          categoriesNav.map((cat) => {
            const hasChildren = cat.children && cat.children.length > 0;
            const isExpanded = !!expandedCategories[cat.id];
            return /* @__PURE__ */ jsxs("div", { className: "py-0.5", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 hover:bg-[#112233] transition", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("category.show", cat.slug),
                    onClick: () => setMobileMenuOpen(false),
                    className: "flex-1 font-semibold text-gray-200 hover:text-[#EF4A23]",
                    children: cat.name
                  }
                ),
                hasChildren && /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleCategoryExpand(cat.id),
                    className: "p-1 text-gray-400 hover:text-white",
                    children: /* @__PURE__ */ jsx(ChevronDown, { className: `w-4 h-4 transition-transform duration-200 ${isExpanded ? "rotate-180 text-[#EF4A23]" : ""}` })
                  }
                )
              ] }),
              hasChildren && isExpanded && /* @__PURE__ */ jsx("div", { className: "bg-[#0b1b28] py-1 pl-6 pr-4 space-y-1", children: cat.children.map((child) => /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("category.show", child.slug),
                  onClick: () => setMobileMenuOpen(false),
                  className: "block py-1.5 text-[11px] text-gray-400 hover:text-white hover:text-orange-400 transition",
                  children: child.name
                },
                child.id
              )) })
            ] }, cat.id);
          }),
          /* @__PURE__ */ jsx("div", { className: "p-2 font-bold uppercase text-[10px] text-gray-400 tracking-wider", children: "Quick Features" }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/pc-builder",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-orange-400 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Custom PC Builder" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/",
              onClick: () => setMobileMenuOpen(false),
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-gray-300 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(Gift, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Special Offers" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: `tel:${settings?.hotline || "16793"}`,
              className: "flex items-center gap-2.5 px-4 py-2.5 font-semibold text-emerald-400 hover:bg-[#112233]",
              children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Hotline: ",
                  settings?.hotline || "16793"
                ] })
              ]
            }
          ),
          auth?.user && /* @__PURE__ */ jsx("div", { className: "p-3 border-t border-gray-800/80 mt-2", children: /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("logout"),
              method: "post",
              as: "button",
              onClick: () => setMobileMenuOpen(false),
              className: "w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 font-bold text-xs border border-rose-500/30 transition",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Sign Out" })
              ]
            }
          ) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("nav", { className: "fixed bottom-0 left-0 right-0 z-40 bg-[#081621] border-t border-gray-800 lg:hidden shadow-2xl px-2 py-1.5 flex items-center justify-around text-[10px] text-gray-300 select-none print:hidden", children: [
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/",
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx(Home, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Home" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/",
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx(Gift, { className: "w-4 h-4 text-amber-400" }),
            /* @__PURE__ */ jsx("span", { children: "Offers" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/pc-builder",
          className: "flex flex-col items-center gap-0.5 text-[#EF4A23] font-bold transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-7 h-7 -mt-3.5 rounded-full bg-[#EF4A23] text-white flex items-center justify-center shadow-lg border-2 border-[#081621]", children: /* @__PURE__ */ jsx(Cpu, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx("span", { children: "PC Build" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("cart.index"),
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2 relative",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsx(ShoppingCart, { className: "w-4 h-4" }),
              cartCount > 0 && /* @__PURE__ */ jsx("span", { className: "absolute -top-1.5 -right-2 bg-[#EF4A23] text-white text-[9px] font-bold rounded-full h-3.5 w-3.5 flex items-center justify-center", children: cartCount })
            ] }),
            /* @__PURE__ */ jsx("span", { children: "Cart" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: auth?.user ? auth.user.role === "admin" ? route("admin.dashboard") : route("dashboard") : route("login"),
          className: "flex flex-col items-center gap-0.5 hover:text-[#EF4A23] transition py-1 px-2",
          children: [
            /* @__PURE__ */ jsx(User, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Account" })
          ]
        }
      )
    ] })
  ] });
}
function Navbar() {
  const { categoriesNav } = usePage().props;
  const [activeHover, setActiveHover] = useState(null);
  if (!categoriesNav || categoriesNav.length === 0) return null;
  return /* @__PURE__ */ jsx("nav", { className: "w-full bg-[#081621] border-t border-gray-800 text-white relative z-40 hidden lg:block print:hidden", children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsx("ul", { className: "flex items-center justify-between text-xs font-semibold", children: categoriesNav.map((cat) => {
    const hasChildren = cat.children && cat.children.length > 0;
    return /* @__PURE__ */ jsxs(
      "li",
      {
        className: "relative group py-2.5",
        onMouseEnter: () => setActiveHover(cat.id),
        onMouseLeave: () => setActiveHover(null),
        children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("category.show", cat.slug),
              className: "flex items-center gap-1 text-gray-200 hover:text-[#EF4A23] transition whitespace-nowrap px-2 py-1",
              children: [
                /* @__PURE__ */ jsx("span", { children: cat.name }),
                hasChildren && /* @__PURE__ */ jsx(ChevronDown, { className: "w-3 h-3 text-gray-400 group-hover:text-[#EF4A23]" })
              ]
            }
          ),
          hasChildren && activeHover === cat.id && /* @__PURE__ */ jsxs("div", { className: "absolute top-full left-0 w-64 bg-[#0e1e2d] border border-gray-700 rounded-b-lg shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150", children: [
            /* @__PURE__ */ jsxs("div", { className: "text-[11px] font-bold text-gray-400 px-4 py-1.5 uppercase tracking-wider border-b border-gray-800", children: [
              cat.name,
              " Categories"
            ] }),
            /* @__PURE__ */ jsx("div", { className: "py-1", children: cat.children.map((child) => /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("category.show", child.slug),
                className: "flex items-center justify-between px-4 py-2 text-xs text-gray-300 hover:text-white hover:bg-[#182f45] transition",
                children: [
                  /* @__PURE__ */ jsx("span", { children: child.name }),
                  /* @__PURE__ */ jsx(ChevronRight, { className: "w-3 h-3 text-gray-500" })
                ]
              },
              child.id
            )) })
          ] })
        ]
      },
      cat.id
    );
  }) }) }) });
}
function Footer() {
  const { settings } = usePage().props;
  return /* @__PURE__ */ jsxs("footer", { className: "w-full bg-[#081621] text-gray-400 text-xs border-t border-gray-800 pt-12 pb-8 mt-16 print:hidden", children: [
    /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10 border-b border-gray-800", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 text-gray-300", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 p-4 rounded-xl bg-[#0f2131] border border-gray-800", children: [
        /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23]/10 flex items-center justify-center text-[#EF4A23]", children: /* @__PURE__ */ jsx(Truck, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h4", { className: "text-sm font-bold text-white", children: "Fast Home Delivery" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Within 24 Hours in Dhaka & Express Nationwide" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 p-4 rounded-xl bg-[#0f2131] border border-gray-800", children: [
        /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23]/10 flex items-center justify-center text-[#EF4A23]", children: /* @__PURE__ */ jsx(ShieldCheck, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h4", { className: "text-sm font-bold text-white", children: "100% Genuine Products" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Official Brand Warranty & Verified Authentic" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 p-4 rounded-xl bg-[#0f2131] border border-gray-800", children: [
        /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-full bg-[#EF4A23]/10 flex items-center justify-center text-[#EF4A23]", children: /* @__PURE__ */ jsx(RefreshCw, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h4", { className: "text-sm font-bold text-white", children: "Easy Return & Warranty" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400", children: "Hassle-free replacement policy & repair support" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#EF4A23] pl-2", children: "Support & Helpline" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "p-3 bg-[#0e1d2c] rounded-lg border border-gray-800", children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: "10:00 AM - 7:00 PM" }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1", children: [
              /* @__PURE__ */ jsx(PhoneCall, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { className: "text-xl font-black text-white", children: settings?.hotline || "16793" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "p-3 bg-[#0e1d2c] rounded-lg border border-gray-800", children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: "Store Support" }),
            /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-white", children: settings?.phone || "09678002003" })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-400 flex items-start gap-2 pt-2", children: [
            /* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-[#EF4A23] shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsx("span", { children: settings?.address || "28 Kazi Nazrul Islam Avenue, Banglamotor, Dhaka 1000" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#EF4A23] pl-2", children: "About Star Tech" }),
        /* @__PURE__ */ jsxs("ul", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/about-us", className: "hover:text-white transition", children: "About Us" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/branches-outlets", className: "hover:text-white transition", children: "Branches & Outlets" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/terms-conditions", className: "hover:text-white transition", children: "Terms and Conditions" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/privacy-policy", className: "hover:text-white transition", children: "Privacy Policy" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/emi-calculation", className: "hover:text-white transition", children: "Star Point & EMI Policy" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#EF4A23] pl-2", children: "Customer Help" }),
        /* @__PURE__ */ jsxs("ul", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/pc-builder-guide", className: "hover:text-white transition", children: "PC Builder Guide" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/cart", className: "hover:text-white transition", children: "Shopping Cart" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/order-tracking", className: "hover:text-white transition", children: "Order Tracking" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/emi-calculation", className: "hover:text-white transition", children: "EMI Calculation" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/service-complain", className: "hover:text-white transition", children: "Online Service & Complain" }) }),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, { href: "/page/contact-us", className: "hover:text-white transition", children: "Contact Us" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#EF4A23] pl-2", children: "Stay Connected" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mb-4", children: "Star Tech & Engineering Ltd is the largest Computer, Laptop & Gaming accessory retailer in Bangladesh." }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx("a", { href: "https://facebook.com", target: "_blank", rel: "noreferrer", className: "w-8 h-8 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center hover:bg-blue-600 hover:text-white transition", children: "f" }),
          /* @__PURE__ */ jsx("a", { href: "https://youtube.com", target: "_blank", rel: "noreferrer", className: "w-8 h-8 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center hover:bg-red-600 hover:text-white transition", children: "▶" }),
          /* @__PURE__ */ jsx("a", { href: "https://instagram.com", target: "_blank", rel: "noreferrer", className: "w-8 h-8 rounded-full bg-pink-600/20 text-pink-400 flex items-center justify-center hover:bg-pink-600 hover:text-white transition", children: "📷" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 pt-4 border-t border-gray-800", children: [
          /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-500 block mb-2", children: "Accepted Payment Methods" }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2 text-[10px] font-bold text-gray-300", children: [
            /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-pink-900/40 text-pink-300 rounded border border-pink-700/50", children: "bKash" }),
            /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-orange-900/40 text-orange-300 rounded border border-orange-700/50", children: "Nagad" }),
            /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-purple-900/40 text-purple-300 rounded border border-purple-700/50", children: "Rocket" }),
            /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-blue-900/40 text-blue-300 rounded border border-blue-700/50", children: "VISA" }),
            /* @__PURE__ */ jsx("span", { className: "px-2 py-1 bg-red-900/40 text-red-300 rounded border border-red-700/50", children: "Mastercard" })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between text-gray-500 text-[11px] gap-4", children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " Star Tech & Engineering Ltd | All Rights Reserved"
      ] }),
      /* @__PURE__ */ jsx("p", { children: "Powered by Laravel 12 + React + MySQL" })
    ] })
  ] });
}
function FrontendLayout({ children, title, description, image }) {
  const { flash } = usePage().props;
  const [alertMessage, setAlertMessage] = useState(null);
  const [alertType, setAlertType] = useState(null);
  useEffect(() => {
    if (flash?.success) {
      setAlertMessage(flash.success);
      setAlertType("success");
      const timer = setTimeout(() => setAlertMessage(null), 5e3);
      return () => clearTimeout(timer);
    }
    if (flash?.error) {
      setAlertMessage(flash.error);
      setAlertType("error");
      const timer = setTimeout(() => setAlertMessage(null), 5e3);
      return () => clearTimeout(timer);
    }
  }, [flash]);
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen flex flex-col bg-[#F2F4F8] text-[#111827] antialiased selection:bg-[#EF4A23] selection:text-white", children: [
    /* @__PURE__ */ jsxs(Head, { children: [
      /* @__PURE__ */ jsx("title", { children: title ? `${title} | Star Tech` : "Star Tech & Engineering Ltd | Leading Computer & Laptop Shop in Bangladesh" }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: description || "Leading Computer, Laptop & Component Shop in Bangladesh. Buy Desktop PC, Laptop, Gaming Component at best price in BD." }),
      image && /* @__PURE__ */ jsx("meta", { property: "og:image", content: image }),
      /* @__PURE__ */ jsx("meta", { property: "og:site_name", content: "Star Tech" }),
      /* @__PURE__ */ jsx("meta", { property: "og:type", content: "website" })
    ] }),
    alertMessage && /* @__PURE__ */ jsx("div", { className: "fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-200", children: /* @__PURE__ */ jsxs("div", { className: `flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl text-sm font-medium border text-white ${alertType === "success" ? "bg-emerald-600 border-emerald-500" : "bg-rose-600 border-rose-500"}`, children: [
      alertType === "success" ? /* @__PURE__ */ jsx(CheckCircle2, { className: "w-5 h-5 shrink-0" }) : /* @__PURE__ */ jsx(AlertCircle, { className: "w-5 h-5 shrink-0" }),
      /* @__PURE__ */ jsx("span", { children: alertMessage }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setAlertMessage(null),
          className: "ml-2 hover:opacity-75",
          children: /* @__PURE__ */ jsx(X, { className: "w-4 h-4" })
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "print:hidden", children: [
      /* @__PURE__ */ jsx(Header, {}),
      /* @__PURE__ */ jsx(Navbar, {})
    ] }),
    /* @__PURE__ */ jsx("main", { className: "flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 pb-20 lg:pb-8 print:p-0 print:m-0 print:max-w-none print:w-full", children }),
    /* @__PURE__ */ jsx("div", { className: "print:hidden", children: /* @__PURE__ */ jsx(Footer, {}) })
  ] });
}
export {
  FrontendLayout as F
};
