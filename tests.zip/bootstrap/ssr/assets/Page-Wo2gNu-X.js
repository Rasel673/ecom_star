import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { useForm, Link, router } from "@inertiajs/react";
import { F as FrontendLayout } from "./FrontendLayout-VbDbxh3C.js";
import { ChevronRight, Search, CheckCircle2, Clock, Truck, ShieldCheck, ExternalLink, AlertCircle, Calculator, CreditCard, Wrench, Send, PhoneCall, Mail, MapPin, Building2 } from "lucide-react";
function Page({ page, trackingResult = null, searchQuery = {}, seo = {} }) {
  const [emiPrice, setEmiPrice] = useState(65e3);
  const [emiDownPayment, setEmiDownPayment] = useState(0);
  const [emiMonths, setEmiMonths] = useState(12);
  const [emiBank, setEmiBank] = useState("City Bank AMEX");
  const [emiRate, setEmiRate] = useState(0);
  const financedAmount = Math.max(0, emiPrice - emiDownPayment);
  const monthlyInstallment = emiMonths > 0 ? Math.round(financedAmount * (1 + emiRate / 100) / emiMonths) : 0;
  const [trackingOrderNo, setTrackingOrderNo] = useState(searchQuery.order_number || "");
  const [trackingPhone, setTrackingPhone] = useState(searchQuery.phone || "");
  const handleSearchOrder = (e) => {
    e.preventDefault();
    router.get(
      route("page.show", page.slug),
      {
        order_number: trackingOrderNo || void 0,
        phone: trackingPhone || void 0
      },
      { preserveState: true }
    );
  };
  const { data: inquiryData, setData: setInquiryData, post: postInquiry, processing: inquiryProcessing, reset: resetInquiry } = useForm({
    name: "",
    phone: "",
    email: "",
    subject: "",
    message: "",
    order_number: ""
  });
  const handleInquirySubmit = (e) => {
    e.preventDefault();
    postInquiry(route("page.inquiry"), {
      preserveScroll: true,
      onSuccess: () => resetInquiry()
    });
  };
  return /* @__PURE__ */ jsx(
    FrontendLayout,
    {
      title: seo.title || page.title,
      description: seo.description || page.subtitle,
      children: /* @__PURE__ */ jsxs("div", { className: "max-w-6xl mx-auto py-4 sm:py-6 space-y-8", children: [
        /* @__PURE__ */ jsxs("nav", { className: "flex items-center gap-1.5 text-xs text-gray-500", children: [
          /* @__PURE__ */ jsx(Link, { href: "/", className: "hover:text-[#EF4A23]", children: "Home" }),
          /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-gray-400" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold", children: page.title })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-r from-[#081621] via-[#112538] to-[#081621] text-white rounded-3xl p-6 sm:p-10 shadow-xl border border-gray-800 relative overflow-hidden", children: [
          /* @__PURE__ */ jsxs("div", { className: "relative z-10 max-w-2xl", children: [
            /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold text-orange-400 bg-orange-400/10 border border-orange-400/20 px-3 py-1 rounded-full uppercase tracking-wider inline-block mb-3", children: "Star Tech Official Portal" }),
            /* @__PURE__ */ jsx("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white", children: page.title }),
            page.subtitle && /* @__PURE__ */ jsx("p", { className: "text-sm sm:text-base text-gray-300 mt-2 font-medium", children: page.subtitle })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "absolute right-0 top-0 bottom-0 w-80 bg-gradient-to-l from-orange-600/15 to-transparent pointer-events-none" })
        ] }),
        page.page_type === "order_tracking" && /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm", children: [
            /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 mb-2 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Search, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: "Look Up Your Order Status" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 mb-6", children: "Enter your StarTech Order Number (e.g. ST-261008-1234) and/or your checkout phone number." }),
            /* @__PURE__ */ jsxs("form", { onSubmit: handleSearchOrder, className: "grid grid-cols-1 sm:grid-cols-12 gap-3 sm:gap-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "sm:col-span-5", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Order Number (Optional)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: trackingOrderNo,
                    onChange: (e) => setTrackingOrderNo(e.target.value),
                    placeholder: "e.g. ST-261008-8472",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3 font-mono"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "sm:col-span-5", children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Phone Number (Optional)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "tel",
                    value: trackingPhone,
                    onChange: (e) => setTrackingPhone(e.target.value),
                    placeholder: "01XXXXXXXXX",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3 font-mono"
                  }
                )
              ] }),
              /* @__PURE__ */ jsx("div", { className: "sm:col-span-2 flex items-end", children: /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "submit",
                  className: "w-full py-2.5 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center justify-center gap-1.5",
                  children: [
                    /* @__PURE__ */ jsx(Search, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsx("span", { children: "Track Order" })
                  ]
                }
              ) })
            ] })
          ] }),
          trackingResult ? /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-lg space-y-6 animate-fade-in", children: [
            /* @__PURE__ */ jsxs("div", { className: "border-b pb-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 uppercase font-semibold", children: "Order Details" }),
                  /* @__PURE__ */ jsxs("h3", { className: "text-lg font-black text-gray-900 font-mono", children: [
                    "Order #",
                    trackingResult.order_number
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "text-left sm:text-right", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 block", children: "Total Amount" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-xl font-black text-[#EF4A23]", children: [
                    "৳",
                    Number(trackingResult.total).toLocaleString()
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 gap-2 text-center text-xs", children: [
                { key: "placed", label: "Order Placed", active: true, icon: CheckCircle2 },
                {
                  key: "processing",
                  label: "Processing",
                  active: ["processing", "dispatched", "delivered"].includes(trackingResult.order_status),
                  icon: Clock
                },
                {
                  key: "dispatched",
                  label: "Dispatched",
                  active: ["dispatched", "delivered"].includes(trackingResult.order_status) || Boolean(trackingResult.courier_tracking_id),
                  icon: Truck
                },
                {
                  key: "delivered",
                  label: "Delivered",
                  active: trackingResult.order_status === "delivered",
                  icon: ShieldCheck
                }
              ].map((step, idx) => {
                const Icon = step.icon;
                return /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
                  /* @__PURE__ */ jsx("div", { className: `w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center mb-1.5 transition ${step.active ? "bg-emerald-600 text-white shadow-md" : "bg-gray-100 text-gray-400"}`, children: /* @__PURE__ */ jsx(Icon, { className: "w-4 h-4 sm:w-5 sm:h-5" }) }),
                  /* @__PURE__ */ jsx("span", { className: `text-[11px] sm:text-xs font-bold ${step.active ? "text-gray-900" : "text-gray-400"}`, children: step.label })
                ] }, idx);
              }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs", children: [
              /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-1.5", children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-800 block text-xs", children: "Customer Information" }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Name:" }),
                  " ",
                  trackingResult.customer_name
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Phone:" }),
                  " ",
                  trackingResult.customer_phone
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Address:" }),
                  " ",
                  trackingResult.delivery_address
                ] }),
                /* @__PURE__ */ jsxs("p", { children: [
                  /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Payment:" }),
                  " ",
                  trackingResult.payment_method?.toUpperCase(),
                  " (",
                  trackingResult.payment_status,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-4 bg-purple-50/60 rounded-2xl border border-purple-100 space-y-1.5", children: [
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-purple-900 block text-xs flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsx(Truck, { className: "w-4 h-4 text-purple-600" }),
                  /* @__PURE__ */ jsx("span", { children: "Courier Logistics Information" })
                ] }),
                trackingResult.courier_tracking_id ? /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsxs("p", { children: [
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Courier Service:" }),
                    " ",
                    trackingResult.courier_name || "Express Courier"
                  ] }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Consignment Code:" }),
                    " ",
                    /* @__PURE__ */ jsx("span", { className: "font-mono font-bold text-purple-900", children: trackingResult.courier_tracking_id })
                  ] }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    /* @__PURE__ */ jsx("strong", { className: "text-gray-600", children: "Delivery Status:" }),
                    " ",
                    trackingResult.courier_status || "In Transit"
                  ] }),
                  trackingResult.courier_tracking_url && /* @__PURE__ */ jsxs(
                    "a",
                    {
                      href: trackingResult.courier_tracking_url,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-[11px] shadow-sm transition",
                      children: [
                        /* @__PURE__ */ jsx("span", { children: "Live Courier Tracking" }),
                        /* @__PURE__ */ jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsx("p", { className: "text-gray-500 italic pt-2", children: "Your parcel is being packaged in our central warehouse and scheduled for courier pickup." })
              ] })
            ] }),
            trackingResult.items && trackingResult.items.length > 0 && /* @__PURE__ */ jsxs("div", { className: "pt-2", children: [
              /* @__PURE__ */ jsxs("h4", { className: "text-xs font-bold text-gray-800 uppercase tracking-wider mb-2", children: [
                "Package Items (",
                trackingResult.items.length,
                ")"
              ] }),
              /* @__PURE__ */ jsx("div", { className: "divide-y divide-gray-100 border rounded-xl overflow-hidden", children: trackingResult.items.map((item, idx) => /* @__PURE__ */ jsxs("div", { className: "p-3 flex items-center justify-between text-xs", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "font-bold text-gray-900", children: item.product_name }),
                  /* @__PURE__ */ jsxs("span", { className: "text-gray-400 ml-2", children: [
                    "Qty: ",
                    item.quantity
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("span", { className: "font-bold text-gray-800", children: [
                  "৳",
                  Number(item.subtotal).toLocaleString()
                ] })
              ] }, idx)) })
            ] })
          ] }) : searchQuery.order_number || searchQuery.phone ? /* @__PURE__ */ jsxs("div", { className: "p-6 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs flex items-start gap-3", children: [
            /* @__PURE__ */ jsx(AlertCircle, { className: "w-5 h-5 text-rose-600 shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("strong", { className: "block font-bold", children: "No Order Found Matching Details" }),
              /* @__PURE__ */ jsxs("p", { className: "text-rose-600 mt-0.5", children: [
                "Please double-check your Order Number or Phone Number. If you recently placed the order, give our system a few minutes or call our hotline at ",
                /* @__PURE__ */ jsx("strong", { children: "16793" }),
                "."
              ] })
            ] })
          ] }) : null
        ] }),
        page.page_type === "emi_calculator" && /* @__PURE__ */ jsxs("div", { className: "space-y-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8", children: [
            /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-6", children: [
              /* @__PURE__ */ jsxs("h2", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(Calculator, { className: "w-5 h-5 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Calculate Your Monthly Installment (EMI)" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                  /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Product Total Price (৳)" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-base font-black text-[#EF4A23]", children: [
                    "৳",
                    Number(emiPrice).toLocaleString()
                  ] })
                ] }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "range",
                    min: "10000",
                    max: "500000",
                    step: "5000",
                    value: emiPrice,
                    onChange: (e) => setEmiPrice(Number(e.target.value)),
                    className: "w-full accent-[#EF4A23] cursor-pointer"
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-[10px] text-gray-400 mt-1", children: [
                  /* @__PURE__ */ jsx("span", { children: "৳10,000" }),
                  /* @__PURE__ */ jsx("span", { children: "৳250,000" }),
                  /* @__PURE__ */ jsx("span", { children: "৳500,000" })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                  /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700", children: "Down Payment (Optional ৳)" }),
                  /* @__PURE__ */ jsxs("span", { className: "text-xs font-bold text-gray-800", children: [
                    "৳",
                    Number(emiDownPayment).toLocaleString()
                  ] })
                ] }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    min: "0",
                    max: emiPrice - 5e3,
                    step: "1000",
                    value: emiDownPayment,
                    onChange: (e) => setEmiDownPayment(Math.min(emiPrice - 5e3, Math.max(0, Number(e.target.value)))),
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700 block mb-2", children: "EMI Tenure (Duration)" }),
                /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 sm:grid-cols-7 gap-2", children: [3, 6, 9, 12, 18, 24, 36].map((m) => /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setEmiMonths(m),
                    className: `py-2 px-2 text-xs font-bold rounded-xl border text-center transition ${emiMonths === m ? "bg-[#081621] text-white border-[#081621] shadow-sm" : "bg-white text-gray-700 border-gray-200 hover:border-gray-300"}`,
                    children: [
                      m,
                      "M"
                    ]
                  },
                  m
                )) })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "text-xs font-bold text-gray-700 block mb-2", children: "Select Your Credit Card Bank" }),
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: emiBank,
                    onChange: (e) => setEmiBank(e.target.value),
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2.5 px-3",
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "City Bank AMEX", children: "City Bank (American Express / Visa / Master)" }),
                      /* @__PURE__ */ jsx("option", { value: "BRAC Bank", children: "BRAC Bank Credit Card" }),
                      /* @__PURE__ */ jsx("option", { value: "Eastern Bank (EBL)", children: "Eastern Bank Ltd (EBL)" }),
                      /* @__PURE__ */ jsx("option", { value: "Standard Chartered", children: "Standard Chartered Bank (SCB)" }),
                      /* @__PURE__ */ jsx("option", { value: "Dutch Bangla Bank (DBBL)", children: "Dutch-Bangla Bank (DBBL Nexus / Visa)" }),
                      /* @__PURE__ */ jsx("option", { value: "Prime Bank", children: "Prime Bank Credit Card" }),
                      /* @__PURE__ */ jsx("option", { value: "Mutual Trust Bank (MTB)", children: "Mutual Trust Bank (MTB)" }),
                      /* @__PURE__ */ jsx("option", { value: "Dhaka Bank", children: "Dhaka Bank Credit Card" }),
                      /* @__PURE__ */ jsx("option", { value: "Southeast Bank", children: "Southeast Bank" }),
                      /* @__PURE__ */ jsx("option", { value: "United Commercial Bank (UCB)", children: "UCB Credit Card" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "lg:col-span-5 bg-gradient-to-br from-[#081621] via-[#112538] to-[#081621] text-white p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col justify-between border border-gray-800", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b border-gray-800 pb-4 mb-6", children: [
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 uppercase tracking-wider block", children: "Estimated Installment" }),
                    /* @__PURE__ */ jsxs("span", { className: "text-3xl font-black text-[#EF4A23] mt-1 block", children: [
                      "৳",
                      monthlyInstallment.toLocaleString(),
                      /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400 font-normal ml-1", children: "/ month" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-500/20 text-[#EF4A23] flex items-center justify-center", children: /* @__PURE__ */ jsx(CreditCard, { className: "w-6 h-6" }) })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-3 text-xs", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1.5 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Total Purchase Value:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      "৳",
                      emiPrice.toLocaleString()
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1.5 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Down Payment:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      "৳",
                      Number(emiDownPayment).toLocaleString()
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1.5 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Financed / Loan Amount:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      "৳",
                      financedAmount.toLocaleString()
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1.5 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Tenure Duration:" }),
                    /* @__PURE__ */ jsxs("span", { className: "font-bold text-white", children: [
                      emiMonths,
                      " Months"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1.5 border-b border-gray-800/80", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Partner Bank:" }),
                    /* @__PURE__ */ jsx("span", { className: "font-bold text-orange-400", children: emiBank })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-1.5", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Annual Interest Rate:" }),
                    /* @__PURE__ */ jsx("span", { className: "font-bold text-emerald-400", children: "0% Promotional EMI" })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-8 pt-4 border-t border-gray-800 text-[11px] text-gray-400 space-y-1", children: [
                /* @__PURE__ */ jsxs("p", { className: "flex items-center gap-1.5 text-emerald-400 font-semibold", children: [
                  /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { children: "Available both online & at all StarTech retail branches." })
                ] }),
                /* @__PURE__ */ jsx("p", { children: "* Valid with all eligible credit cards from participating commercial banks in Bangladesh." })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 border-l-2 border-[#EF4A23] pl-2", children: "28+ Partner Banks with 0% EMI Facility" }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 text-center text-xs font-semibold text-gray-700", children: [
              "City Bank AMEX",
              "BRAC Bank",
              "Eastern Bank",
              "Standard Chartered",
              "DBBL",
              "Prime Bank",
              "Mutual Trust Bank",
              "Dhaka Bank",
              "Southeast Bank",
              "UCB",
              "LankaBangla",
              "Bank Asia",
              "NCC Bank",
              "Jamuna Bank",
              "One Bank",
              "Premier Bank",
              "Trust Bank",
              "Midland Bank"
            ].map((b, i) => /* @__PURE__ */ jsx("div", { className: "p-3 bg-gray-50 rounded-xl border border-gray-200 hover:border-gray-300", children: b }, i)) })
          ] })
        ] }),
        (page.page_type === "contact_us" || page.page_type === "service_complain") && /* @__PURE__ */ jsx("div", { className: "space-y-8", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-gray-200/90 shadow-sm space-y-5", children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-base font-bold text-gray-900 flex items-center gap-2", children: [
              page.page_type === "service_complain" ? /* @__PURE__ */ jsx(Wrench, { className: "w-5 h-5 text-[#EF4A23]" }) : /* @__PURE__ */ jsx(Send, { className: "w-5 h-5 text-[#EF4A23]" }),
              /* @__PURE__ */ jsx("span", { children: page.page_type === "service_complain" ? "Submit RMA Service & Repair Complaint" : "Send an Inquiry / Feedback" })
            ] }),
            /* @__PURE__ */ jsxs("form", { onSubmit: handleInquirySubmit, className: "space-y-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Your Name *" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "text",
                      required: true,
                      value: inquiryData.name,
                      onChange: (e) => setInquiryData("name", e.target.value),
                      placeholder: "e.g. Asif Mahmud",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Phone Number *" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "tel",
                      required: true,
                      value: inquiryData.phone,
                      onChange: (e) => setInquiryData("phone", e.target.value),
                      placeholder: "01XXXXXXXXX",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Email Address" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "email",
                      value: inquiryData.email,
                      onChange: (e) => setInquiryData("email", e.target.value),
                      placeholder: "your@email.com",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Order / Invoice No (Optional)" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "text",
                      value: inquiryData.order_number,
                      onChange: (e) => setInquiryData("order_number", e.target.value),
                      placeholder: "e.g. ST-261008-8472",
                      className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3 font-mono"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Subject *" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    required: true,
                    value: inquiryData.subject,
                    onChange: (e) => setInquiryData("subject", e.target.value),
                    placeholder: "e.g. Warranty claim for GPU / Query regarding bulk purchase",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] py-2 px-3"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-semibold text-gray-700 mb-1", children: "Message / Complaint Details *" }),
                /* @__PURE__ */ jsx(
                  "textarea",
                  {
                    rows: "5",
                    required: true,
                    value: inquiryData.message,
                    onChange: (e) => setInquiryData("message", e.target.value),
                    placeholder: "Please describe your technical issue, hardware serial number, or feedback...",
                    className: "w-full text-xs rounded-xl border-gray-300 focus:border-[#EF4A23] focus:ring-[#EF4A23] p-3 leading-relaxed"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "submit",
                  disabled: inquiryProcessing,
                  className: "w-full py-3 px-4 bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold text-xs rounded-xl transition shadow-md flex items-center justify-center gap-2 disabled:opacity-50",
                  children: [
                    /* @__PURE__ */ jsx(Send, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsx("span", { children: inquiryProcessing ? "Submitting..." : "Send Message to StarTech" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "lg:col-span-5 space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-[#081621] text-white p-6 rounded-3xl border border-gray-800 shadow-xl space-y-4", children: [
              /* @__PURE__ */ jsxs("h4", { className: "text-sm font-bold text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(PhoneCall, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Direct Customer Hotline" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-4 bg-white/5 rounded-2xl border border-white/10", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[11px] text-gray-400 block", children: "General Hotline (10am - 7pm)" }),
                /* @__PURE__ */ jsx("span", { className: "text-2xl font-black text-[#EF4A23] block mt-0.5", children: "16793" }),
                /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-300 mt-1 block", children: "Alternate: 09678002003" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "text-xs text-gray-300 space-y-2", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4 text-[#EF4A23] shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("span", { children: "info@startech.com.bd • support@startech.com.bd" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-[#EF4A23] shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("span", { children: "28 Kazi Nazrul Islam Avenue, Banglamotor, Dhaka 1000" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-3xl border border-gray-200/90 shadow-sm space-y-3 text-xs", children: [
              /* @__PURE__ */ jsxs("h4", { className: "font-bold text-gray-900 flex items-center gap-2 text-xs", children: [
                /* @__PURE__ */ jsx(Building2, { className: "w-4 h-4 text-[#EF4A23]" }),
                /* @__PURE__ */ jsx("span", { children: "Major Superstore Outlets" })
              ] }),
              /* @__PURE__ */ jsxs("ul", { className: "space-y-2 text-gray-600 divide-y divide-gray-100", children: [
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "IDB Bhaban:" }),
                  " BCS Computer City, Agargaon, Dhaka"
                ] }),
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "Multiplan Center:" }),
                  " New Elephant Road, Dhaka"
                ] }),
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "Uttara Branch:" }),
                  " Sector 3, RAK Tower, Jashimuddin Road"
                ] }),
                /* @__PURE__ */ jsxs("li", { className: "pt-2", children: [
                  /* @__PURE__ */ jsx("strong", { children: "Agrabad Chattogram:" }),
                  " Yunusco City Center, CDA Avenue"
                ] })
              ] })
            ] })
          ] })
        ] }) }),
        page.content && /* @__PURE__ */ jsx("div", { className: "bg-white p-6 sm:p-10 rounded-3xl border border-gray-200/90 shadow-sm", children: /* @__PURE__ */ jsx(
          "div",
          {
            className: "prose prose-sm sm:prose max-w-none text-gray-700 leading-relaxed space-y-4",
            dangerouslySetInnerHTML: { __html: page.content }
          }
        ) })
      ] })
    }
  );
}
export {
  Page as default
};
