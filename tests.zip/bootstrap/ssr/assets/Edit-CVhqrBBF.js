import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { useForm, Link } from "@inertiajs/react";
import { A as AdminLayout } from "./AdminLayout-ZE2N9Axe.js";
import { ArrowLeft } from "lucide-react";
function Edit({ category, parentCategories = [] }) {
  const { data, setData, put, processing, errors } = useForm({
    name: category.name || "",
    slug: category.slug || "",
    parent_id: category.parent_id || "",
    icon: category.icon || "",
    image: category.image || "",
    description: category.description || "",
    is_featured: !!category.is_featured,
    sort_order: category.sort_order || 0,
    status: !!category.status,
    meta_title: category.meta_title || "",
    meta_description: category.meta_description || ""
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    put(route("admin.categories.update", category.id));
  };
  return /* @__PURE__ */ jsx(AdminLayout, { title: `Edit Category: ${category.name}`, children: /* @__PURE__ */ jsxs("div", { className: "max-w-2xl mx-auto", children: [
    /* @__PURE__ */ jsxs(
      Link,
      {
        href: route("admin.categories.index"),
        className: "inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#EF4A23] font-semibold mb-4",
        children: [
          /* @__PURE__ */ jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsx("span", { children: "Back to Categories" })
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl border border-gray-200 shadow-sm p-6", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-bold text-gray-900 border-b pb-3 mb-4", children: "Edit Category" }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("label", { className: "block font-semibold text-gray-700 mb-1", children: [
            "Category Name ",
            /* @__PURE__ */ jsx("span", { className: "text-rose-500", children: "*" })
          ] }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              required: true,
              value: data.name,
              onChange: (e) => setData("name", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
            }
          ),
          errors.name && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Slug" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              required: true,
              value: data.slug,
              onChange: (e) => setData("slug", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
            }
          ),
          errors.slug && /* @__PURE__ */ jsx("p", { className: "text-rose-500 mt-1", children: errors.slug })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Parent Category" }),
          /* @__PURE__ */ jsxs(
            "select",
            {
              value: data.parent_id,
              onChange: (e) => setData("parent_id", e.target.value),
              className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]",
              children: [
                /* @__PURE__ */ jsx("option", { value: "", children: "— None (Root Category) —" }),
                parentCategories.map((p) => /* @__PURE__ */ jsx("option", { value: p.id, children: p.name }, p.id))
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Icon Name" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: data.icon,
                onChange: (e) => setData("icon", e.target.value),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block font-semibold text-gray-700 mb-1", children: "Sort Order" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: data.sort_order,
                onChange: (e) => setData("sort_order", Number(e.target.value)),
                className: "w-full p-2.5 rounded-lg border border-gray-300 focus:border-[#EF4A23]"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-6 pt-2", children: [
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.is_featured,
                onChange: (e) => setData("is_featured", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Featured on Homepage" })
          ] }),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-semibold text-gray-700", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: data.status,
                onChange: (e) => setData("status", e.target.checked),
                className: "rounded border-gray-300 text-[#EF4A23] focus:ring-[#EF4A23]"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: "Active" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-4 border-t flex justify-end gap-3", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("admin.categories.index"),
              className: "px-4 py-2 border rounded-lg hover:bg-gray-50 text-gray-700 font-semibold",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              disabled: processing,
              className: "bg-[#EF4A23] hover:bg-[#d63c17] text-white font-bold px-6 py-2 rounded-lg transition",
              children: processing ? "Updating..." : "Update Category"
            }
          )
        ] })
      ] })
    ] })
  ] }) });
}
export {
  Edit as default
};
