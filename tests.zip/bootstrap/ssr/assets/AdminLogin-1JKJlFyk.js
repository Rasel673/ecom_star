import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { useForm, Head, Link } from "@inertiajs/react";
import { Shield, Store, KeyRound, CheckCircle2, Mail, AlertCircle, Lock, EyeOff, Eye, ArrowRight, Server } from "lucide-react";
function AdminLogin({ status }) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: true
  });
  const [showPassword, setShowPassword] = useState(false);
  const submit = (e) => {
    e.preventDefault();
    post(route("login"), {
      onFinish: () => reset("password")
    });
  };
  const fillDemoAdmin = () => {
    setData({
      email: "admin@startech.com.bd",
      password: "password123",
      remember: true
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-[#050B14] text-gray-200 flex flex-col justify-between relative overflow-hidden font-sans selection:bg-[#EF4A23] selection:text-white", children: [
    /* @__PURE__ */ jsx(Head, { title: "Admin Security Gateway - Star Tech" }),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: "absolute inset-0 opacity-[0.03] pointer-events-none",
        style: {
          backgroundImage: `linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(90deg, #ffffff 1px, transparent 1px)`,
          backgroundSize: "40px 40px"
        }
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-gradient-to-tr from-[#EF4A23]/10 via-orange-600/5 to-blue-600/10 rounded-full blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsx("header", { className: "relative z-10 border-b border-gray-800/80 bg-[#08121E]/60 backdrop-blur-md px-6 py-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-6xl mx-auto flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxs(Link, { href: "/", className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xl font-black tracking-tight text-white", children: "STAR" }),
          /* @__PURE__ */ jsx("span", { className: "text-xl font-black tracking-tight text-[#EF4A23]", children: "TECH" })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "h-4 w-[1px] bg-gray-700" }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 px-2 py-0.5 rounded bg-orange-950/40 text-orange-400 border border-orange-800/60 text-[10px] font-mono font-bold uppercase tracking-wider", children: [
          /* @__PURE__ */ jsx(Shield, { className: "w-3 h-3 text-[#EF4A23]" }),
          /* @__PURE__ */ jsx("span", { children: "Command Portal" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: "/",
          className: "text-xs text-gray-400 hover:text-white transition flex items-center gap-1.5 font-medium",
          children: [
            /* @__PURE__ */ jsx(Store, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsx("span", { children: "Return to Store" })
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ jsx("main", { className: "flex-1 flex items-center justify-center p-4 sm:p-6 relative z-10 my-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-md bg-[#0B1726]/90 backdrop-blur-xl border border-gray-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#EF4A23] to-transparent" }),
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-6", children: [
        /* @__PURE__ */ jsx("div", { className: "w-14 h-14 mx-auto rounded-2xl bg-[#08121E] border border-gray-700/80 text-[#EF4A23] flex items-center justify-center shadow-lg shadow-black/50 mb-3.5", children: /* @__PURE__ */ jsx(KeyRound, { className: "w-6 h-6 text-[#EF4A23]" }) }),
        /* @__PURE__ */ jsx("h1", { className: "text-xl sm:text-2xl font-black text-white tracking-tight", children: "Admin Authentication" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-400 mt-1", children: "Authorized StarTech personnel and store operators only" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-6 p-3 bg-gray-900/80 border border-gray-700/60 rounded-xl flex items-center justify-between gap-2 text-xs", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-300 font-medium", children: "Demo Admin:" }),
          /* @__PURE__ */ jsx("code", { className: "bg-gray-800 text-orange-300 px-1.5 py-0.5 rounded text-[11px] font-mono", children: "admin@startech.com.bd" })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: fillDemoAdmin,
            className: "px-2.5 py-1 bg-[#EF4A23] hover:bg-[#d63c17] text-white text-[10px] font-bold rounded-lg transition shadow-sm uppercase tracking-wider",
            children: "Autofill"
          }
        )
      ] }),
      status && /* @__PURE__ */ jsxs("div", { className: "mb-5 p-3 rounded-xl bg-emerald-950/40 text-emerald-300 text-xs font-semibold border border-emerald-800/60 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(CheckCircle2, { className: "w-4 h-4 shrink-0" }),
        /* @__PURE__ */ jsx("span", { children: status })
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-300 mb-1.5", htmlFor: "admin-email", children: "Admin Email" }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400", children: /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx(
              "input",
              {
                id: "admin-email",
                type: "email",
                name: "email",
                value: data.email,
                autoComplete: "username",
                required: true,
                onChange: (e) => setData("email", e.target.value),
                placeholder: "admin@startech.com.bd",
                className: `w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border bg-[#060D17] text-white transition ${errors.email ? "border-rose-500/80 focus:border-rose-500 focus:ring-rose-900/40" : "border-gray-700/80 focus:border-[#EF4A23] focus:ring-orange-950/50"} focus:outline-none focus:ring-4`
              }
            )
          ] }),
          errors.email && /* @__PURE__ */ jsxs("p", { className: "mt-1.5 text-xs text-rose-400 font-medium flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(AlertCircle, { className: "w-3.5 h-3.5 shrink-0" }),
            /* @__PURE__ */ jsx("span", { children: errors.email })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs font-bold text-gray-300 mb-1.5", htmlFor: "admin-password", children: "Security Password" }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400", children: /* @__PURE__ */ jsx(Lock, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx(
              "input",
              {
                id: "admin-password",
                type: showPassword ? "text" : "password",
                name: "password",
                value: data.password,
                autoComplete: "current-password",
                required: true,
                onChange: (e) => setData("password", e.target.value),
                placeholder: "••••••••••••",
                className: `w-full pl-10 pr-10 py-2.5 text-xs rounded-xl border bg-[#060D17] text-white transition ${errors.password ? "border-rose-500/80 focus:border-rose-500 focus:ring-rose-900/40" : "border-gray-700/80 focus:border-[#EF4A23] focus:ring-orange-950/50"} focus:outline-none focus:ring-4`
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowPassword(!showPassword),
                className: "absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-200 transition",
                children: showPassword ? /* @__PURE__ */ jsx(EyeOff, { className: "w-4 h-4" }) : /* @__PURE__ */ jsx(Eye, { className: "w-4 h-4" })
              }
            )
          ] }),
          errors.password && /* @__PURE__ */ jsxs("p", { className: "mt-1.5 text-xs text-rose-400 font-medium flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(AlertCircle, { className: "w-3.5 h-3.5 shrink-0" }),
            /* @__PURE__ */ jsx("span", { children: errors.password })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between pt-1", children: /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer select-none", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              name: "remember",
              checked: data.remember,
              onChange: (e) => setData("remember", e.target.checked),
              className: "w-4 h-4 text-[#EF4A23] bg-[#060D17] border-gray-700 rounded focus:ring-[#EF4A23] focus:ring-offset-0"
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-400", children: "Remember administrative workstation" })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsxs(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#EF4A23] to-[#d63c17] hover:from-[#d63c17] hover:to-[#be3412] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-orange-950/60 transition disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsx("span", { children: processing ? "Authenticating System..." : "Enter Admin Control Center" }),
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4" })
            ]
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 pt-4 border-t border-gray-800 text-center space-y-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-1.5 text-[11px] text-gray-500", children: [
          /* @__PURE__ */ jsx(Server, { className: "w-3.5 h-3.5 text-emerald-400" }),
          /* @__PURE__ */ jsx("span", { children: "StarTech SSL Protected • Audit Logging Active" })
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-gray-600", children: [
          "Need customer access instead?",
          " ",
          /* @__PURE__ */ jsx(Link, { href: route("login"), className: "text-orange-400 hover:underline", children: "Customer Sign In" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("footer", { className: "relative z-10 border-t border-gray-800/80 py-3 text-center text-[11px] text-gray-500 bg-[#08121E]/60", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " Star Tech & Engineering Ltd • Internal Systems Division"
    ] })
  ] });
}
export {
  AdminLogin as default
};
